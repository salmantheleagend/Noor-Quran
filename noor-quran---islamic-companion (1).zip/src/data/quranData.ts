import { SurahMeta, AyahItem } from '../types';
import {
  convertPhoneticToBengali,
  normalizeArabicWithCompleteTashkeel,
  getBengaliPronunciation,
} from '../utils/quranTransliteration';

export interface TajweedRuleInfo {
  nameBn: string;
  nameAr: string;
  colorHex: string;
  className: string;
  descriptionBn: string;
  exampleAr: string;
}

export const TAJWEED_RULES: TajweedRuleInfo[] = [
  {
    nameBn: 'মাদ্দ (Madd - দীর্ঘ টান)',
    nameAr: 'المدّ',
    colorHex: '#dc2626',
    className: 'tajweed-madd',
    descriptionBn: 'মাদ্দের হরফের পর হামযাহ বা সাকিন আসলে ৩ বা ৪ আলিফ পরিমাণ দীর্ঘ টেনে পড়তে হয়।',
    exampleAr: 'السَّمَاۤءِ',
  },
  {
    nameBn: 'ওয়াজিব গুন্নাহ ও গুন্নাহ (Ghunnah)',
    nameAr: 'الغُنّة',
    colorHex: '#10b981',
    className: 'tajweed-ghunnah',
    descriptionBn: 'নূন বা মীম মুশাদ্দাদে ১ আলিফ পরিমাণ নাকের বাঁশিতে আওয়াজ আটকে গুন্নাহ করা ওয়াজিব।',
    exampleAr: 'إِنَّ / ثُمَّ',
  },
  {
    nameBn: 'ইখফা (Ikhfa - গোপন করে গুন্নাহ)',
    nameAr: 'الإخفاء',
    colorHex: '#0d9488',
    className: 'tajweed-ikhfa',
    descriptionBn: 'নূন সাকিন বা তানবীনের পর ইখফার ১৫টি হরফের কোনো একটি আসলে গুন্নাহসহ অস্পষ্ট আওয়াজে পড়া।',
    exampleAr: 'مِن قَبْلُ / كُنتُمْ',
  },
  {
    nameBn: 'ইদগাম (Idgham - মিলিয়ে পড়া)',
    nameAr: 'الإدغام',
    colorHex: '#6366f1',
    className: 'tajweed-idgham',
    descriptionBn: 'প্রথম হরফকে পরবর্তী হরফের সাথে মিলিয়ে সংযুক্ত করে পড়া (বাগুন্নাহ ও বা-ই-গুন্নাহ)।',
    exampleAr: 'مَن يَّقُولُ / مِن رَّبِّهِمْ',
  },
  {
    nameBn: 'কলকলাহ (Qalqalah - প্রতিধ্বনি)',
    nameAr: 'القلقلة',
    colorHex: '#3b82f6',
    className: 'tajweed-qalqalah',
    descriptionBn: 'ক্বাফ, ত্বো, বা, জিম, দাল (ق ط ب ج د)—এ ৫টি হরফে সাকিন হলে আওয়াজকে ধাক্কা দিয়ে প্রতিধ্বনি তৈরি করা।',
    exampleAr: 'قُلْ هُوَ اللَّهُ أَحَدْ / خَلَقَ',
  },
  {
    nameBn: 'ইকলাব (Iqlab - পরিবর্তন করা)',
    nameAr: 'الإقلاب',
    colorHex: '#d97706',
    className: 'tajweed-iqlab',
    descriptionBn: 'নূন সাকিন বা তানবীনের পর "বা" (ب) আসলে নূন-কে "মীম" (م) দ্বারা পরিবর্তন করে গুন্নাহসহ পড়া।',
    exampleAr: 'مِۢن بَعْدِ',
  },
];

export const SURAH_LIST: SurahMeta[] = [
  { number: 1, nameArabic: 'الفاتحة', nameBangla: 'আল-ফাতিহা', nameEnglish: 'Al-Fatihah', englishTranslation: 'The Opening', numberOfAyahs: 7, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 1, pageStart: 1 },
  { number: 2, nameArabic: 'البقرة', nameBangla: 'আল-বাকারা', nameEnglish: 'Al-Baqarah', englishTranslation: 'The Cow', numberOfAyahs: 286, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 1, pageStart: 2 },
  { number: 3, nameArabic: 'آل عمران', nameBangla: 'আলে-ইমরান', nameEnglish: 'Ali \'Imran', englishTranslation: 'Family of Imran', numberOfAyahs: 200, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 3, pageStart: 50 },
  { number: 4, nameArabic: 'النساء', nameBangla: 'আন-নিসা', nameEnglish: 'An-Nisa', englishTranslation: 'The Women', numberOfAyahs: 176, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 4, pageStart: 77 },
  { number: 5, nameArabic: 'المائدة', nameBangla: 'আল-মায়িদাহ', nameEnglish: 'Al-Ma\'idah', englishTranslation: 'The Table Spread', numberOfAyahs: 120, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 6, pageStart: 106 },
  { number: 6, nameArabic: 'الأنعام', nameBangla: 'আল-আনআম', nameEnglish: 'Al-An\'am', englishTranslation: 'The Cattle', numberOfAyahs: 165, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 7, pageStart: 128 },
  { number: 7, nameArabic: 'الأعراف', nameBangla: 'আল-আরাফ', nameEnglish: 'Al-A\'raf', englishTranslation: 'The Heights', numberOfAyahs: 206, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 8, pageStart: 151 },
  { number: 8, nameArabic: 'الأنفال', nameBangla: 'আল-আনফাল', nameEnglish: 'Al-Anfal', englishTranslation: 'The Spoils of War', numberOfAyahs: 75, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 9, pageStart: 177 },
  { number: 9, nameArabic: 'التوبة', nameBangla: 'আত-তাওবাহ', nameEnglish: 'At-Tawbah', englishTranslation: 'The Repentance', numberOfAyahs: 129, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 10, pageStart: 187 },
  { number: 10, nameArabic: 'يونس', nameBangla: 'ইউনুস', nameEnglish: 'Yunus', englishTranslation: 'Jonah', numberOfAyahs: 109, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 11, pageStart: 208 },
  { number: 11, nameArabic: 'هود', nameBangla: 'হুদ', nameEnglish: 'Hud', englishTranslation: 'Hud', numberOfAyahs: 123, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 11, pageStart: 221 },
  { number: 12, nameArabic: 'يوسف', nameBangla: 'ইউসুফ', nameEnglish: 'Yusuf', englishTranslation: 'Joseph', numberOfAyahs: 111, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 12, pageStart: 235 },
  { number: 13, nameArabic: 'الرعد', nameBangla: 'আর-রাদ', nameEnglish: 'Ar-Ra\'d', englishTranslation: 'The Thunder', numberOfAyahs: 43, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 13, pageStart: 249 },
  { number: 14, nameArabic: 'إبراهيم', nameBangla: 'ইব্রাহিম', nameEnglish: 'Ibrahim', englishTranslation: 'Abraham', numberOfAyahs: 52, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 13, pageStart: 255 },
  { number: 15, nameArabic: 'الحجر', nameBangla: 'আল-হিজর', nameEnglish: 'Al-Hijr', englishTranslation: 'The Rocky Tract', numberOfAyahs: 99, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 14, pageStart: 262 },
  { number: 16, nameArabic: 'النحل', nameBangla: 'আন-নাহল', nameEnglish: 'An-Nahl', englishTranslation: 'The Bee', numberOfAyahs: 128, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 14, pageStart: 267 },
  { number: 17, nameArabic: 'الإسراء', nameBangla: 'আল-ইসরা', nameEnglish: 'Al-Isra', englishTranslation: 'The Night Journey', numberOfAyahs: 111, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 15, pageStart: 282 },
  { number: 18, nameArabic: 'الكهف', nameBangla: 'আল-কাহফ', nameEnglish: 'Al-Kahf', englishTranslation: 'The Cave', numberOfAyahs: 110, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 15, pageStart: 293 },
  { number: 19, nameArabic: 'مريم', nameBangla: 'মারিয়াম', nameEnglish: 'Maryam', englishTranslation: 'Mary', numberOfAyahs: 98, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 16, pageStart: 305 },
  { number: 20, nameArabic: 'طه', nameBangla: 'ত্বা-হা', nameEnglish: 'Ta-Ha', englishTranslation: 'Ta-Ha', numberOfAyahs: 135, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 16, pageStart: 312 },
  { number: 21, nameArabic: 'الأنبياء', nameBangla: 'আল-আম্বিয়া', nameEnglish: 'Al-Anbiya', englishTranslation: 'The Prophets', numberOfAyahs: 112, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 17, pageStart: 322 },
  { number: 22, nameArabic: 'الحج', nameBangla: 'আল-হাজ্ব', nameEnglish: 'Al-Hajj', englishTranslation: 'The Pilgrimage', numberOfAyahs: 78, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 17, pageStart: 332 },
  { number: 23, nameArabic: 'المؤمنون', nameBangla: 'আল-মুমিনুন', nameEnglish: 'Al-Mu\'minun', englishTranslation: 'The Believers', numberOfAyahs: 118, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 18, pageStart: 342 },
  { number: 24, nameArabic: 'النور', nameBangla: 'আন-নূর', nameEnglish: 'An-Nur', englishTranslation: 'The Light', numberOfAyahs: 64, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 18, pageStart: 350 },
  { number: 25, nameArabic: 'الفرقان', nameBangla: 'আল-ফুরকান', nameEnglish: 'Al-Furqan', englishTranslation: 'The Criterion', numberOfAyahs: 77, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 18, pageStart: 359 },
  { number: 26, nameArabic: 'الشعراء', nameBangla: 'আশ-শুআরা', nameEnglish: 'Ash-Shu\'ara', englishTranslation: 'The Poets', numberOfAyahs: 227, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 19, pageStart: 367 },
  { number: 27, nameArabic: 'النمل', nameBangla: 'আন-নামল', nameEnglish: 'An-Naml', englishTranslation: 'The Ant', numberOfAyahs: 93, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 19, pageStart: 377 },
  { number: 28, nameArabic: 'القصص', nameBangla: 'আল-কাসাস', nameEnglish: 'Al-Qasas', englishTranslation: 'The Stories', numberOfAyahs: 88, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 20, pageStart: 385 },
  { number: 29, nameArabic: 'العنكبوت', nameBangla: 'আল-আনকাবুত', nameEnglish: 'Al-\'Ankabut', englishTranslation: 'The Spider', numberOfAyahs: 69, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 20, pageStart: 396 },
  { number: 30, nameArabic: 'الروم', nameBangla: 'আর-রুম', nameEnglish: 'Ar-Rum', englishTranslation: 'The Romans', numberOfAyahs: 60, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 21, pageStart: 404 },
  { number: 31, nameArabic: 'لقمان', nameBangla: 'লুকমান', nameEnglish: 'Luqman', englishTranslation: 'Luqman', numberOfAyahs: 34, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 21, pageStart: 411 },
  { number: 32, nameArabic: 'السجدة', nameBangla: 'আস-সাজদাহ', nameEnglish: 'As-Sajdah', englishTranslation: 'The Prostration', numberOfAyahs: 30, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 21, pageStart: 415 },
  { number: 33, nameArabic: 'الأحزاب', nameBangla: 'আল-আহযাব', nameEnglish: 'Al-Ahzab', englishTranslation: 'The Combined Forces', numberOfAyahs: 73, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 21, pageStart: 418 },
  { number: 34, nameArabic: 'سبأ', nameBangla: 'সাবা', nameEnglish: 'Saba', englishTranslation: 'Sheba', numberOfAyahs: 54, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 22, pageStart: 428 },
  { number: 35, nameArabic: 'فاطر', nameBangla: 'ফাতির', nameEnglish: 'Fatir', englishTranslation: 'Originator', numberOfAyahs: 45, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 22, pageStart: 434 },
  { number: 36, nameArabic: 'يس', nameBangla: 'ইয়াসীন', nameEnglish: 'Ya-Sin', englishTranslation: 'Ya Sin', numberOfAyahs: 83, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 22, pageStart: 440 },
  { number: 37, nameArabic: 'الصافات', nameBangla: 'আস-সাফফাত', nameEnglish: 'As-Saffat', englishTranslation: 'Those who set the Ranks', numberOfAyahs: 182, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 23, pageStart: 446 },
  { number: 38, nameArabic: 'ص', nameBangla: 'সোয়াদ', nameEnglish: 'Sad', englishTranslation: 'The Letter "Saad"', numberOfAyahs: 88, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 23, pageStart: 453 },
  { number: 39, nameArabic: 'الزمر', nameBangla: 'আজ-জুমার', nameEnglish: 'Az-Zumar', englishTranslation: 'The Troops', numberOfAyahs: 75, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 23, pageStart: 458 },
  { number: 40, nameArabic: 'غافر', nameBangla: 'গাফির', nameEnglish: 'Ghafir', englishTranslation: 'The Forgiver', numberOfAyahs: 85, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 24, pageStart: 467 },
  { number: 41, nameArabic: 'فصلت', nameBangla: 'ফুসসিলাত', nameEnglish: 'Fussilat', englishTranslation: 'Explained in Detail', numberOfAyahs: 54, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 24, pageStart: 477 },
  { number: 42, nameArabic: 'الشورى', nameBangla: 'আশ-শুরা', nameEnglish: 'Ash-Shura', englishTranslation: 'The Consultation', numberOfAyahs: 53, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 25, pageStart: 483 },
  { number: 43, nameArabic: 'الزخرف', nameBangla: 'আজ-জুযরুফ', nameEnglish: 'Az-Zukhruf', englishTranslation: 'The Ornaments of Gold', numberOfAyahs: 89, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 25, pageStart: 489 },
  { number: 44, nameArabic: 'الدخان', nameBangla: 'আদ-দুখান', nameEnglish: 'Ad-Dukhan', englishTranslation: 'The Smoke', numberOfAyahs: 59, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 25, pageStart: 496 },
  { number: 45, nameArabic: 'الجاثية', nameBangla: 'আল-জাসিয়াহ', nameEnglish: 'Al-Jathiyah', englishTranslation: 'The Crouching', numberOfAyahs: 37, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 25, pageStart: 499 },
  { number: 46, nameArabic: 'الأحقاف', nameBangla: 'আল-আহকাফ', nameEnglish: 'Al-Ahqaf', englishTranslation: 'The Wind-Curved Sandhills', numberOfAyahs: 35, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 26, pageStart: 502 },
  { number: 47, nameArabic: 'محمد', nameBangla: 'মুহাম্মদ', nameEnglish: 'Muhammad', englishTranslation: 'Muhammad', numberOfAyahs: 38, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 26, pageStart: 507 },
  { number: 48, nameArabic: 'الفتح', nameBangla: 'আল-ফাতহ', nameEnglish: 'Al-Fath', englishTranslation: 'The Victory', numberOfAyahs: 29, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 26, pageStart: 511 },
  { number: 49, nameArabic: 'الحجرات', nameBangla: 'আল-হুজুরাত', nameEnglish: 'Al-Hujurat', englishTranslation: 'The Rooms', numberOfAyahs: 18, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 26, pageStart: 515 },
  { number: 50, nameArabic: 'ق', nameBangla: 'ক্বাফ', nameEnglish: 'Qaf', englishTranslation: 'The Letter "Qaf"', numberOfAyahs: 45, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 26, pageStart: 518 },
  { number: 51, nameArabic: 'الذاريات', nameBangla: 'আয-যারিয়াত', nameEnglish: 'Adh-Dhariyat', englishTranslation: 'The Winnowing Winds', numberOfAyahs: 60, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 26, pageStart: 520 },
  { number: 52, nameArabic: 'الطور', nameBangla: 'আত-তূর', nameEnglish: 'At-Tur', englishTranslation: 'The Mount', numberOfAyahs: 49, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 27, pageStart: 523 },
  { number: 53, nameArabic: 'النجم', nameBangla: 'আন-নাজম', nameEnglish: 'An-Najm', englishTranslation: 'The Star', numberOfAyahs: 62, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 27, pageStart: 526 },
  { number: 54, nameArabic: 'القمر', nameBangla: 'আল-কামার', nameEnglish: 'Al-Qamar', englishTranslation: 'The Moon', numberOfAyahs: 55, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 27, pageStart: 528 },
  { number: 55, nameArabic: 'الرحمن', nameBangla: 'আর-রহমান', nameEnglish: 'Ar-Rahman', englishTranslation: 'The Beneficent', numberOfAyahs: 78, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 27, pageStart: 531 },
  { number: 56, nameArabic: 'الواقعة', nameBangla: 'আল-ওয়াকিয়াহ', nameEnglish: 'Al-Waqi\'ah', englishTranslation: 'The Inevitable', numberOfAyahs: 96, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 27, pageStart: 534 },
  { number: 57, nameArabic: 'الحديد', nameBangla: 'আল-হাদীদ', nameEnglish: 'Al-Hadid', englishTranslation: 'The Iron', numberOfAyahs: 29, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 27, pageStart: 537 },
  { number: 58, nameArabic: 'المجادلة', nameBangla: 'আল-মুজাদালাহ', nameEnglish: 'Al-Mujadila', englishTranslation: 'The Pleading Woman', numberOfAyahs: 22, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 542 },
  { number: 59, nameArabic: 'الحشر', nameBangla: 'আল-হাশর', nameEnglish: 'Al-Hashr', englishTranslation: 'The Exile', numberOfAyahs: 24, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 545 },
  { number: 60, nameArabic: 'الممتحنة', nameBangla: 'আল-মুমতাহিনাহ', nameEnglish: 'Al-Mumtahanah', englishTranslation: 'She that is to be examined', numberOfAyahs: 13, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 549 },
  { number: 61, nameArabic: 'الصف', nameBangla: 'আস-সফ', nameEnglish: 'As-Saff', englishTranslation: 'The Ranks', numberOfAyahs: 14, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 551 },
  { number: 62, nameArabic: 'الجمعة', nameBangla: 'আল-জুমুআহ', nameEnglish: 'Al-Jumu\'ah', englishTranslation: 'The Congregation', numberOfAyahs: 11, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 553 },
  { number: 63, nameArabic: 'المنافقون', nameBangla: 'আল-মুনাফিকুন', nameEnglish: 'Al-Munafiqun', englishTranslation: 'The Hypocrites', numberOfAyahs: 11, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 554 },
  { number: 64, nameArabic: 'التغابن', nameBangla: 'আত-তাগাবুন', nameEnglish: 'At-Taghabun', englishTranslation: 'The Mutual Disillusion', numberOfAyahs: 18, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 556 },
  { number: 65, nameArabic: 'الطلاق', nameBangla: 'আত-ত্বালাক্ব', nameEnglish: 'At-Talaq', englishTranslation: 'The Divorce', numberOfAyahs: 12, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 558 },
  { number: 66, nameArabic: 'التحريم', nameBangla: 'আত-তাহরীম', nameEnglish: 'At-Tahrim', englishTranslation: 'The Prohibition', numberOfAyahs: 12, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 28, pageStart: 560 },
  { number: 67, nameArabic: 'الملك', nameBangla: 'আল-মুলক', nameEnglish: 'Al-Mulk', englishTranslation: 'The Sovereignty', numberOfAyahs: 30, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 562 },
  { number: 68, nameArabic: 'القلم', nameBangla: 'আল-কলম', nameEnglish: 'Al-Qalam', englishTranslation: 'The Pen', numberOfAyahs: 52, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 564 },
  { number: 69, nameArabic: 'الحاقة', nameBangla: 'আল-হাক্কাহ', nameEnglish: 'Al-Haqqah', englishTranslation: 'The Inevitable Reality', numberOfAyahs: 52, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 566 },
  { number: 70, nameArabic: 'المعارج', nameBangla: 'আল-মাআরিজ', nameEnglish: 'Al-Ma\'arij', englishTranslation: 'The Ascending Stairways', numberOfAyahs: 44, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 568 },
  { number: 71, nameArabic: 'نوح', nameBangla: 'নূহ', nameEnglish: 'Nuh', englishTranslation: 'Noah', numberOfAyahs: 28, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 570 },
  { number: 72, nameArabic: 'الجن', nameBangla: 'আল-জ্বিন', nameEnglish: 'Al-Jinn', englishTranslation: 'The Jinn', numberOfAyahs: 28, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 572 },
  { number: 73, nameArabic: 'المزمل', nameBangla: 'আল-মুয্যাম্মিল', nameEnglish: 'Al-Muzzammil', englishTranslation: 'The Enshrouded One', numberOfAyahs: 20, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 574 },
  { number: 74, nameArabic: 'المدثر', nameBangla: 'আল-মুদ্দাসসির', nameEnglish: 'Al-Muddaththir', englishTranslation: 'The Cloaked One', numberOfAyahs: 56, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 575 },
  { number: 75, nameArabic: 'القيامة', nameBangla: 'আল-কিয়ামাহ', nameEnglish: 'Al-Qiyamah', englishTranslation: 'The Resurrection', numberOfAyahs: 40, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 577 },
  { number: 76, nameArabic: 'الإنسان', nameBangla: 'আল-ইনসান', nameEnglish: 'Al-Insan', englishTranslation: 'The Man', numberOfAyahs: 31, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 29, pageStart: 578 },
  { number: 77, nameArabic: 'المرسلات', nameBangla: 'আল-মুরসালাত', nameEnglish: 'Al-Mursalat', englishTranslation: 'The Emissaries', numberOfAyahs: 50, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 29, pageStart: 580 },
  { number: 78, nameArabic: 'النبأ', nameBangla: 'আন-নাবা', nameEnglish: 'An-Naba', englishTranslation: 'The Tidings', numberOfAyahs: 40, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 582 },
  { number: 79, nameArabic: 'النازعات', nameBangla: 'আন-নাযিআত', nameEnglish: 'An-Nazi\'at', englishTranslation: 'Those who drag forth', numberOfAyahs: 46, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 583 },
  { number: 80, nameArabic: 'عبس', nameBangla: 'আবাসা', nameEnglish: '\'Abasa', englishTranslation: 'He Frowned', numberOfAyahs: 42, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 585 },
  { number: 81, nameArabic: 'التكوير', nameBangla: 'আত-তাকবীর', nameEnglish: 'At-Takwir', englishTranslation: 'The Overthrowing', numberOfAyahs: 29, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 586 },
  { number: 82, nameArabic: 'الانفطار', nameBangla: 'আল-ইনফিতার', nameEnglish: 'Al-Infitar', englishTranslation: 'The Cleaving', numberOfAyahs: 19, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 587 },
  { number: 83, nameArabic: 'المطففين', nameBangla: 'আল-মুতাফফিফীন', nameEnglish: 'Al-Mutaffifin', englishTranslation: 'The Defrauding', numberOfAyahs: 36, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 587 },
  { number: 84, nameArabic: 'الانشقاق', nameBangla: 'আল-ইনশিক্বাক্ব', nameEnglish: 'Al-Inshiqaq', englishTranslation: 'The Splitting Asunder', numberOfAyahs: 25, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 589 },
  { number: 85, nameArabic: 'البروج', nameBangla: 'আল-বুরূজ', nameEnglish: 'Al-Buruj', englishTranslation: 'The Mansions of the Stars', numberOfAyahs: 22, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 590 },
  { number: 86, nameArabic: 'الطارق', nameBangla: 'আত-তারিক্ব', nameEnglish: 'At-Tariq', englishTranslation: 'The Morning Star', numberOfAyahs: 17, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 591 },
  { number: 87, nameArabic: 'الأعلى', nameBangla: 'আল-আলা', nameEnglish: 'Al-A\'la', englishTranslation: 'The Most High', numberOfAyahs: 19, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 591 },
  { number: 88, nameArabic: 'الغاشية', nameBangla: 'আল-গাশিয়াহ', nameEnglish: 'Al-Ghashiyah', englishTranslation: 'The Overwhelming', numberOfAyahs: 26, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 592 },
  { number: 89, nameArabic: 'الفجر', nameBangla: 'আল-ফজর', nameEnglish: 'Al-Fajr', englishTranslation: 'The Dawn', numberOfAyahs: 30, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 593 },
  { number: 90, nameArabic: 'البلد', nameBangla: 'আল-বালাদ', nameEnglish: 'Al-Balad', englishTranslation: 'The City', numberOfAyahs: 20, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 594 },
  { number: 91, nameArabic: 'الشمس', nameBangla: 'আশ-শামস', nameEnglish: 'Ash-Shams', englishTranslation: 'The Sun', numberOfAyahs: 15, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 595 },
  { number: 92, nameArabic: 'الليل', nameBangla: 'আল-লায়ল', nameEnglish: 'Al-Layl', englishTranslation: 'The Night', numberOfAyahs: 21, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 595 },
  { number: 93, nameArabic: 'الضحى', nameBangla: 'আদ-দুহা', nameEnglish: 'Ad-Duhaa', englishTranslation: 'The Morning Hours', numberOfAyahs: 11, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 596 },
  { number: 94, nameArabic: 'الشرح', nameBangla: 'আল-ইনশিরাহ', nameEnglish: 'Ash-Sharh', englishTranslation: 'The Relief', numberOfAyahs: 8, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 596 },
  { number: 95, nameArabic: 'التين', nameBangla: 'আত-তীন', nameEnglish: 'At-Tin', englishTranslation: 'The Fig', numberOfAyahs: 8, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 597 },
  { number: 96, nameArabic: 'العلق', nameBangla: 'আল-আলাক্ব', nameEnglish: 'Al-\'Alaq', englishTranslation: 'The Clot', numberOfAyahs: 19, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 597 },
  { number: 97, nameArabic: 'القدر', nameBangla: 'আল-ক্বদর', nameEnglish: 'Al-Qadr', englishTranslation: 'The Power', numberOfAyahs: 5, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 598 },
  { number: 98, nameArabic: 'البينة', nameBangla: 'আল-বাইয়িনাহ', nameEnglish: 'Al-Bayyinah', englishTranslation: 'The Clear Proof', numberOfAyahs: 8, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 30, pageStart: 598 },
  { number: 99, nameArabic: 'الزلزلة', nameBangla: 'আয-যালযালাহ', nameEnglish: 'Az-Zalzalah', englishTranslation: 'The Earthquake', numberOfAyahs: 8, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 30, pageStart: 599 },
  { number: 100, nameArabic: 'العاديات', nameBangla: 'আল-আদিয়াত', nameEnglish: 'Al-\'Adiyat', englishTranslation: 'The Courser', numberOfAyahs: 11, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 599 },
  { number: 101, nameArabic: 'القارعة', nameBangla: 'আল-ক্বারিয়াহ', nameEnglish: 'Al-Qari\'ah', englishTranslation: 'The Calamity', numberOfAyahs: 11, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 600 },
  { number: 102, nameArabic: 'التكاثر', nameBangla: 'আত-তাকাছুর', nameEnglish: 'At-Takathur', englishTranslation: 'The Rivalry in World Increase', numberOfAyahs: 8, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 600 },
  { number: 103, nameArabic: 'العصر', nameBangla: 'আল-আসর', nameEnglish: 'Al-\'Asr', englishTranslation: 'The Declining Day', numberOfAyahs: 3, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 601 },
  { number: 104, nameArabic: 'الهمزة', nameBangla: 'আল-হুমাযাহ', nameEnglish: 'Al-Humazah', englishTranslation: 'The Traducer', numberOfAyahs: 9, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 601 },
  { number: 105, nameArabic: 'الفيل', nameBangla: 'আল-ফীল', nameEnglish: 'Al-Fil', englishTranslation: 'The Elephant', numberOfAyahs: 5, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 601 },
  { number: 106, nameArabic: 'قريش', nameBangla: 'কুরাইশ', nameEnglish: 'Quraysh', englishTranslation: 'Quraysh', numberOfAyahs: 4, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 602 },
  { number: 107, nameArabic: 'الماعون', nameBangla: 'আল-মাউন', nameEnglish: 'Al-Ma\'un', englishTranslation: 'The Small Kindness', numberOfAyahs: 7, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 602 },
  { number: 108, nameArabic: 'الكوثر', nameBangla: 'আল-কাওসার', nameEnglish: 'Al-Kawthar', englishTranslation: 'The Abundance', numberOfAyahs: 3, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 602 },
  { number: 109, nameArabic: 'الكافرون', nameBangla: 'আল-কাফিরুন', nameEnglish: 'Al-Kafirun', englishTranslation: 'The Disbelievers', numberOfAyahs: 6, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 603 },
  { number: 110, nameArabic: 'النصر', nameBangla: 'আন-নাসর', nameEnglish: 'An-Nasr', englishTranslation: 'The Divine Support', numberOfAyahs: 3, revelationType: 'Medinan', revelationTypeBn: 'মাদানী', juzStart: 30, pageStart: 603 },
  { number: 111, nameArabic: 'المسد', nameBangla: 'আল-লাহাব / আল-মাসাদ', nameEnglish: 'Al-Masad', englishTranslation: 'The Palm Fiber', numberOfAyahs: 5, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 603 },
  { number: 112, nameArabic: 'الإخلاص', nameBangla: 'আল-ইখলাস', nameEnglish: 'Al-Ikhlas', englishTranslation: 'The Sincerity', numberOfAyahs: 4, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 604 },
  { number: 113, nameArabic: 'الفلق', nameBangla: 'আল-ফালাক্ব', nameEnglish: 'Al-Falaq', englishTranslation: 'The Daybreak', numberOfAyahs: 5, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 604 },
  { number: 114, nameArabic: 'الناس', nameBangla: 'আন-নাস', nameEnglish: 'An-Nas', englishTranslation: 'Mankind', numberOfAyahs: 6, revelationType: 'Meccan', revelationTypeBn: 'মাক্কী', juzStart: 30, pageStart: 604 },
];

// Offline verified ayah datasets for immediate zero-latency reading with full Tajweed color markup
export const CURATED_SURAH_DATA: Record<number, AyahItem[]> = {
  // Surah 1: Al-Fatihah
  1: [
    {
      numberInSurah: 1,
      numberInQuran: 1,
      textArabic: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      textArabicTajweed: 'بِسْمِ ٱللَّهِ <span class="tajweed-ghunnah">ٱلرَّحْمَٰنِ</span> ٱلرَّحِيمِ',
      transliterationBn: 'বিসমিল্লাহির রাহমানির রাহিম',
      translationBn: 'শুরু করছি আল্লাহর নামে যিনি পরম করুণাময়, অতি দয়ালু।',
      translationEn: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 2,
      numberInQuran: 2,
      textArabic: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ',
      textArabicTajweed: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ',
      transliterationBn: 'আলহামদু লিল্লাহি রাব্বিল আলামীন',
      translationBn: 'সমস্ত প্রশংসা জগৎসমূহের প্রতিপালক আল্লাহর জন্য।',
      translationEn: '[All] praise is [due] to Allah, Lord of the worlds.',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 3,
      numberInQuran: 3,
      textArabic: 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      textArabicTajweed: 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      transliterationBn: 'আর-রাহমানির রাহিম',
      translationBn: 'যিনি পরম করুণাময়, অতি দয়ালু।',
      translationEn: 'The Entirely Merciful, the Especially Merciful,',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 4,
      numberInQuran: 4,
      textArabic: 'مَٰلِكِ يَوْمِ ٱلدِّينِ',
      textArabicTajweed: 'مَٰلِكِ يَوْمِ ٱلدِّينِ',
      transliterationBn: 'মালিকি ইয়াওমিদ্দীন',
      translationBn: 'বিচার দিবসের অধিপতি।',
      translationEn: 'Sovereign of the Day of Recompense.',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 5,
      numberInQuran: 5,
      textArabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
      textArabicTajweed: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
      transliterationBn: 'ইয়্যাকা না’বুদু ওয়া ইয়্যাকা নাস্তাঈন',
      translationBn: 'আমরা কেবল তোমারই ইবাদত করি এবং কেবল তোমারই কাছে সাহায্য প্রার্থনা করি।',
      translationEn: 'It is You we worship and You we ask for help.',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 6,
      numberInQuran: 6,
      textArabic: 'ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ',
      textArabicTajweed: 'ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ',
      transliterationBn: 'ইহদিনাস সিরাতাল মুস্তাক্বীম',
      translationBn: 'আমাদের সরল-সঠিক পথ প্রদর্শন করুন।',
      translationEn: 'Guide us to the straight path -',
      juz: 1,
      page: 1,
    },
    {
      numberInSurah: 7,
      numberInQuran: 7,
      textArabic: 'صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ',
      textArabicTajweed: 'صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا <span class="tajweed-madd">ٱلضَّآلِّينَ</span>',
      transliterationBn: 'সিরাতাল্লাযীনা আনআমতা আলাইহিম, গাইরিল মাগদূবি আলাইহিম ওয়ালাদ্দাল্লীন।',
      translationBn: 'তাদের পথ যাদের ওপর আপনি অনুগ্রহ করেছেন; তাদের পথ নয় যারা ক্রোধে নিপতিত হয়েছে এবং যারা পথভ্রষ্ট হয়েছে।',
      translationEn: 'The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.',
      juz: 1,
      page: 1,
    },
  ],

  // Surah 112: Al-Ikhlas
  112: [
    {
      numberInSurah: 1,
      numberInQuran: 6222,
      textArabic: 'قُلۡ هُوَ ٱللَّهُ أَحَدٌ',
      textArabicTajweed: 'قُلۡ هُوَ ٱللَّهُ <span class="tajweed-qalqalah">أَحَدٌ</span>',
      transliterationBn: 'ক্বুল হুয়াল্লাহু আহাদ',
      translationBn: 'বলুন: তিনিই আল্লাহ, একক ও অদ্বিতীয়।',
      translationEn: 'Say, "He is Allah, [who is] One,',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 2,
      numberInQuran: 6223,
      textArabic: 'ٱللَّهُ ٱلصَّمَدُ',
      textArabicTajweed: 'ٱللَّهُ <span class="tajweed-qalqalah">ٱلصَّمَدُ</span>',
      transliterationBn: 'আল্লাহুস সামাদ',
      translationBn: 'আল্লাহ অমুখাপেক্ষী (সকলের ভরসা)।',
      translationEn: 'Allah, the Eternal Refuge.',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 3,
      numberInQuran: 6224,
      textArabic: 'لَمۡ يَلِدۡ وَلَمۡ يُولَدۡ',
      textArabicTajweed: 'لَمۡ <span class="tajweed-qalqalah">يَلِدۡ</span> وَلَمۡ <span class="tajweed-qalqalah">يُولَدۡ</span>',
      transliterationBn: 'লাম ইয়ালিদ ওয়া লাম ইউলাদ',
      translationBn: 'তিনি কাউকে জন্ম দেননি এবং তাঁকেও কেউ জন্ম দেয়নি।',
      translationEn: 'He neither begets nor is born,',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 4,
      numberInQuran: 6225,
      textArabic: 'وَلَمۡ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ',
      textArabicTajweed: 'وَلَمۡ <span class="tajweed-idgham">يَكُن لَّهُۥ</span> كُفُوًا <span class="tajweed-qalqalah">أَحَدٌۢ</span>',
      transliterationBn: 'ওয়া লাম ইয়াকুল্লাহু কুফুওয়ান আহাদ',
      translationBn: 'এবং তাঁর সমতুল্য কেউই নেই।',
      translationEn: 'Nor is there to Him any equivalent."',
      juz: 30,
      page: 604,
    },
  ],

  // Surah 113: Al-Falaq
  113: [
    {
      numberInSurah: 1,
      numberInQuran: 6226,
      textArabic: 'قُلۡ أَعُوذُ بِرَبِّ ٱلۡفَلَقِ',
      textArabicTajweed: 'قُلۡ أَعُوذُ بِرَبِّ <span class="tajweed-qalqalah">ٱلۡفَلَقِ</span>',
      transliterationBn: 'ক্বুল আ’ঊযু বিরাব্বিল ফালাক্ব',
      translationBn: 'বলুন: আমি আশ্রয় প্রার্থনা করছি প্রভাত-রবের কাছে,',
      translationEn: 'Say, "I seek refuge in the Lord of daybreak',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 2,
      numberInQuran: 6227,
      textArabic: 'مِن شَرِّ مَا خَلَقَ',
      textArabicTajweed: 'مِن <span class="tajweed-ikhfa">شَرِّ</span> مَا <span class="tajweed-qalqalah">خَلَقَ</span>',
      transliterationBn: 'মিন শাররি মা খালাক্ব',
      translationBn: 'তিনি যা সৃষ্টি করেছেন তার অনিষ্ট হতে,',
      translationEn: 'From the evil of that which He created',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 3,
      numberInQuran: 6228,
      textArabic: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ',
      textArabicTajweed: 'وَمِن <span class="tajweed-ikhfa">شَرِّ</span> غَاسِقٍ إِذَا <span class="tajweed-qalqalah">وَقَبَ</span>',
      transliterationBn: 'ওয়া মিন শাররি গাসিক্বিন ইযা ওয়াক্বাব',
      translationBn: 'এবং অন্ধকার রাতের অনিষ্ট হতে যখন তা সমাগত হয়,',
      translationEn: 'And from the evil of darkness when it settles',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 4,
      numberInQuran: 6229,
      textArabic: 'وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلۡعُقَدِ',
      textArabicTajweed: 'وَمِن <span class="tajweed-ikhfa">شَرِّ</span> <span class="tajweed-ghunnah">ٱلنَّفَّٰثَٰتِ</span> فِى <span class="tajweed-qalqalah">ٱلۡعُقَدِ</span>',
      transliterationBn: 'ওয়া মিন শাররিন নাফ্ফাছাতি ফিল ‘উক্বাদ',
      translationBn: 'এবং গ্রন্থিতে ফুঁৎকার প্রদানকারী নারীদের (জাদুকরদের) অনিষ্ট হতে,',
      translationEn: 'And from the evil of the blowers in knots',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 5,
      numberInQuran: 6230,
      textArabic: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
      textArabicTajweed: 'وَمِن <span class="tajweed-ikhfa">شَرِّ</span> حَاسِدٍ إِذَا <span class="tajweed-qalqalah">حَسَدَ</span>',
      transliterationBn: 'ওয়া মিন শাররি হাসিদিন ইযা হাসাদ',
      translationBn: 'এবং হিংসুকের অনিষ্ট হতে যখন সে হিংসা করে।',
      translationEn: 'And from the evil of an envier when he envies."',
      juz: 30,
      page: 604,
    },
  ],

  // Surah 114: An-Nas
  114: [
    {
      numberInSurah: 1,
      numberInQuran: 6231,
      textArabic: 'قُلۡ أَعُوذُ بِرَبِّ ٱلنَّاسِ',
      textArabicTajweed: 'قُلۡ أَعُوذُ بِرَبِّ <span class="tajweed-ghunnah">ٱلنَّاسِ</span>',
      transliterationBn: 'ক্বুল আ’ঊযু বিরাব্বিন নাস',
      translationBn: 'বলুন: আমি আশ্রয় প্রার্থনা করছি মানুষের প্রতিপালকের কাছে,',
      translationEn: 'Say, "I seek refuge in the Lord of mankind,',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 2,
      numberInQuran: 6232,
      textArabic: 'مَلِكِ ٱلنَّاسِ',
      textArabicTajweed: 'مَلِكِ <span class="tajweed-ghunnah">ٱلنَّاسِ</span>',
      transliterationBn: 'মালিকিন নাস',
      translationBn: 'মানুষের অধিপতির কাছে,',
      translationEn: 'The Sovereign of mankind.',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 3,
      numberInQuran: 6233,
      textArabic: 'إِلَٰهِ ٱلنَّاسِ',
      textArabicTajweed: 'إِلَٰهِ <span class="tajweed-ghunnah">ٱلنَّاسِ</span>',
      transliterationBn: 'ইলাহিন নাস',
      translationBn: 'মানুষের প্রকৃত উপাস্যের কাছে,',
      translationEn: 'The God of mankind,',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 4,
      numberInQuran: 6234,
      textArabic: 'مِن شَرِّ ٱلۡوَسۡوَاسِ ٱلۡخَنَّاسِ',
      textArabicTajweed: 'مِن <span class="tajweed-ikhfa">شَرِّ</span> ٱلۡوَسۡوَاسِ <span class="tajweed-ghunnah">ٱلۡخَنَّاسِ</span>',
      transliterationBn: 'মিন শাররিল ওয়াসওয়াসিল খান্নাস',
      translationBn: 'আত্মগোপনকারী কুমন্ত্রণাদাতার অনিষ্ট হতে,',
      translationEn: 'From the evil of the retreating whisperer -',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 5,
      numberInQuran: 6235,
      textArabic: 'ٱلَّذِى يُوَسۡوِسُ فِى صُدُورِ ٱلنَّاسِ',
      textArabicTajweed: 'ٱلَّذِى يُوَسۡوِسُ فِى صُدُورِ <span class="tajweed-ghunnah">ٱلنَّاسِ</span>',
      transliterationBn: 'আল্লাযী ইয়ুওয়াসউইসু ফী সুদূরিন নাস',
      translationBn: 'যে মানুষের অন্তরে কুমন্ত্রণা দেয়,',
      translationEn: 'Who whispers [evil] into the breasts of mankind -',
      juz: 30,
      page: 604,
    },
    {
      numberInSurah: 6,
      numberInQuran: 6236,
      textArabic: 'مِنَ ٱلۡجِنَّةِ وَٱلنَّاسِ',
      textArabicTajweed: 'مِنَ <span class="tajweed-ghunnah">ٱلۡجِنَّةِ</span> <span class="tajweed-ghunnah">وَٱلنَّاسِ</span>',
      transliterationBn: 'মিনাল জিন্নাতি ওয়ান নাস',
      translationBn: 'জ্বিন ও মানুষের মধ্য হতে।',
      translationEn: 'From among the jinn and mankind."',
      juz: 30,
      page: 604,
    },
  ],

  // Surah 108: Al-Kawthar
  108: [
    {
      numberInSurah: 1,
      numberInQuran: 6205,
      textArabic: 'إِنَّآ أَعۡطَيۡنَٰكَ ٱلۡكَوۡثَرَ',
      textArabicTajweed: '<span class="tajweed-ghunnah">إِنَّآ</span> <span class="tajweed-madd">أَعۡطَيۡنَٰكَ</span> ٱلۡكَوۡثَرَ',
      transliterationBn: 'ইন্না আ’তায়নাকাল কাওসার',
      translationBn: 'নিশ্চয়ই আমি আপনাকে কাউসার (প্রভূত কল্যাণ) দান করেছি।',
      translationEn: 'Indeed, We have granted you, [O Muhammad], al-Kawthar.',
      juz: 30,
      page: 602,
    },
    {
      numberInSurah: 2,
      numberInQuran: 6206,
      textArabic: 'فَصَلِّ لِرَبِّكَ وَٱنۡحَرۡ',
      textArabicTajweed: 'فَصَلِّ لِرَبِّكَ <span class="tajweed-qalqalah">وَٱنۡحَرۡ</span>',
      transliterationBn: 'ফাসাল্লি লিরাব্বিকা ওয়ানহার',
      translationBn: 'অতএব আপনি আপনার প্রতিপালকের উদ্দেশ্যে নামাজ পড়ুন এবং কুরবানি করুন।',
      translationEn: 'So pray to your Lord and sacrifice [to Him alone].',
      juz: 30,
      page: 602,
    },
    {
      numberInSurah: 3,
      numberInQuran: 6207,
      textArabic: 'إِنَّ شَانِئَكَ هُوَ ٱلۡأَبۡتَرُ',
      textArabicTajweed: '<span class="tajweed-ghunnah">إِنَّ</span> شَانِئَكَ هُوَ <span class="tajweed-qalqalah">ٱلۡأَبۡتَرُ</span>',
      transliterationBn: 'ইন্না শানি’আকা হুয়াল আবতার',
      translationBn: 'নিশ্চয়ই আপনার শত্রুই তো নির্বংশ, শিকড়হীন।',
      translationEn: 'Indeed, your enemy is the one cut off.',
      juz: 30,
      page: 602,
    },
  ],

  // Surah 103: Al-Asr
  103: [
    {
      numberInSurah: 1,
      numberInQuran: 6177,
      textArabic: 'وَٱلۡعَصۡرِ',
      textArabicTajweed: 'وَٱلۡعَصۡرِ',
      transliterationBn: 'ওয়াল ‘আসর',
      translationBn: 'কালের শপথ,',
      translationEn: 'By time,',
      juz: 30,
      page: 601,
    },
    {
      numberInSurah: 2,
      numberInQuran: 6178,
      textArabic: 'إِنَّ ٱلۡإِنسَٰنَ لَفِى خُسۡرٍ',
      textArabicTajweed: '<span class="tajweed-ghunnah">إِنَّ</span> <span class="tajweed-ikhfa">ٱلۡإِنسَٰنَ</span> لَفِى خُسۡرٍ',
      transliterationBn: 'ইন্নাল ইনসানা লাফী খুসর',
      translationBn: 'নিশ্চয়ই সমগ্র মানবজাতি চরম ক্ষতির মধ্যে নিমজ্জিত;',
      translationEn: 'Indeed, mankind is in loss,',
      juz: 30,
      page: 601,
    },
    {
      numberInSurah: 3,
      numberInQuran: 6179,
      textArabic: 'إِلَّا ٱلَّذِينَ ءَامَنُواْ وَعَمِلُواْ ٱلصَّٰلِحَٰتِ وَتَوَاصَوۡاْ بِٱلۡحَقِّ وَتَوَاصَوۡاْ بِٱلصَّبۡرِ',
      textArabicTajweed: 'إِلَّا ٱلَّذِينَ ءَامَنُواْ وَعَمِلُواْ ٱلصَّٰلِحَٰتِ وَتَوَاصَوۡاْ بِٱلۡحَقِّ وَتَوَاصَوۡاْ بِٱلصَّبۡرِ',
      transliterationBn: 'ইল্লাল্লাযীনা আমানূ ওয়া ‘আমিলুস সালিহাতি ওয়া তাওয়াসাও বিল হাক্কি ওয়া তাওয়াসাও বিস সাবর',
      translationBn: 'তারা ব্যতীত যারা ঈমান এনেছে, সৎকাজ করেছে এবং পরস্পরকে সত্যের উপদেশ ও ধৈর্যের উপদেশ দিয়েছে।',
      translationEn: 'Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience.',
      juz: 30,
      page: 601,
    },
  ],

  // Surah 67: Al-Mulk (First 5 sample verses with Tajweed)
  67: [
    {
      numberInSurah: 1,
      numberInQuran: 5242,
      textArabic: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
      textArabicTajweed: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ <span class="tajweed-ikhfa">قَدِيرٌ</span>',
      transliterationBn: 'তাবারাকাল্লাযী বিয়াদিহিল মুলকু ওয়াহুওয়া আলা কুল্লি শাইয়িন ক্বাদীর',
      translationBn: 'বরকতময় তিনি যাঁর হাতে সমগ্র রাজত্ব, এবং তিনি সকল বিষয়ের ওপর সর্বশক্তিমান।',
      translationEn: 'Blessed is He in whose hand is dominion, and He is over all things competent -',
      juz: 29,
      page: 562,
    },
    {
      numberInSurah: 2,
      numberInQuran: 5243,
      textArabic: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ',
      textArabicTajweed: 'الَّذِي <span class="tajweed-qalqalah">خَلَقَ</span> الْمَوْتَ وَالْحَيَاةَ <span class="tajweed-qalqalah">لِيَبْلُوَكُمْ</span> أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ',
      transliterationBn: 'আল্লাযী খালাক্বাল মাওতা ওয়াল হায়াতা লিইয়াবলুয়াকুম আইয়্যুকুম আহসানু আমালা, ওয়াহুয়াল আযীযুল গাফূর',
      translationBn: 'যিনি সৃষ্টি করেছেন মৃত্যু ও জীবন, তোমাদের পরীক্ষা করার জন্য যে তোমাদের মধ্যে কর্মে কে শ্রেষ্ঠ। আর তিনি পরাক্রমশালী, ক্ষমাশীল।',
      translationEn: '[He] who created death and life to test you [as to] which of you is best in deed - and He is the Exalted in Might, the Forgiving -',
      juz: 29,
      page: 562,
    },
    {
      numberInSurah: 3,
      numberInQuran: 5244,
      textArabic: 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ',
      textArabicTajweed: 'الَّذِي <span class="tajweed-qalqalah">خَلَقَ</span> <span class="tajweed-qalqalah">سَبْعَ</span> سَمَاوَاتٍ <span class="tajweed-ikhfa">طِبَاقًا</span> ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ <span class="tajweed-ikhfa">مِن تَفَاوُتٍ</span>',
      transliterationBn: 'আল্লাযী খালাক্বা সাবআ সামাওয়া-তিন তিবা-ক্বা, মা তারা ফী খালক্বির রাহমা-নি মিন তাফা-উত',
      translationBn: 'যিনি সপ্ত আকাশ স্তরে স্তরে সৃষ্টি করেছেন। পরম করুণাময়ের সৃষ্টিতে আপনি কোনো অসামঞ্জস্য দেখতে পাবেন না।',
      translationEn: '[And] who created seven heavens in layers. You do not see in the creation of the Most Merciful any inconsistency.',
      juz: 29,
      page: 562,
    },
  ],
};

// Asynchronous loader for fetching any of the 114 Surahs from open Quran API with caching
const SURAH_CACHE = new Map<number, AyahItem[]>();

export async function fetchSurahAyahs(surahNumber: number): Promise<AyahItem[]> {
  // If in curated offline dataset, return immediately
  if (CURATED_SURAH_DATA[surahNumber]) {
    return CURATED_SURAH_DATA[surahNumber];
  }

  // If in memory cache, return
  if (SURAH_CACHE.has(surahNumber)) {
    return SURAH_CACHE.get(surahNumber)!;
  }

  try {
    // Fetch authentic Madinah Mushaf Arabic text with COMPLETE Tashkeel & Harakat (quran-uthmani),
    // English transliteration (en.transliteration), Bengali translation (bn.bengali) and English translation (en.sahih)
    const resp = await fetch(
      `https://api.alquran.cloud/v1/surah/${surahNumber}/editions/quran-uthmani,en.transliteration,bn.bengali,en.sahih`
    );
    if (!resp.ok) throw new Error('Failed to fetch surah data');
    const json = await resp.json();
    
    if (json.data && Array.isArray(json.data) && json.data.length >= 3) {
      const arabicAyahs = json.data[0].ayahs;
      const transliterationAyahs = json.data[1].ayahs;
      const bengaliAyahs = json.data[2].ayahs;
      const englishAyahs = json.data[3]?.ayahs || [];

      const items: AyahItem[] = arabicAyahs.map((ar: { numberInSurah: number; number: number; text: string; juz: number; page: number; sajdah: boolean }, idx: number) => {
        let textAr = normalizeArabicWithCompleteTashkeel(ar.text);
        let rawTransliteration = transliterationAyahs[idx]?.text || '';

        // For Surahs 2-114, strip repeated Bismillah prefix from Ayah 1 (as Bismillah header is already shown above)
        if (surahNumber !== 1 && idx === 0) {
          textAr = textAr.replace(/^بِسْمِ\s*ٱللَّهِ\s*ٱلرَّحْمَٰنِ\s*ٱلرَّحِيمِ\s*/, '');
          textAr = textAr.replace(/^بِسْمِ\s*اللَّهِ\s*الرَّحْمَٰنِ\s*الرَّحِيمِ\s*/, '');
          rawTransliteration = rawTransliteration.replace(/^Bismillaahir[ -]Rahmaanir[ -]Raheem\s*/i, '');
          rawTransliteration = rawTransliteration.replace(/^Bismil-laahir[ -]Rahmaanir[ -]Raheem\s*/i, '');
        }

        // Generate authentic, pristine Bengali pronunciation with full vocalization
        const bnPronunciation = getBengaliPronunciation(
          surahNumber,
          ar.numberInSurah,
          textAr,
          rawTransliteration
        );

        // Precise automatic Tajweed markup parser:
        // Highlights nun/meem shaddah (ghunnah), qalqalah letters with sukun, madd
        // Note: Keep base character with combining diacritics attached together so font rendering is never broken
        const tajweedAr = textAr
          .replace(/(إِنَّ|أَنَّ|ثُمَّ|عَمَّ|مِّن|مَّآ|[نم][َّّ])/g, '<span class="tajweed-ghunnah">$1</span>')
          .replace(/([قطبجد][ْۡ])/g, '<span class="tajweed-qalqalah">$1</span>')
          .replace(/([ء-يٱ-ۓ][\u064B-\u065F\u0670]?[\u0653\u06E4]|آ|ۤ)/g, '<span class="tajweed-madd">$1</span>');

        return {
          numberInSurah: ar.numberInSurah,
          numberInQuran: ar.number,
          textArabic: textAr,
          textArabicTajweed: tajweedAr,
          transliterationBn: bnPronunciation,
          translationBn: bengaliAyahs[idx]?.text || '',
          translationEn: englishAyahs[idx]?.text || '',
          juz: ar.juz,
          page: ar.page,
          isSajdah: !!ar.sajdah,
        };
      });

      SURAH_CACHE.set(surahNumber, items);
      return items;
    }
  } catch (err) {
    console.warn(`Could not fetch live surah ${surahNumber}:`, err);
  }

  // Fallback to sample or basic representation
  const meta = SURAH_LIST.find(s => s.number === surahNumber);
  const fallbackAyahs: AyahItem[] = [
    {
      numberInSurah: 1,
      numberInQuran: surahNumber * 10,
      textArabic: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      textArabicTajweed: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      transliterationBn: 'বিসমিল্লাহির রাহমানির রাহিম',
      translationBn: 'শুরু করছি আল্লাহর নামে যিনি পরম করুণাময়, অতি দয়ালু।',
      translationEn: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.',
      juz: meta?.juzStart || 1,
      page: meta?.pageStart || 1,
    }
  ];
  return fallbackAyahs;
}
