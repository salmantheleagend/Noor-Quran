/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AppLanguage,
  AppTheme,
  LocationInfo,
  UserPreferences,
  PrayerTimesData,
  ArabicFontFamily,
} from './types';
import { DEFAULT_LOCATION } from './data/districtsBD';
import { calculatePrayerTimes } from './utils/prayerTimes';
import { Header } from './components/Header';
import { BottomNav, MainTabType } from './components/BottomNav';
import { HomeDashboard } from './components/HomeDashboard';
import { QuranReader } from './components/QuranReader';
import { PrayerSchedule } from './components/PrayerSchedule';
import { SalahGuide } from './components/SalahGuide';
import { DuaAzkar } from './components/DuaAzkar';
import { TasbeehCounter } from './components/TasbeehCounter';
import { QaidaLearning } from './components/QaidaLearning';
import { HadithSection } from './components/HadithSection';
import { QiblaCompass } from './components/QiblaCompass';
import { PeriodTracker } from './components/PeriodTracker';
import { MasalaSection } from './components/MasalaSection';
import { CharitySection } from './components/CharitySection';
import { RuqyahHome } from './components/RuqyahHome';
import { MoreMenu } from './components/MoreMenu';
import { LocationModal } from './components/LocationModal';
import { SettingsModal } from './components/SettingsModal';
import { OnboardingModal } from './components/OnboardingModal';

const PREFERENCES_KEY = 'noor_quran_user_preferences_v1';

export default function App() {
  // Load preferences or initialize default
  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem(PREFERENCES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure pronunciation is ON by default
        if (parsed.showTransliteration === undefined) {
          parsed.showTransliteration = true;
        }
        return parsed;
      }
    } catch {
      // ignore
    }
    return {
      language: 'bn',
      theme: 'light',
      location: DEFAULT_LOCATION,
      calculationMethod: 'IFB',
      asrMethod: 'hanafi',
      ramadanMode: false,
      fontSizeArabic: 28,
      fontSizeBengali: 15,
      arabicFont: (typeof window !== 'undefined' ? (localStorage.getItem('noor_quran_user_arabic_font') as ArabicFontFamily) : null) || 'amiri-quran',
      showTransliteration: true,
      showEnglishTranslation: false,
      showTajweedColors: true,
      selectedReciter: 'alafasy',
      soundEnabled: true,
      vibrationEnabled: true,
      bookmarks: [1, 67, 112],
      favoriteAyahs: [],
      favoriteDuas: ['sayyidul_istighfar'],
      favoriteHadiths: ['hadith_niyyah'],
      tasbeehCounts: { subhanallah: 33, alhamdulillah: 33, allahuakbar: 34 },
      activeTasbeehDhikr: 'subhanallah',
      dailyAmalChecklist: {},
      onboardingCompleted: true, // will trigger if false
    };
  });

  // Current view tab (Default opens on Home screen with Namazer Waqt mode as requested)
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [activeSurahToOpen, setActiveSurahToOpen] = useState<number | undefined>(1);

  // Modals
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Synchronize Preferences to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(PREFERENCES_KEY, JSON.stringify(preferences));
    } catch (e) {
      console.warn('Failed to save preferences to localStorage', e);
    }
  }, [preferences]);

  // Apply Theme to document HTML root
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark', 'theme-amoled');
    if (preferences.theme === 'dark') {
      root.classList.add('dark');
    } else if (preferences.theme === 'amoled') {
      root.classList.add('dark', 'theme-amoled');
    }
  }, [preferences.theme]);

  // Calculate Astronomical Prayer Times for current date & location
  const prayerTimes: PrayerTimesData = calculatePrayerTimes(
    new Date(),
    preferences.location,
    preferences.calculationMethod,
    preferences.asrMethod
  );

  // Handlers
  const handleUpdatePreferences = (partial: Partial<UserPreferences>) => {
    if (partial.arabicFont && typeof window !== 'undefined') {
      try {
        localStorage.setItem('noor_quran_user_arabic_font', partial.arabicFont);
      } catch {
        // ignore
      }
    }
    setPreferences(prev => ({
      ...prev,
      ...partial,
    }));
  };

  const handleToggleTheme = () => {
    const nextTheme: AppTheme =
      preferences.theme === 'light'
        ? 'dark'
        : preferences.theme === 'dark'
        ? 'amoled'
        : 'light';
    handleUpdatePreferences({ theme: nextTheme });
  };

  const handleToggleBookmark = (surahNum: number) => {
    const exists = preferences.bookmarks.includes(surahNum);
    const updated = exists
      ? preferences.bookmarks.filter(b => b !== surahNum)
      : [...preferences.bookmarks, surahNum];
    handleUpdatePreferences({ bookmarks: updated });
  };

  const handleToggleFavoriteDua = (duaId: string) => {
    const exists = preferences.favoriteDuas.includes(duaId);
    const updated = exists
      ? preferences.favoriteDuas.filter(d => d !== duaId)
      : [...preferences.favoriteDuas, duaId];
    handleUpdatePreferences({ favoriteDuas: updated });
  };

  const handleToggleFavoriteHadith = (hadithId: string) => {
    const exists = preferences.favoriteHadiths.includes(hadithId);
    const updated = exists
      ? preferences.favoriteHadiths.filter(h => h !== hadithId)
      : [...preferences.favoriteHadiths, hadithId];
    handleUpdatePreferences({ favoriteHadiths: updated });
  };

  const handleToggleAmalHabit = (habitId: string) => {
    const updated = {
      ...preferences.dailyAmalChecklist,
      [habitId]: !preferences.dailyAmalChecklist[habitId],
    };
    handleUpdatePreferences({ dailyAmalChecklist: updated });
  };

  const handleUpdateTasbeehCount = (dhikrId: string, count: number) => {
    const updated = {
      ...preferences.tasbeehCounts,
      [dhikrId]: count,
    };
    handleUpdatePreferences({ tasbeehCounts: updated });
  };

  const handleNavigate = (tab: string, extra?: unknown) => {
    if (tab === 'quran' && typeof extra === 'number') {
      setActiveSurahToOpen(extra);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetAllData = () => {
    localStorage.clear();
    setPreferences({
      language: 'bn',
      theme: 'light',
      location: DEFAULT_LOCATION,
      calculationMethod: 'IFB',
      asrMethod: 'hanafi',
      ramadanMode: false,
      fontSizeArabic: 28,
      fontSizeBengali: 15,
      showTransliteration: true,
      showEnglishTranslation: false,
      showTajweedColors: true,
      selectedReciter: 'alafasy',
      soundEnabled: true,
      vibrationEnabled: true,
      bookmarks: [1, 67, 112],
      favoriteAyahs: [],
      favoriteDuas: ['sayyidul_istighfar'],
      favoriteHadiths: ['hadith_niyyah'],
      tasbeehCounts: { subhanallah: 33, alhamdulillah: 33, allahuakbar: 34 },
      activeTasbeehDhikr: 'subhanallah',
      dailyAmalChecklist: {},
      onboardingCompleted: true,
    });
    setCurrentTab('home');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Header */}
      <Header
        language={preferences.language}
        theme={preferences.theme}
        location={preferences.location}
        onOpenLocationModal={() => setIsLocationModalOpen(true)}
        onToggleTheme={handleToggleTheme}
        onChangeLanguage={(lang) => handleUpdatePreferences({ language: lang })}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-1 sm:px-2 pt-2">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="w-full"
          >
            {currentTab === 'home' && (
              <HomeDashboard
                language={preferences.language}
                location={preferences.location}
                prayerTimes={prayerTimes}
                onNavigate={handleNavigate}
                onOpenLocationModal={() => setIsLocationModalOpen(true)}
                ramadanMode={preferences.ramadanMode}
                onToggleRamadanMode={() =>
                  handleUpdatePreferences({ ramadanMode: !preferences.ramadanMode })
                }
              />
            )}

            {currentTab === 'quran' && (
              <QuranReader
                language={preferences.language}
                arabicFontSize={preferences.fontSizeArabic}
                bengaliFontSize={preferences.fontSizeBengali}
                arabicFont={preferences.arabicFont || 'amiri-quran'}
                showTajweed={preferences.showTajweedColors}
                showTransliteration={preferences.showTransliteration}
                showEnglishTranslation={preferences.showEnglishTranslation}
                selectedReciter={preferences.selectedReciter}
                bookmarks={preferences.bookmarks}
                onToggleBookmark={handleToggleBookmark}
                onUpdateFontSize={(ar, bn) =>
                  handleUpdatePreferences({ fontSizeArabic: ar, fontSizeBengali: bn })
                }
                onChangeArabicFont={(font) =>
                  handleUpdatePreferences({ arabicFont: font })
                }
                onToggleTajweed={() =>
                  handleUpdatePreferences({ showTajweedColors: !preferences.showTajweedColors })
                }
                onToggleTransliteration={() =>
                  handleUpdatePreferences({
                    showTransliteration: !preferences.showTransliteration,
                  })
                }
                onToggleEnglish={() =>
                  handleUpdatePreferences({
                    showEnglishTranslation: !preferences.showEnglishTranslation,
                  })
                }
                onChangeReciter={(reciterId) =>
                  handleUpdatePreferences({ selectedReciter: reciterId })
                }
                initialSurah={activeSurahToOpen}
                onOpenProfile={() => setIsSettingsModalOpen(true)}
              />
            )}

            {currentTab === 'search' && (
              <QuranReader
                language={preferences.language}
                arabicFontSize={preferences.fontSizeArabic}
                bengaliFontSize={preferences.fontSizeBengali}
                arabicFont={preferences.arabicFont || 'amiri-quran'}
                showTajweed={preferences.showTajweedColors}
                showTransliteration={preferences.showTransliteration}
                showEnglishTranslation={preferences.showEnglishTranslation}
                selectedReciter={preferences.selectedReciter}
                bookmarks={preferences.bookmarks}
                onToggleBookmark={handleToggleBookmark}
                onUpdateFontSize={(ar, bn) =>
                  handleUpdatePreferences({ fontSizeArabic: ar, fontSizeBengali: bn })
                }
                onChangeArabicFont={(font) =>
                  handleUpdatePreferences({ arabicFont: font })
                }
                onToggleTajweed={() =>
                  handleUpdatePreferences({ showTajweedColors: !preferences.showTajweedColors })
                }
                onToggleTransliteration={() =>
                  handleUpdatePreferences({
                    showTransliteration: !preferences.showTransliteration,
                  })
                }
                onToggleEnglish={() =>
                  handleUpdatePreferences({
                    showEnglishTranslation: !preferences.showEnglishTranslation,
                  })
                }
                onChangeReciter={(reciterId) =>
                  handleUpdatePreferences({ selectedReciter: reciterId })
                }
                initialSurah={activeSurahToOpen}
                initialSearchOpen={true}
                onOpenProfile={() => setIsSettingsModalOpen(true)}
              />
            )}

            {currentTab === 'prayer' && (
              <PrayerSchedule
                language={preferences.language}
                location={preferences.location}
                prayerTimes={prayerTimes}
                calculationMethod={preferences.calculationMethod}
                asrMethod={preferences.asrMethod}
                onChangeCalculationMethod={(method) =>
                  handleUpdatePreferences({ calculationMethod: method })
                }
                onChangeAsrMethod={(asr) => handleUpdatePreferences({ asrMethod: asr })}
                onOpenLocationModal={() => setIsLocationModalOpen(true)}
                ramadanMode={preferences.ramadanMode}
                onToggleRamadanMode={() =>
                  handleUpdatePreferences({ ramadanMode: !preferences.ramadanMode })
                }
              />
            )}

            {currentTab === 'dua' && (
              <DuaAzkar
                language={preferences.language}
                dailyAmalChecklist={preferences.dailyAmalChecklist}
                onToggleAmalHabit={handleToggleAmalHabit}
                favoriteDuas={preferences.favoriteDuas}
                onToggleFavoriteDua={handleToggleFavoriteDua}
              />
            )}

            {currentTab === 'tasbeeh' && (
              <TasbeehCounter
                language={preferences.language}
                activeTasbeehDhikr={preferences.activeTasbeehDhikr}
                onChangeDhikr={(dhikrId) =>
                  handleUpdatePreferences({ activeTasbeehDhikr: dhikrId })
                }
                tasbeehCounts={preferences.tasbeehCounts}
                onUpdateCount={handleUpdateTasbeehCount}
                soundEnabled={preferences.soundEnabled}
                vibrationEnabled={preferences.vibrationEnabled}
              />
            )}

            {currentTab === 'qaida' && (
              <QaidaLearning
                language={preferences.language}
                onOpenSurah={(surahNum) => handleNavigate('quran', surahNum)}
              />
            )}

            {currentTab === 'salahGuide' && (
              <SalahGuide language={preferences.language} />
            )}

            {currentTab === 'hadith' && (
              <HadithSection
                language={preferences.language}
                favoriteHadiths={preferences.favoriteHadiths}
                onToggleFavoriteHadith={handleToggleFavoriteHadith}
              />
            )}

            {currentTab === 'qibla' && (
              <QiblaCompass
                language={preferences.language}
                location={preferences.location}
              />
            )}

            {currentTab === 'tracker' && (
              <PeriodTracker language={preferences.language} />
            )}

            {currentTab === 'masala' && (
              <MasalaSection language={preferences.language} />
            )}

            {currentTab === 'charity' && (
              <CharitySection
                language={preferences.language}
                onBack={() => handleNavigate('more')}
              />
            )}

            {currentTab === 'ruqyah' && (
              <RuqyahHome
                language={preferences.language}
                onBack={() => handleNavigate('home')}
                onOpenSettings={() => setIsSettingsModalOpen(true)}
              />
            )}

            {currentTab === 'more' && (
              <MoreMenu
                language={preferences.language}
                onSelectFeature={(featId) => handleNavigate(featId)}
                onOpenSettings={() => setIsSettingsModalOpen(true)}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Ergonomic Bottom Navigation Bar */}
      <BottomNav
        currentTab={currentTab}
        onChangeTab={(tab) => handleNavigate(tab)}
        language={preferences.language}
      />

      {/* Location Picker Modal */}
      {isLocationModalOpen && (
        <LocationModal
          language={preferences.language}
          currentLocation={preferences.location}
          onSelectLocation={(loc) => handleUpdatePreferences({ location: loc })}
          onClose={() => setIsLocationModalOpen(false)}
        />
      )}

      {/* Settings Modal */}
      {isSettingsModalOpen && (
        <SettingsModal
          language={preferences.language}
          theme={preferences.theme}
          preferences={preferences}
          onClose={() => setIsSettingsModalOpen(false)}
          onChangeLanguage={(lang) => handleUpdatePreferences({ language: lang })}
          onChangeTheme={(th) => handleUpdatePreferences({ theme: th })}
          onUpdatePreferences={handleUpdatePreferences}
          onResetAllData={handleResetAllData}
        />
      )}

      {/* First-time Onboarding Modal */}
      {!preferences.onboardingCompleted && (
        <OnboardingModal
          onComplete={(updates) => handleUpdatePreferences(updates)}
        />
      )}
    </div>
  );
}
