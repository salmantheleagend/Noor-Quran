import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { QAIDA_LESSONS } from '../data/qaidaData';
import { SURAH_LIST } from '../data/quranData';
import {
  Volume2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  Sparkles,
  BookOpen,
  GraduationCap,
} from 'lucide-react';
import { speakArabic, triggerHaptic } from '../utils/audioPlayer';

interface QaidaLearningProps {
  language: AppLanguage;
  onOpenSurah: (surahNumber: number) => void;
}

export const QaidaLearning: React.FC<QaidaLearningProps> = ({
  language,
  onOpenSurah,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'qaida' | 'ampara'>('qaida');
  const [activeLessonId, setActiveLessonId] = useState<number>(1);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [showQuizResult, setShowQuizResult] = useState(false);

  const activeLesson = QAIDA_LESSONS.find(l => l.id === activeLessonId) || QAIDA_LESSONS[0];

  const handleSpeakLetter = (arabicText: string) => {
    triggerHaptic(15);
    speakArabic(arabicText);
  };

  const handleSelectQuizOption = (questionIdx: number, optionIdx: number) => {
    triggerHaptic(15);
    setQuizAnswers(prev => ({
      ...prev,
      [questionIdx]: optionIdx,
    }));
  };

  // Juz 30 / Ampara Surahs (Surah 78 to 114)
  const amparaSurahs = SURAH_LIST.filter(s => s.juzStart === 30);

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.qaidaTitle}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {t.qaidaSubtitle}
        </p>
      </div>

      {/* Tabs: Qaida vs Ampara */}
      <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-medium">
        <button
          onClick={() => setActiveTab('qaida')}
          className={`py-2 rounded-xl transition-all ${
            activeTab === 'qaida'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          নূরানী কায়দা পাঠ (১-৭)
        </button>
        <button
          onClick={() => setActiveTab('ampara')}
          className={`py-2 rounded-xl transition-all ${
            activeTab === 'ampara'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          ৩০তম পারা (আমপারা)
        </button>
      </div>

      {/* QAIDA LESSONS VIEW */}
      {activeTab === 'qaida' && (
        <div className="space-y-4">
          {/* Lesson Selector Carousel */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {QAIDA_LESSONS.map((lesson) => (
              <button
                key={lesson.id}
                onClick={() => {
                  triggerHaptic(15);
                  setActiveLessonId(lesson.id);
                  setQuizAnswers({});
                  setShowQuizResult(false);
                }}
                className={`px-3 py-1.5 rounded-full shrink-0 font-medium transition-colors ${
                  activeLessonId === lesson.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                পাঠ {lesson.id}
              </button>
            ))}
          </div>

          {/* Active Lesson Header & Explanation */}
          <div className="p-4 rounded-3xl bg-linear-to-r from-emerald-800 to-teal-900 text-white shadow-md space-y-2 border border-emerald-700/50">
            <span className="text-[11px] text-emerald-200 uppercase tracking-widest font-semibold block">
              {activeLesson.titleAr}
            </span>
            <h3 className="text-base font-bold">
              {activeLesson.titleBn}
            </h3>
            <p className="text-xs text-emerald-100/90 leading-relaxed font-bengali">
              {activeLesson.descriptionBn}
            </p>
            <div className="p-2.5 rounded-xl bg-black/20 border border-white/10 text-[11px] text-amber-200 mt-2">
              <strong>নিয়ম:</strong> {activeLesson.ruleBn}
            </div>
          </div>

          {/* Interactive Letter / Word Cards Grid */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 block px-1">
              উচ্চারণ শুনতে হরফের ওপর স্পর্শ করুন:
            </span>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
              {activeLesson.items.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSpeakLetter(item.letterAr)}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs transition-all active:scale-95 flex flex-col items-center justify-center group"
                >
                  <span className="font-arabic text-3xl font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors">
                    {item.letterAr}
                  </span>
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400 mt-1">
                    {item.transliterationBn}
                  </span>
                  <div className="w-5 h-5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center mt-1">
                    <Volume2 className="w-3 h-3" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Lesson Quiz */}
          {activeLesson.quiz && activeLesson.quiz.length > 0 && (
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
                <HelpCircle className="w-4 h-4 text-emerald-600" />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                  পাঠ অনুশীলন ও ছোট কুইজ
                </h4>
              </div>

              <div className="space-y-3">
                {activeLesson.quiz.map((q, qIdx) => {
                  const selectedOpt = quizAnswers[qIdx];
                  const isAnswered = selectedOpt !== undefined;
                  const isCorrect = isAnswered && selectedOpt === q.correctIndex;

                  return (
                    <div key={qIdx} className="space-y-2 text-xs">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">
                        {qIdx + 1}. {q.question}
                      </p>

                      <div className="grid grid-cols-2 gap-1.5">
                        {q.options.map((opt, optIdx) => {
                          const isOptionSelected = selectedOpt === optIdx;
                          let btnStyle = 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300';
                          if (isAnswered) {
                            if (optIdx === q.correctIndex) {
                              btnStyle = 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold';
                            } else if (isOptionSelected) {
                              btnStyle = 'bg-rose-100 dark:bg-rose-950/80 border-rose-500 text-rose-900 dark:text-rose-200';
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectQuizOption(qIdx, optIdx)}
                              className={`p-2 rounded-xl border text-left transition-colors ${btnStyle}`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Lesson Navigation Buttons */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => {
                if (activeLessonId > 1) {
                  triggerHaptic(15);
                  setActiveLessonId(activeLessonId - 1);
                }
              }}
              disabled={activeLessonId === 1}
              className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 disabled:opacity-40 flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>{t.prevLesson}</span>
            </button>

            <button
              onClick={() => {
                if (activeLessonId < QAIDA_LESSONS.length) {
                  triggerHaptic(15);
                  setActiveLessonId(activeLessonId + 1);
                }
              }}
              disabled={activeLessonId === QAIDA_LESSONS.length}
              className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 disabled:opacity-40 flex items-center gap-1"
            >
              <span>{t.nextLesson}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* AMPARA (JUZ 30) VIEW */}
      {activeTab === 'ampara' && (
        <div className="space-y-3">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl text-xs text-emerald-900 dark:text-emerald-300">
            <strong>সম্পূর্ণ ৩০তম পারা (আমপারা):</strong> শিশু ও নতুন শিক্ষার্থীদের নিয়মিত আমপারা পড়ার জন্য সূরা নাবা থেকে সূরা নাস পর্যন্ত মোট ৩৭টি সূরা সংকলিত।
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {amparaSurahs.map((surah) => (
              <div
                key={surah.number}
                onClick={() => {
                  triggerHaptic(15);
                  onOpenSurah(surah.number);
                }}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 hover:bg-emerald-50/60 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between cursor-pointer transition-all active:scale-[0.98]"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center justify-center font-mono">
                    {surah.number}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {surah.nameBangla}
                    </h4>
                    <span className="text-[10px] text-slate-500">
                      {surah.numberOfAyahs} আয়াত · {surah.revelationTypeBn}
                    </span>
                  </div>
                </div>

                <span className="font-arabic text-base font-bold text-emerald-800 dark:text-emerald-300">
                  {surah.nameArabic}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
