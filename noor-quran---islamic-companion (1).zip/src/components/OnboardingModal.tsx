import React, { useState } from 'react';
import { AppLanguage, LocationInfo, UserPreferences } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { BD_DISTRICTS } from '../data/districtsBD';
import {
  Sparkles,
  MapPin,
  Globe,
  Clock,
  Shield,
  Check,
  ChevronRight,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface OnboardingModalProps {
  onComplete: (prefs: Partial<UserPreferences>) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete }) => {
  const [step, setStep] = useState<number>(1);
  const [language, setLanguage] = useState<AppLanguage>('bn');
  const [selectedLocation, setSelectedLocation] = useState<LocationInfo>(BD_DISTRICTS[0]);
  const [asrMethod, setAsrMethod] = useState<'hanafi' | 'standard'>('hanafi');

  const handleNext = () => {
    triggerHaptic(20);
    if (step < 3) {
      setStep(step + 1);
    } else {
      onComplete({
        language,
        location: selectedLocation,
        asrMethod,
        onboardingCompleted: true,
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-6 space-y-5 border border-slate-200 dark:border-slate-800 shadow-2xl text-center">
        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-1.5">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                s === step
                  ? 'w-8 bg-emerald-600'
                  : s < step
                  ? 'w-4 bg-emerald-400'
                  : 'w-2 bg-slate-200 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* STEP 1: WELCOME & LANGUAGE */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto text-3xl font-arabic font-bold shadow-lg shadow-emerald-700/30">
              ن
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                নূর কুরআন-এ স্বাগতম
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                আপনার পছন্দের ভাষা নির্বাচন করুন
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2 pt-2">
              <button
                onClick={() => setLanguage('bn')}
                className={`p-3 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-colors ${
                  language === 'bn'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <span>বাংলা (Bengali)</span>
                {language === 'bn' && <Check className="w-4 h-4 text-emerald-600" />}
              </button>

              <button
                onClick={() => setLanguage('ar')}
                className={`p-3 rounded-2xl border text-sm font-arabic font-semibold flex items-center justify-between transition-colors ${
                  language === 'ar'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <span>العربية (Arabic)</span>
                {language === 'ar' && <Check className="w-4 h-4 text-emerald-600" />}
              </button>

              <button
                onClick={() => setLanguage('en')}
                className={`p-3 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-colors ${
                  language === 'en'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <span>English (International)</span>
                {language === 'en' && <Check className="w-4 h-4 text-emerald-600" />}
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: LOCATION */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto shadow-xs">
              <MapPin className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                আপনার জেলা বা শহর
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                সঠিক নামাজের সময় ও সাহরি-ইফতারের জন্য লোকেশন নির্বাচন করুন
              </p>
            </div>

            <div className="text-left space-y-1">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                জেলা নির্বাচন:
              </label>
              <select
                value={selectedLocation.name}
                onChange={(e) => {
                  const loc = BD_DISTRICTS.find(d => d.name === e.target.value);
                  if (loc) setSelectedLocation(loc);
                }}
                className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-800 dark:text-slate-100"
              >
                {BD_DISTRICTS.map((d) => (
                  <option key={d.name} value={d.name}>
                    {d.nameBn} ({d.name})
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* STEP 3: PREFERENCES & START */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto shadow-xs">
              <Sparkles className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                নামাজের হিসাব পদ্ধতি
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                আসরের ওয়াক্ত শুরুর নিয়ম নির্বাচন করুন
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2 pt-1 text-left">
              <button
                onClick={() => setAsrMethod('hanafi')}
                className={`p-3 rounded-2xl border text-xs font-semibold flex items-center justify-between transition-colors ${
                  asrMethod === 'hanafi'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div>
                  <span className="font-bold block">হানাফী মাযহাব (দ্বিগুণ ছায়া)</span>
                  <span className="text-[10px] text-slate-500">বাংলাদেশ ও দক্ষিণ এশিয়ায় বহুল প্রচলিত</span>
                </div>
                {asrMethod === 'hanafi' && <Check className="w-4 h-4 text-emerald-600" />}
              </button>

              <button
                onClick={() => setAsrMethod('standard')}
                className={`p-3 rounded-2xl border text-xs font-semibold flex items-center justify-between transition-colors ${
                  asrMethod === 'standard'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div>
                  <span className="font-bold block">শাফেঈ / সাধারণ (একগুণ ছায়া)</span>
                  <span className="text-[10px] text-slate-500">জমহুর ও আরব বিশ্বে প্রচলিত</span>
                </div>
                {asrMethod === 'standard' && <Check className="w-4 h-4 text-emerald-600" />}
              </button>
            </div>
          </div>
        )}

        {/* CTA Button */}
        <button
          onClick={handleNext}
          className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-700/20 flex items-center justify-center gap-1.5 transition-colors"
        >
          <span>{step === 3 ? 'অ্যাপ শুরু করুন' : 'পরবর্তী ধাপ'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
