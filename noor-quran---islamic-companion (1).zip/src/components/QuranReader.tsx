import React, { useState, useEffect, useRef, useMemo } from 'react';
import { AppLanguage, SurahMeta, AyahItem, ArabicFontFamily } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { SURAH_LIST, fetchSurahAyahs } from '../data/quranData';
import { getAyahAudioUrl, triggerHaptic } from '../utils/audioPlayer';
import {
  Search,
  BookOpen,
  Play,
  Pause,
  Bookmark,
  Share2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  User,
  X,
  Volume2,
  Check,
  Type,
  Sliders,
  Sparkles,
  Minus,
  Plus,
  RotateCcw,
} from 'lucide-react';

export interface QuranReaderProps {
  language: AppLanguage;
  arabicFontSize: number;
  bengaliFontSize: number;
  arabicFont?: ArabicFontFamily;
  showTajweed: boolean;
  showTransliteration: boolean;
  showEnglishTranslation: boolean;
  selectedReciter: string;
  bookmarks: number[];
  onToggleBookmark: (surahNum: number) => void;
  onUpdateFontSize: (arabic: number, bengali: number) => void;
  onChangeArabicFont?: (font: ArabicFontFamily) => void;
  onToggleTajweed: () => void;
  onToggleTransliteration: () => void;
  onToggleEnglish: () => void;
  onChangeReciter: (reciterId: string) => void;
  initialSurah?: number;
  initialSearchOpen?: boolean;
  onOpenProfile?: () => void;
}

export type MushafFilterType = 'color_coded' | 'standard' | 'nurani_easy' | 'word_by_word' | 'clean_arabic';
export type ScriptFilterType = 'amiri-quran' | 'noto-nastaliq' | 'noto-naskh' | 'scheherazade' | 'amiri' | 'lateef';

export const QuranReader: React.FC<QuranReaderProps> = ({
  language,
  arabicFontSize,
  bengaliFontSize,
  arabicFont = 'amiri-quran',
  showTajweed,
  showTransliteration,
  showEnglishTranslation,
  selectedReciter,
  bookmarks,
  onToggleBookmark,
  onUpdateFontSize,
  onChangeArabicFont,
  onToggleTajweed,
  onToggleTransliteration,
  onToggleEnglish,
  onChangeReciter,
  initialSurah = 1,
  initialSearchOpen = false,
  onOpenProfile,
}) => {
  const t = TRANSLATIONS[language];
  const [activeSurah, setActiveSurah] = useState<number>(initialSurah || 1);
  const [ayahs, setAyahs] = useState<AyahItem[]>([]);
  const [loadingAyahs, setLoadingAyahs] = useState(false);
  const [showSurahModal, setShowSurahModal] = useState(initialSearchOpen);
  const [showFontModal, setShowFontModal] = useState(false);
  const [surahSearchQuery, setSurahSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio Playback
  const [playingAyahNumber, setPlayingAyahNumber] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // User-selected Arabic Font
  const [selectedArabicFont, setSelectedArabicFont] = useState<ArabicFontFamily>(() => {
    try {
      return (localStorage.getItem('noor_quran_user_arabic_font') as ArabicFontFamily) || arabicFont || 'amiri-quran';
    } catch {
      return arabicFont || 'amiri-quran';
    }
  });

  // Available Arabic Fonts with Previews and verified styles
  const ARABIC_FONTS: {
    id: ArabicFontFamily;
    nameBn: string;
    shortNameBn: string;
    styleName: string;
    preview: string;
    className: string;
  }[] = [
    {
      id: 'amiri-quran',
      nameBn: 'উসমানি কুরআন (Amiri Quran)',
      shortNameBn: 'উসমানি',
      styleName: 'মদিনা শরীফ মুসহাফ স্ট্যান্ডার্ড স্টাইল',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-amiri-quran',
    },
    {
      id: 'noto-nastaliq',
      nameBn: 'নূরানী / নাস্তালিক (Nastaliq)',
      shortNameBn: 'নূরানী',
      styleName: 'বাংলাদেশ ও উপমহাদেশের ঐতিহ্যবাহী কুরআন লিপি',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-noto-nastaliq',
    },
    {
      id: 'noto-naskh',
      nameBn: 'আধুনিক নাসখ (Noto Naskh)',
      shortNameBn: 'নাসখ',
      styleName: 'পরিষ্কার ও সর্বাধিক সহজ পাঠ',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-noto-naskh',
    },
    {
      id: 'scheherazade',
      nameBn: 'শাহারাজাদ (Scheherazade New)',
      shortNameBn: 'শাহারাজাদ',
      styleName: 'ঐতিহ্যবাহী লিপিশৈলী',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-scheherazade',
    },
    {
      id: 'amiri',
      nameBn: 'ক্লাসিক আমিরি (Amiri Classic)',
      shortNameBn: 'আমিরি',
      styleName: 'প্রথাগত আরবি শাস্ত্রীয় হরফ',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-amiri',
    },
    {
      id: 'lateef',
      nameBn: 'লতিফ হরফ (Lateef Script)',
      shortNameBn: 'লতিফ',
      styleName: 'কোমল ও আকর্ষণীয় বাঁকানো নক্সা',
      preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      className: 'font-arabic-lateef',
    },
  ];

  const currentFontInfo = useMemo(() => {
    return ARABIC_FONTS.find((f) => f.id === selectedArabicFont) || ARABIC_FONTS[0];
  }, [selectedArabicFont]);

  // Mushaf Filter Type (e.g. Color-coded, Standard, Easy)
  const [selectedMushafFilter, setSelectedMushafFilter] = useState<MushafFilterType>(() => {
    return showTajweed ? 'color_coded' : 'standard';
  });

  // Ayah Bookmark map
  const [bookmarkedAyahs, setBookmarkedAyahs] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('noor_quran_ayah_bookmarks_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const currentSurahMeta = useMemo(() => {
    return SURAH_LIST.find((s) => s.number === activeSurah) || SURAH_LIST[0];
  }, [activeSurah]);

  // Load ayahs when activeSurah changes
  useEffect(() => {
    if (activeSurah) {
      setLoadingAyahs(true);
      fetchSurahAyahs(activeSurah).then((data) => {
        setAyahs(data);
        setLoadingAyahs(false);
        try {
          localStorage.setItem('noor_quran_last_read_surah', activeSurah.toString());
        } catch {
          // ignore
        }
      });

      // Stop previous audio
      if (audioRef.current) {
        audioRef.current.pause();
        setIsPlaying(false);
        setPlayingAyahNumber(null);
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [activeSurah]);

  // Audio Play / Pause
  const playAyah = (ayahNumInSurah: number) => {
    if (!activeSurah) return;
    const url = getAyahAudioUrl(activeSurah, ayahNumInSurah, selectedReciter);

    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
          setPlayingAyahNumber(ayahNumInSurah);
        })
        .catch((err) => {
          console.warn('Audio play error:', err);
        });
    }
  };

  const handleToggleAyahAudio = (ayahNumInSurah: number) => {
    triggerHaptic(20);
    if (playingAyahNumber === ayahNumInSurah) {
      if (isPlaying) {
        if (audioRef.current) {
          audioRef.current.pause();
        }
        setIsPlaying(false);
      } else {
        if (audioRef.current) {
          audioRef.current.play().then(() => setIsPlaying(true)).catch(console.warn);
        } else {
          playAyah(ayahNumInSurah);
        }
      }
    } else {
      playAyah(ayahNumInSurah);
    }
  };

  // Bookmark Toggle
  const handleToggleAyahBookmark = (ayahNumInSurah: number) => {
    triggerHaptic(15);
    const key = `${activeSurah}_${ayahNumInSurah}`;
    setBookmarkedAyahs((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem('noor_quran_ayah_bookmarks_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      showToast(next[key] ? 'আয়াত বুকমার্কে সংরক্ষিত' : 'বুকমার্ক সরানো হয়েছে');
      return next;
    });
  };

  // Share Ayah
  const handleShareAyah = (ayah: AyahItem) => {
    triggerHaptic(15);
    const shareText = `সূরা ${currentSurahMeta.nameBangla} (আয়াত: ${ayah.numberInSurah})\n\n${ayah.textArabic}\n\nউচ্চারণ: ${ayah.transliterationBn}\n\nঅর্থ: "${ayah.translationBn}"\n\n— নূর কুরআন (Noor Quran)`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      navigator.share({
        title: `সূরা ${currentSurahMeta.nameBangla} — আয়াত ${ayah.numberInSurah}`,
        text: shareText,
      }).catch(() => {});
    } else if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(shareText);
      showToast('আয়াত ও অর্থ ক্লিপবোর্ডে কপি করা হয়েছে');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Carousel Filters: Mushaf Type & Script Type
  const handleSelectMushafFilter = (type: MushafFilterType) => {
    triggerHaptic(15);
    setSelectedMushafFilter(type);
    if (type === 'color_coded') {
      if (!showTajweed) onToggleTajweed();
    } else if (type === 'clean_arabic') {
      // In clean arabic mode, transliteration stays off
      if (showTajweed) onToggleTajweed();
    } else {
      if (showTajweed && type === 'standard') onToggleTajweed();
    }
  };

  const handleSelectScriptFilter = (fontId: ArabicFontFamily) => {
    handleSelectFont(fontId);
  };

  const handleSelectFont = (fontId: ArabicFontFamily) => {
    triggerHaptic(15);
    setSelectedArabicFont(fontId);
    if (onChangeArabicFont) {
      onChangeArabicFont(fontId);
    }
    try {
      localStorage.setItem('noor_quran_user_arabic_font', fontId);
    } catch {
      // ignore
    }
    const found = ARABIC_FONTS.find((f) => f.id === fontId);
    showToast(`✓ ফন্ট পরিবর্তিত: ${found?.shortNameBn || fontId}`);
  };

  const getArabicFontClass = (font: ArabicFontFamily) => {
    switch (font) {
      case 'noto-nastaliq':
        return 'font-arabic-noto-nastaliq';
      case 'noto-naskh':
        return 'font-arabic-noto-naskh';
      case 'scheherazade':
        return 'font-arabic-scheherazade';
      case 'amiri':
        return 'font-arabic-amiri';
      case 'lateef':
        return 'font-arabic-lateef';
      case 'amiri-quran':
      default:
        return 'font-arabic-amiri-quran';
    }
  };

  const getFontFamilyString = (font: ArabicFontFamily) => {
    switch (font) {
      case 'noto-nastaliq':
        return "'Noto Nastaliq Urdu', 'Urdu Typesetting', serif";
      case 'noto-naskh':
        return "'Noto Naskh Arabic', sans-serif";
      case 'scheherazade':
        return "'Scheherazade New', serif";
      case 'amiri':
        return "'Amiri', serif";
      case 'lateef':
        return "'Lateef', cursive, serif";
      case 'amiri-quran':
      default:
        return "'Amiri Quran', 'UthmanicHafs', serif";
    }
  };

  // Filtered Surahs in Search Modal
  const filteredSurahs = useMemo(() => {
    if (!surahSearchQuery.trim()) return SURAH_LIST;
    const q = surahSearchQuery.toLowerCase().trim();
    return SURAH_LIST.filter(
      (s) =>
        s.number.toString() === q ||
        s.nameBangla.toLowerCase().includes(q) ||
        s.nameEnglish.toLowerCase().includes(q) ||
        s.nameArabic.includes(q) ||
        s.englishTranslation.toLowerCase().includes(q)
    );
  }, [surahSearchQuery]);

  const mainAyah = ayahs.length > 0 ? ayahs[0] : null;
  const subsequentAyahs = ayahs.length > 1 ? ayahs.slice(1) : [];

  return (
    <div className="min-h-screen bg-slate-50/40 dark:bg-slate-950 text-slate-800 dark:text-slate-100 pb-28">
      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        onEnded={() => {
          if (playingAyahNumber && playingAyahNumber < ayahs.length) {
            // Auto play next ayah smoothly
            playAyah(playingAyahNumber + 1);
          } else {
            setIsPlaying(false);
            setPlayingAyahNumber(null);
          }
        }}
      />

      {/* 1. TOP APP BAR: "Noor Quran", Surah Selector, Font Changer, Search & Profile */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors shadow-2xs">
        <div className="max-w-3xl mx-auto px-3 sm:px-4 h-14 flex items-center justify-between gap-2">
          {/* Brand & Surah Quick Selector */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
            <h1 className="text-sm sm:text-base font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5 shrink-0">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-600 dark:bg-teal-400" />
              <span>Noor Quran</span>
            </h1>

            {/* Clean Surah Title Badge */}
            <button
              onClick={() => {
                triggerHaptic(15);
                setShowSurahModal(true);
              }}
              className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/60 text-teal-800 dark:text-teal-200 text-xs font-semibold transition-all border border-teal-200/60 dark:border-teal-800/60 cursor-pointer truncate"
              title="সূরা পরিবর্তন করুন"
            >
              <span className="truncate max-w-[100px] xs:max-w-[130px] sm:max-w-[180px]">
                {currentSurahMeta.number}. {currentSurahMeta.nameBangla}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
            </button>
          </div>

          {/* Action Icons: Direct Font Switcher, Search & Profile */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Direct Font Selector Button (Prominent in Eyesight) */}
            <button
              onClick={() => {
                triggerHaptic(15);
                setShowFontModal(true);
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 text-xs font-bold transition-all shadow-2xs active:scale-95 cursor-pointer"
              title="আরবি ফন্ট ও হরফের সাইজ পরিবর্তন করুন"
            >
              <Type className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="hidden xs:inline text-[11px] font-medium text-emerald-700 dark:text-emerald-300">ফন্ট:</span>
              <span className="text-xs font-bold truncate max-w-[65px] sm:max-w-[90px]">
                {currentFontInfo.shortNameBn}
              </span>
              <Sliders className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0 opacity-80" />
            </button>

            {/* Search */}
            <button
              onClick={() => {
                triggerHaptic(15);
                setShowSurahModal(true);
              }}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="সূরা ও আয়াত অনুসন্ধান"
              aria-label="Search"
            >
              <Search className="w-4 h-4 stroke-[2]" />
            </button>

            {/* Profile */}
            <button
              onClick={() => {
                triggerHaptic(15);
                if (onOpenProfile) onOpenProfile();
              }}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="প্রোফাইল ও সেটিংস"
              aria-label="Profile"
            >
              <User className="w-4 h-4 stroke-[2]" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. DUAL ROW CAROUSEL FILTERS: 'Mushaf Type' & 'Arabic Font Style' */}
      <div className="bg-white/80 dark:bg-slate-900/80 border-b border-slate-200/70 dark:border-slate-800 backdrop-blur-xs divide-y divide-slate-100 dark:divide-slate-800/60">
        {/* Row 1: Mushaf Type Filter */}
        <div className="max-w-3xl mx-auto px-3 sm:px-4 py-2">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider shrink-0 pl-0.5">
              মুসহাফ:
            </span>

            <button
              onClick={() => handleSelectMushafFilter('color_coded')}
              className={`px-3 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedMushafFilter === 'color_coded'
                  ? 'bg-teal-700 text-white font-bold shadow-2xs ring-2 ring-teal-500/20'
                  : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-teal-400 font-medium'
              }`}
            >
              কালার কোডেড
            </button>

            <button
              onClick={() => handleSelectMushafFilter('standard')}
              className={`px-3 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedMushafFilter === 'standard'
                  ? 'bg-teal-700 text-white font-bold shadow-2xs ring-2 ring-teal-500/20'
                  : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-teal-400 font-medium'
              }`}
            >
              স্ট্যান্ডার্ড
            </button>

            <button
              onClick={() => handleSelectMushafFilter('nurani_easy')}
              className={`px-3 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedMushafFilter === 'nurani_easy'
                  ? 'bg-teal-700 text-white font-bold shadow-2xs ring-2 ring-teal-500/20'
                  : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-teal-400 font-medium'
              }`}
            >
              সহজ পাঠ
            </button>

            <button
              onClick={() => handleSelectMushafFilter('word_by_word')}
              className={`px-3 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedMushafFilter === 'word_by_word'
                  ? 'bg-teal-700 text-white font-bold shadow-2xs ring-2 ring-teal-500/20'
                  : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-teal-400 font-medium'
              }`}
            >
              শব্দে শব্দে
            </button>

            <button
              onClick={() => handleSelectMushafFilter('clean_arabic')}
              className={`px-3 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedMushafFilter === 'clean_arabic'
                  ? 'bg-teal-700 text-white font-bold shadow-2xs ring-2 ring-teal-500/20'
                  : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-teal-400 font-medium'
              }`}
            >
              শুধু আরবি
            </button>
          </div>
        </div>

        {/* Row 2: Arabic Font / Script Filter (All 6 fonts directly visible and accessible) */}
        <div className="max-w-3xl mx-auto px-3 sm:px-4 py-2 bg-slate-50/60 dark:bg-slate-900/40">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
            <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider shrink-0 pl-0.5 flex items-center gap-1">
              <Type className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
              <span>হরফের ফন্ট:</span>
            </span>

            {ARABIC_FONTS.map((font) => {
              const isSelected = selectedArabicFont === font.id;
              return (
                <button
                  key={font.id}
                  onClick={() => handleSelectFont(font.id)}
                  className={`px-2.5 py-1 rounded-full text-xs transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1 ${
                    isSelected
                      ? 'bg-emerald-700 text-white font-bold shadow-2xs ring-2 ring-emerald-500/30'
                      : 'bg-white dark:bg-slate-850 border border-slate-200/90 dark:border-slate-750 text-slate-700 dark:text-slate-300 hover:border-emerald-400 font-medium'
                  }`}
                  title={font.styleName}
                >
                  {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  <span>{font.shortNameBn}</span>
                </button>
              );
            })}

            {/* Quick Settings Icon Button */}
            <button
              onClick={() => {
                triggerHaptic(15);
                setShowFontModal(true);
              }}
              className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100/70 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-200/80 dark:hover:bg-emerald-900/80 border border-emerald-300/80 dark:border-emerald-700/80 shrink-0 transition-all flex items-center gap-1 cursor-pointer"
              title="ফন্ট সাইজ ও সেটিংস পরিবর্তন করুন"
            >
              <Sliders className="w-3 h-3" />
              <span>ফন্ট সেটিংস</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-2xl mx-auto px-4 pt-6 space-y-6">
        {/* Surah Bismillah Banner (Except Surah 9) */}
        {activeSurah !== 9 && (
          <div className="text-center py-4 space-y-1">
            <span
              className={`${getArabicFontClass(selectedArabicFont)} text-2xl sm:text-3xl text-teal-900 dark:text-teal-200 font-bold tracking-normal block`}
              style={{ fontFamily: getFontFamilyString(selectedArabicFont) }}
              dir="rtl"
            >
              بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
            </span>
            <p className="text-xs text-slate-600 dark:text-slate-400 font-bengali font-normal">
              পরম করুণাময়, অতি দয়ালু আল্লাহর নামে শুরু করছি
            </p>
          </div>
        )}

        {/* Loading Spinner */}
        {loadingAyahs && (
          <div className="py-20 text-center space-y-3">
            <div className="w-8 h-8 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-slate-600 dark:text-slate-400">কুরআনের আয়াত লোড হচ্ছে...</p>
          </div>
        )}

        {!loadingAyahs && mainAyah && (
          <>
            {/* 3. LARGE MAIN CARD FOR THE QURAN TEXT (VERSE 1) */}
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6 transition-all hover:border-teal-300/80 dark:hover:border-teal-700/80">
              {/* Minimalist Top Indicator */}
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-200 text-xs font-bold font-mono flex items-center justify-center border border-teal-200/70 dark:border-teal-800/60 shadow-2xs">
                  {mainAyah.numberInSurah}
                </div>

                {mainAyah.isSajdah && (
                  <span className="text-[10px] text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/60 px-2.5 py-0.5 rounded-full font-bold border border-teal-200 dark:border-teal-800">
                    সিজদার আয়াত
                  </span>
                )}
              </div>

              {/* Arabic Text (Centered, High-Quality Readable Font with Colored Vowels) */}
              <div className="py-2 text-center" dir="rtl">
                <p
                  className={`${getArabicFontClass(selectedArabicFont)} text-2xl sm:text-3xl lg:text-4xl leading-[2.6] sm:leading-[2.8] text-slate-900 dark:text-white tracking-normal select-text`}
                  style={{
                    fontSize: `${arabicFontSize + 2}px`,
                    fontFamily: getFontFamilyString(selectedArabicFont),
                  }}
                >
                  {selectedMushafFilter === 'color_coded' && mainAyah.textArabicTajweed ? (
                    <span dangerouslySetInnerHTML={{ __html: mainAyah.textArabicTajweed }} />
                  ) : (
                    mainAyah.textArabic
                  )}
                </p>
              </div>

              {/* Clear Bengali Transliteration (Well-Spaced, Centered) */}
              {selectedMushafFilter !== 'clean_arabic' && showTransliteration && mainAyah.transliterationBn && (
                <div className="text-center px-2 sm:px-6">
                  <p className="text-sm sm:text-base font-medium text-slate-600 dark:text-slate-400 font-bengali leading-relaxed tracking-wide">
                    {mainAyah.transliterationBn}
                  </p>
                </div>
              )}

              {/* Bengali Translation (Well-Spaced, Centered) */}
              {selectedMushafFilter !== 'clean_arabic' && mainAyah.translationBn && (
                <div className="text-center px-2 sm:px-6">
                  <p
                    className="text-sm sm:text-base font-normal text-slate-800 dark:text-slate-100 font-bengali leading-relaxed"
                    style={{ fontSize: `${bengaliFontSize}px` }}
                  >
                    "{mainAyah.translationBn}"
                  </p>
                </div>
              )}

              {/* Optional English Translation */}
              {selectedMushafFilter !== 'clean_arabic' && showEnglishTranslation && mainAyah.translationEn && (
                <div className="text-center px-2 sm:px-6 pt-1">
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 italic font-sans leading-relaxed">
                    {mainAyah.translationEn}
                  </p>
                </div>
              )}

              {/* Subtle Action Icons at the Bottom: Play Audio, Bookmark, Share */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-center gap-6 sm:gap-8 text-slate-500 dark:text-slate-400">
                <button
                  onClick={() => handleToggleAyahAudio(mainAyah.numberInSurah)}
                  className={`flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                    playingAyahNumber === mainAyah.numberInSurah && isPlaying
                      ? 'text-teal-700 dark:text-teal-400 font-bold'
                      : 'hover:text-teal-700 dark:hover:text-teal-400'
                  }`}
                  title="তেলাওয়াত শুনুন"
                >
                  {playingAyahNumber === mainAyah.numberInSurah && isPlaying ? (
                    <Pause className="w-4 h-4 text-teal-700 dark:text-teal-400 fill-current" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                  <span>
                    {playingAyahNumber === mainAyah.numberInSurah && isPlaying ? 'বিরতি' : 'তেলাওয়াত'}
                  </span>
                </button>

                <button
                  onClick={() => handleToggleAyahBookmark(mainAyah.numberInSurah)}
                  className={`flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                    bookmarkedAyahs[`${activeSurah}_${mainAyah.numberInSurah}`]
                      ? 'text-teal-700 dark:text-teal-400 font-bold'
                      : 'hover:text-teal-700 dark:hover:text-teal-400'
                  }`}
                  title="বুকমার্ক করুন"
                >
                  <Bookmark
                    className={`w-4 h-4 ${
                      bookmarkedAyahs[`${activeSurah}_${mainAyah.numberInSurah}`]
                        ? 'text-teal-700 dark:text-teal-400 fill-current'
                        : ''
                    }`}
                  />
                  <span>বুকমার্ক</span>
                </button>

                <button
                  onClick={() => handleShareAyah(mainAyah)}
                  className="flex items-center gap-1.5 text-xs font-semibold hover:text-teal-700 dark:hover:text-teal-400 transition-colors cursor-pointer"
                  title="আয়াত শেয়ার করুন"
                >
                  <Share2 className="w-4 h-4" />
                  <span>শেয়ার</span>
                </button>
              </div>
            </div>

            {/* 4. SUBSEQUENT VERSES: Minimal, Spacious, Consistent Design */}
            <div className="space-y-6 pt-2">
              {subsequentAyahs.map((ayah) => {
                const isPlayingThis = playingAyahNumber === ayah.numberInSurah && isPlaying;
                const isBookmarkedThis = bookmarkedAyahs[`${activeSurah}_${ayah.numberInSurah}`];

                return (
                  <div
                    key={ayah.numberInSurah}
                    className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 shadow-2xs space-y-5 transition-all hover:border-teal-300/80 dark:hover:border-teal-700/80"
                  >
                    {/* Clean Minimal Verse Badge */}
                    <div className="flex items-center justify-between">
                      <div className="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold font-mono flex items-center justify-center">
                        {ayah.numberInSurah}
                      </div>

                      {ayah.isSajdah && (
                        <span className="text-[10px] text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-full font-bold border border-teal-200 dark:border-teal-800">
                          সিজদার আয়াত
                        </span>
                      )}
                    </div>

                    {/* Centered Arabic Text with Colored Vowels */}
                    <div className="text-center py-1" dir="rtl">
                      <p
                        className={`${getArabicFontClass(selectedArabicFont)} text-xl sm:text-2xl lg:text-3xl leading-[2.5] sm:leading-[2.7] text-slate-900 dark:text-white select-text`}
                        style={{
                          fontSize: `${arabicFontSize}px`,
                          fontFamily: getFontFamilyString(selectedArabicFont),
                        }}
                      >
                        {selectedMushafFilter === 'color_coded' && ayah.textArabicTajweed ? (
                          <span dangerouslySetInnerHTML={{ __html: ayah.textArabicTajweed }} />
                        ) : (
                          ayah.textArabic
                        )}
                      </p>
                    </div>

                    {/* Centered Bengali Transliteration */}
                    {selectedMushafFilter !== 'clean_arabic' && showTransliteration && ayah.transliterationBn && (
                      <div className="text-center px-2 sm:px-4">
                        <p className="text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 font-bengali leading-relaxed">
                          {ayah.transliterationBn}
                        </p>
                      </div>
                    )}

                    {/* Centered Bengali Translation */}
                    {selectedMushafFilter !== 'clean_arabic' && ayah.translationBn && (
                      <div className="text-center px-2 sm:px-4">
                        <p
                          className="text-xs sm:text-sm font-normal text-slate-800 dark:text-slate-200 font-bengali leading-relaxed"
                          style={{ fontSize: `${bengaliFontSize}px` }}
                        >
                          "{ayah.translationBn}"
                        </p>
                      </div>
                    )}

                    {/* Optional English Translation */}
                    {selectedMushafFilter !== 'clean_arabic' && showEnglishTranslation && ayah.translationEn && (
                      <div className="text-center px-2 sm:px-4 pt-0.5">
                        <p className="text-xs text-slate-500 dark:text-slate-400 italic font-sans leading-relaxed">
                          {ayah.translationEn}
                        </p>
                      </div>
                    )}

                    {/* Subtle Action Icons */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-center gap-6 sm:gap-8 text-slate-500 dark:text-slate-400 text-xs">
                      <button
                        onClick={() => handleToggleAyahAudio(ayah.numberInSurah)}
                        className={`flex items-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                          isPlayingThis
                            ? 'text-teal-700 dark:text-teal-400 font-bold'
                            : 'hover:text-teal-700 dark:hover:text-teal-400'
                        }`}
                        title="তেলাওয়াত শুনুন"
                      >
                        {isPlayingThis ? (
                          <Pause className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5" />
                        )}
                        <span>{isPlayingThis ? 'বিরতি' : 'তেলাওয়াত'}</span>
                      </button>

                      <button
                        onClick={() => handleToggleAyahBookmark(ayah.numberInSurah)}
                        className={`flex items-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                          isBookmarkedThis
                            ? 'text-teal-700 dark:text-teal-400 font-bold'
                            : 'hover:text-teal-700 dark:hover:text-teal-400'
                        }`}
                        title="বুকমার্ক করুন"
                      >
                        <Bookmark
                          className={`w-3.5 h-3.5 ${
                            isBookmarkedThis ? 'text-teal-700 dark:text-teal-400 fill-current' : ''
                          }`}
                        />
                        <span>বুকমার্ক</span>
                      </button>

                      <button
                        onClick={() => handleShareAyah(ayah)}
                        className="flex items-center gap-1.5 font-semibold hover:text-teal-700 dark:hover:text-teal-400 transition-colors cursor-pointer"
                        title="আয়াত শেয়ার করুন"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>শেয়ার</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* Next / Previous Surah Navigation Bar at End of Verses */}
        {!loadingAyahs && ayahs.length > 0 && (
          <div className="pt-6 pb-8 flex items-center justify-between border-t border-slate-200/80 dark:border-slate-800">
            <button
              onClick={() => {
                if (activeSurah > 1) {
                  triggerHaptic(15);
                  setActiveSurah(activeSurah - 1);
                }
              }}
              disabled={activeSurah <= 1}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-semibold transition-colors ${
                activeSurah <= 1
                  ? 'opacity-30 cursor-not-allowed text-slate-400'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-teal-700'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>পূর্ববর্তী সূরা</span>
            </button>

            <button
              onClick={() => setShowSurahModal(true)}
              className="text-xs font-bold text-teal-700 dark:text-teal-400 hover:underline"
            >
              সূচিপত্র দেখুন
            </button>

            <button
              onClick={() => {
                if (activeSurah < 114) {
                  triggerHaptic(15);
                  setActiveSurah(activeSurah + 1);
                }
              }}
              disabled={activeSurah >= 114}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-semibold transition-colors ${
                activeSurah >= 114
                  ? 'opacity-30 cursor-not-allowed text-slate-400'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-teal-700'
              }`}
            >
              <span>পরবর্তী সূরা</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>

      {/* SURAH SEARCH & NAVIGATION MODAL (Clean, Minimalist Drawer) */}
      {showSurahModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  পবিত্র কুরআনের ১১৪টি সূরা
                </h3>
              </div>
              <button
                onClick={() => setShowSurahModal(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Input */}
            <div className="p-3 border-b border-slate-100 dark:border-slate-800">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={surahSearchQuery}
                  onChange={(e) => setSurahSearchQuery(e.target.value)}
                  placeholder="সূরা খুঁজুন (যেমন: ফাতিহা, বাকারাহ, ১-১১৪)..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-hidden focus:border-teal-500"
                  autoFocus
                />
              </div>
            </div>

            {/* Surah List */}
            <div className="overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 p-1">
              {filteredSurahs.map((surah) => {
                const isCurrent = surah.number === activeSurah;
                return (
                  <button
                    key={surah.number}
                    onClick={() => {
                      triggerHaptic(15);
                      setActiveSurah(surah.number);
                      setShowSurahModal(false);
                      setSurahSearchQuery('');
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl text-left transition-colors cursor-pointer ${
                      isCurrent
                        ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-900 dark:text-teal-200'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-850'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold font-mono ${
                          isCurrent
                            ? 'bg-teal-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {surah.number}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {surah.nameBangla}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            ({surah.nameEnglish})
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                          {surah.numberOfAyahs} আয়াত · {surah.revelationTypeBn}
                        </span>
                      </div>
                    </div>

                    <span className="font-arabic text-base font-bold text-teal-800 dark:text-teal-300" dir="rtl">
                      {surah.nameArabic}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ARABIC FONT & TYPOGRAPHY SETTINGS MODAL */}
      {showFontModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center">
                  <Type className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    কুরআনের আরবি ফন্ট ও হরফ সেটিংস
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    লিপিশৈলী ও পড়ার সুবিধার জন্য হরফের সাইজ নির্ধারণ করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowFontModal(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="overflow-y-auto p-4 space-y-5">
              {/* Live Preview Card */}
              <div className="p-4 rounded-2xl bg-linear-to-b from-emerald-50/70 to-teal-50/40 dark:from-emerald-950/40 dark:to-teal-950/20 border border-emerald-200/80 dark:border-emerald-800/60 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>লাইভ হরফ প্রিভিউ: {currentFontInfo.shortNameBn}</span>
                  </span>
                  <span className="text-[10px] bg-emerald-200/60 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 px-2 py-0.5 rounded-full font-bold">
                    {arabicFontSize}px
                  </span>
                </div>

                <div className="text-center py-2" dir="rtl">
                  <p
                    className={`${getArabicFontClass(selectedArabicFont)} text-slate-900 dark:text-white font-bold leading-[2.6] transition-all`}
                    style={{
                      fontSize: `${arabicFontSize}px`,
                      fontFamily: getFontFamilyString(selectedArabicFont),
                    }}
                  >
                    بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
                  </p>
                </div>

                <p
                  className="text-center text-slate-600 dark:text-slate-400 font-bengali leading-relaxed"
                  style={{ fontSize: `${bengaliFontSize}px` }}
                >
                  পরম করুণাময়, অতি দয়ালু আল্লাহর নামে শুরু করছি
                </p>
              </div>

              {/* 1. Arabic Font Selection Grid */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                  <span>পছন্দের আরবি ফন্ট (লিপিশৈলী বেছে নিন):</span>
                  <span className="text-[11px] text-teal-600 dark:text-teal-400 font-normal">
                    মোট ৬টি হরফ
                  </span>
                </label>

                <div className="grid grid-cols-1 gap-2">
                  {ARABIC_FONTS.map((font) => {
                    const isSelected = selectedArabicFont === font.id;
                    return (
                      <button
                        key={font.id}
                        onClick={() => handleSelectFont(font.id)}
                        className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-3 cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 shadow-2xs ring-1 ring-emerald-500/30'
                            : 'bg-white dark:bg-slate-850 border-slate-200/80 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border ${
                              isSelected
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          </div>

                          <div className="truncate">
                            <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                              {font.nameBn}
                            </h4>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                              {font.styleName}
                            </p>
                          </div>
                        </div>

                        {/* Font Sample */}
                        <span
                          className={`${font.className} text-base sm:text-lg font-bold text-emerald-800 dark:text-emerald-300 shrink-0`}
                          dir="rtl"
                          style={{ fontFamily: getFontFamilyString(font.id) }}
                        >
                          الْقُرْآنُ
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Arabic Font Size Slider & Buttons */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    আরবি হরফের সাইজ
                  </span>
                  <span className="text-xs font-bold font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-300/40">
                    {arabicFontSize} px
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onUpdateFontSize(Math.max(20, arabicFontSize - 2), bengaliFontSize);
                    }}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 cursor-pointer shadow-2xs active:scale-95 shrink-0"
                    title="ছোট করুন"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>

                  <input
                    type="range"
                    min="20"
                    max="48"
                    step="1"
                    value={arabicFontSize}
                    onChange={(e) => onUpdateFontSize(Number(e.target.value), bengaliFontSize)}
                    className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />

                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onUpdateFontSize(Math.min(48, arabicFontSize + 2), bengaliFontSize);
                    }}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 cursor-pointer shadow-2xs active:scale-95 shrink-0"
                    title="বড় করুন"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* 3. Bengali Translation Font Size Slider */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    বাংলা অর্থ ও উচ্চারণের সাইজ
                  </span>
                  <span className="text-xs font-bold font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-300/40">
                    {bengaliFontSize} px
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onUpdateFontSize(arabicFontSize, Math.max(12, bengaliFontSize - 1));
                    }}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 cursor-pointer shadow-2xs active:scale-95 shrink-0"
                    title="ছোট করুন"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>

                  <input
                    type="range"
                    min="12"
                    max="24"
                    step="1"
                    value={bengaliFontSize}
                    onChange={(e) => onUpdateFontSize(arabicFontSize, Number(e.target.value))}
                    className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none"
                  />

                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onUpdateFontSize(arabicFontSize, Math.min(24, bengaliFontSize + 1));
                    }}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 cursor-pointer shadow-2xs active:scale-95 shrink-0"
                    title="বড় করুন"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* 4. Reading View Toggles */}
              <div className="space-y-2 pt-1">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                  পড়ার সুবিধা ও প্রদর্শন:
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onToggleTajweed();
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                      showTajweed
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 text-emerald-900 dark:text-emerald-200'
                        : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span>তাজবীদ কালার</span>
                    <span className="text-[10px] font-bold">{showTajweed ? 'চালু' : 'বন্ধ'}</span>
                  </button>

                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      onToggleTransliteration();
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                      showTransliteration
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 text-emerald-900 dark:text-emerald-200'
                        : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span>বাংলা উচ্চারণ</span>
                    <span className="text-[10px] font-bold">{showTransliteration ? 'চালু' : 'বন্ধ'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  triggerHaptic(15);
                  handleSelectFont('amiri-quran');
                  onUpdateFontSize(28, 15);
                  showToast('ডিফল্ট হরফ ও সাইজ রিসেট করা হয়েছে');
                }}
                className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 font-semibold cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>রিসেট করুন</span>
              </button>

              <button
                onClick={() => setShowFontModal(false)}
                className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm transition-all active:scale-95 cursor-pointer"
              >
                সম্পন্ন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 dark:bg-white/90 text-white dark:text-slate-900 text-xs font-semibold px-4 py-2 rounded-full shadow-lg backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 duration-150 flex items-center gap-2">
          <Check className="w-3.5 h-3.5 text-teal-400 dark:text-teal-600" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
