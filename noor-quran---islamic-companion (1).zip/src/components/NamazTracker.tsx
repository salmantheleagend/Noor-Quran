import React, { useState, useEffect, useMemo } from 'react';
import { AppLanguage } from '../types';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Calendar,
  RotateCcw,
  Sparkles,
  Flame,
  Award,
  ChevronLeft,
  ChevronRight,
  Info,
  BookOpen,
  Check,
  History,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

export interface NamazTrackerProps {
  language: AppLanguage;
}

export type WaqtKey = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
export type WaqtStatus = 'prayed' | 'missed' | 'none';

interface DayNamazRecord {
  dateStr: string; // YYYY-MM-DD
  fajr?: WaqtStatus;
  dhuhr?: WaqtStatus;
  asr?: WaqtStatus;
  maghrib?: WaqtStatus;
  isha?: WaqtStatus;
  tahajjud?: boolean;
}

const STORAGE_KEY_NAMAZ_LOG = 'noor_quran_namaz_tracker_log_v2';
const STORAGE_KEY_QAZA_COUNT = 'noor_quran_namaz_qaza_repaid_v2';

const WAQT_LIST: { id: WaqtKey; nameBn: string; nameAr: string; rakats: string }[] = [
  { id: 'fajr', nameBn: 'ফজর', nameAr: 'الفجر', rakats: '২ রাকাত ফরজ' },
  { id: 'dhuhr', nameBn: 'যোহর', nameAr: 'الظهر', rakats: '৪ রাকাত ফরজ' },
  { id: 'asr', nameBn: 'আসর', nameAr: 'العصر', rakats: '৪ রাকাত ফরজ' },
  { id: 'maghrib', nameBn: 'মাগরিব', nameAr: 'المغرب', rakats: '৩ রাকাত ফরজ' },
  { id: 'isha', nameBn: 'ইশা', nameAr: 'العشاء', rakats: '৪ রাকাত ফরজ' },
];

// Authentic Hadiths on the severe consequence and punishment of neglecting prayer
const PRAYER_WARNING_HADITHS = [
  {
    id: 'muslim_82',
    arabic: 'بَيْنَ الرَّجُلِ وَبَيْنَ الشِّرْكِ وَالْكُفْرِ تَرْكُ الصَّلَاةِ',
    bangla: 'বান্দা এবং শিরক ও কুফরের মাঝে একমাত্র পার্থক্যই হলো সালাত ত্যাগ করা।',
    reference: 'সহীহ মুসলিম: ৮২, সুনানে তিরমিযী: ২৬১৮, আবু দাউদ: ৪৬৭৮',
    highlight: 'সালাত ত্যাগ কুফর ও শিরকের সমান মারাত্মক অপরাধ',
  },
  {
    id: 'tirmidhi_2621',
    arabic: 'الْعَهْدُ الَّذِي بَيْنَنَا وَبَيْنَهُمُ الصَّلَاةُ فَمَنْ تَرَكَهَا فَقَدْ كَفَرَ',
    bangla: 'আমাদের এবং তাদের (কাফের ও মুনাফিকদের) মাঝে চুক্তি হলো সালাত; সুতরাং যে ব্যক্তি সালাত ত্যাগ করল, সে সুস্পষ্ট কুফরী করল।',
    reference: 'জামে তিরমিযী: ২৬২১, সুনানে নাসাঈ: ৪৬৩, ইবনে মাজাহ: ১০৭৯ (সহীহ)',
    highlight: 'ঈমান ও কুফরের সীমারেখা হলো সালাত',
  },
  {
    id: 'tirmidhi_413',
    arabic: 'إِنَّ أَوَّلَ مَا يُحَاسَبُ بِهِ الْعَبْدُ يَوْمَ الْقِيَامَةِ مِنْ عَمَلِهِ صَلَاتُهُ، فَإِنْ صَلَحَتْ فَقَدْ أَفْلَحَ وَأَنْجَحَ، وَإِنْ فَسَدَتْ فَقَدْ خَابَ وَخَسِرَ',
    bangla: 'কিয়ামতের দিন বান্দার আমলসমূহের মধ্যে সর্বপ্রথম সালাতের হিসাব নেওয়া হবে। সালাত সঠিক হলে সে সফলকাম ও মুক্তি পাবে; আর সালাত বরবাদ হলে সে ব্যর্থ, ধ্বংস ও চির ক্ষতিগ্রস্ত হবে।',
    reference: 'জামে তিরমিযী: ৪১৩, সুনানে আবু দাউদ: ৮৬৪ (সহীহ)',
    highlight: 'আখেরাতের প্রথম বিচার হবে সালাতের',
  },
  {
    id: 'quran_muddathir',
    arabic: 'مَا سَلَكَكُمْ فِي سَقَرَ ۝ قَالُوا لَمْ نَكُ مِنَ الْمُصَلِّينَ',
    bangla: 'জাহান্নামীদের জিজ্ঞেস করা হবে: কীসে তোমাদের সাক্বার (ভয়াবহ জাহান্নামে) নিক্ষেপ করল? তারা বলবে: আমরা নামাজি ছিলাম না (সালাত আদায় করতাম না)।',
    reference: 'পবিত্র কুরআন: সূরা আল-মুদ্দাসসির (৪২-৪৩)',
    highlight: 'জাহান্নামে যাওয়ার অন্যতম প্রধান কারণ সালাত না পড়া',
  },
];

export const NamazTracker: React.FC<NamazTrackerProps> = ({ language }) => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [activeHadithIndex, setActiveHadithIndex] = useState(0);
  const [showHadithModal, setShowHadithModal] = useState(false);

  // Namaz Log: Record<dateStr, DayNamazRecord>
  const [logs, setLogs] = useState<Record<string, DayNamazRecord>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NAMAZ_LOG);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {};
  });

  // Repaid Qaza count
  const [repaidQazaCount, setRepaidQazaCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_QAZA_COUNT);
      if (saved) return Number(saved) || 0;
    } catch {
      // ignore
    }
    return 0;
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NAMAZ_LOG, JSON.stringify(logs));
    } catch (e) {
      console.warn('Failed to save namaz log', e);
    }
  }, [logs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_QAZA_COUNT, repaidQazaCount.toString());
    } catch (e) {
      console.warn('Failed to save qaza count', e);
    }
  }, [repaidQazaCount]);

  // Date formatting helper
  const getDateStr = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  const todayStr = useMemo(() => getDateStr(new Date()), []);
  const currentSelectedDateStr = useMemo(() => getDateStr(selectedDate), [selectedDate]);
  const isSelectedDateToday = currentSelectedDateStr === todayStr;

  const currentDayRecord: DayNamazRecord = logs[currentSelectedDateStr] || {
    dateStr: currentSelectedDateStr,
  };

  // Toggle or set waqt status for the selected date
  const handleSetWaqtStatus = (waqt: WaqtKey, newStatus: WaqtStatus) => {
    triggerHaptic(20);
    const existingStatus = currentDayRecord[waqt] || 'none';
    const finalStatus = existingStatus === newStatus ? 'none' : newStatus;

    setLogs((prev) => ({
      ...prev,
      [currentSelectedDateStr]: {
        ...(prev[currentSelectedDateStr] || { dateStr: currentSelectedDateStr }),
        [waqt]: finalStatus,
      },
    }));
  };

  const handleToggleTahajjud = () => {
    triggerHaptic(15);
    setLogs((prev) => ({
      ...prev,
      [currentSelectedDateStr]: {
        ...(prev[currentSelectedDateStr] || { dateStr: currentSelectedDateStr }),
        tahajjud: !currentDayRecord.tahajjud,
      },
    }));
  };

  // Repay a Qaza waqt
  const handleRepayQaza = () => {
    triggerHaptic(30);
    setRepaidQazaCount((prev) => prev + 1);
  };

  // Monthly Calculations for the currently selected month
  const currentMonthYearKey = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}`;
  const daysInCurrentMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();

  // If viewing current month, only calculate elapsed days up to today
  const isCurrentViewingMonthThisMonth =
    selectedDate.getFullYear() === new Date().getFullYear() &&
    selectedDate.getMonth() === new Date().getMonth();

  const daysElapsedInMonth = isCurrentViewingMonthThisMonth
    ? new Date().getDate()
    : daysInCurrentMonth;

  const monthlyStats = useMemo(() => {
    let totalPrayed = 0;
    let totalExplicitMissed = 0;
    let totalUnrecordedWaqts = 0;

    const waqtMissedBreakdown: Record<WaqtKey, number> = {
      fajr: 0,
      dhuhr: 0,
      asr: 0,
      maghrib: 0,
      isha: 0,
    };

    const waqtPrayedBreakdown: Record<WaqtKey, number> = {
      fajr: 0,
      dhuhr: 0,
      asr: 0,
      maghrib: 0,
      isha: 0,
    };

    for (let day = 1; day <= daysElapsedInMonth; day++) {
      const dStr = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const rec = logs[dStr];

      WAQT_LIST.forEach(({ id }) => {
        const st = rec ? rec[id] : undefined;
        if (st === 'prayed') {
          totalPrayed++;
          waqtPrayedBreakdown[id]++;
        } else if (st === 'missed') {
          totalExplicitMissed++;
          waqtMissedBreakdown[id]++;
        } else {
          // If past day and not marked, count as missed
          if (dStr < todayStr) {
            totalUnrecordedWaqts++;
            waqtMissedBreakdown[id]++;
          }
        }
      });
    }

    const totalEligibleWaqts = daysElapsedInMonth * 5;
    const totalMissedCombined = totalExplicitMissed + totalUnrecordedWaqts;
    const netMissedRemaining = Math.max(0, totalMissedCombined - repaidQazaCount);
    const successRate = totalEligibleWaqts > 0 ? Math.round((totalPrayed / totalEligibleWaqts) * 100) : 0;

    return {
      totalEligibleWaqts,
      totalPrayed,
      totalExplicitMissed,
      totalUnrecordedWaqts,
      totalMissedCombined,
      netMissedRemaining,
      successRate,
      waqtMissedBreakdown,
      waqtPrayedBreakdown,
    };
  }, [logs, selectedDate, daysElapsedInMonth, todayStr, repaidQazaCount]);

  // Navigate dates
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    setSelectedDate(d);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    // Don't go into future dates beyond today
    if (d > new Date()) return;
    setSelectedDate(d);
  };

  const activeHadith = PRAYER_WARNING_HADITHS[activeHadithIndex];

  return (
    <div className="space-y-4">
      {/* 1. PROMINENT EYE-CATCHING HADITH WARNING: PUNISHMENT FOR NEGLECTING PRAYER */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-rose-950 via-slate-950 to-red-950 text-white border-2 border-rose-500/40 shadow-xl shadow-rose-950/25 p-4 sm:p-5 space-y-3">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between border-b border-rose-800/40 pb-2.5">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500 text-white shadow-xs">
              <AlertTriangle className="h-4 w-4" />
            </span>
            <div>
              <span className="text-xs font-black tracking-wide uppercase text-rose-300 block">
                নামাজ না পড়ার কঠোর শাস্তি ও হাদিসের সতর্কবার্তা
              </span>
              <span className="text-[10px] text-rose-200/70 block">
                সহীহ হাদিসের আলোকে সালাত ত্যাগকারীর পরিণতি
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {PRAYER_WARNING_HADITHS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  triggerHaptic(10);
                  setActiveHadithIndex(idx);
                }}
                className={`h-2 rounded-full transition-all ${
                  idx === activeHadithIndex
                    ? 'w-5 bg-amber-400'
                    : 'w-2 bg-rose-800 hover:bg-rose-700'
                }`}
                title={`হাদিস ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Hadith Content with Highlight */}
        <div className="space-y-2 pt-0.5">
          <div className="p-3 rounded-2xl bg-black/40 border border-rose-800/50 backdrop-blur-xs space-y-2">
            <p className="font-arabic text-lg sm:text-xl font-bold text-amber-200 text-right leading-relaxed" dir="rtl">
              «{activeHadith.arabic}»
            </p>
            <p className="text-xs sm:text-sm font-semibold text-rose-50 font-bengali leading-relaxed">
              "{activeHadith.bangla}"
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px]">
            <span className="px-2.5 py-1 rounded-lg bg-rose-900/60 border border-rose-700/50 text-rose-200 font-bold">
              📌 {activeHadith.highlight}
            </span>
            <span className="text-amber-300 font-mono text-[10px]">
              {activeHadith.reference}
            </span>
          </div>
        </div>

        {/* View all Hadiths trigger button */}
        <div className="flex items-center justify-between pt-1">
          <button
            onClick={() => {
              triggerHaptic(15);
              setShowHadithModal(true);
            }}
            className="text-[11px] font-bold text-amber-300 hover:text-amber-200 underline underline-offset-4 flex items-center gap-1 cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>বেনামাজীর শাস্তি সংক্রান্ত আরও সহীহ হাদিস পড়ুন</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic(10);
              setActiveHadithIndex((prev) => (prev + 1) % PRAYER_WARNING_HADITHS.length);
            }}
            className="text-[11px] font-bold text-rose-200 hover:text-white px-2 py-0.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
          >
            পরবর্তী হাদিস →
          </button>
        </div>
      </div>

      {/* 2. DAILY NAMAZ CHECKLIST (আজকের ৫ ওয়াক্ত সালাত চেকলিস্ট) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-4">
        {/* Day Selector Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                দৈনিক ৫ ওয়াক্ত সালাত চেকলিস্ট
              </h3>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              প্রতিটি ওয়াক্ত আদায় বা মিস চিহ্নিত করে নিজের হিসাব রাখুন
            </p>
          </div>

          {/* Date Navigator */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
            <button
              onClick={handlePrevDay}
              className="p-1 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
              title="আগের দিন"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 px-2 min-w-[75px] text-center">
              {isSelectedDateToday
                ? 'আজকে'
                : selectedDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
                    day: 'numeric',
                    month: 'short',
                  })}
            </span>
            <button
              onClick={handleNextDay}
              disabled={isSelectedDateToday}
              className={`p-1 rounded-xl transition-colors ${
                isSelectedDateToday
                  ? 'opacity-30 cursor-not-allowed'
                  : 'hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
              title="পরের দিন"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 5 Waqt Check Buttons Grid */}
        <div className="space-y-2">
          {WAQT_LIST.map((waqt) => {
            const status = currentDayRecord[waqt.id] || 'none';
            const isPrayed = status === 'prayed';
            const isMissed = status === 'missed';

            return (
              <div
                key={waqt.id}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between ${
                  isPrayed
                    ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                    : isMissed
                    ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800'
                    : 'bg-slate-50/70 dark:bg-slate-850 border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                      isPrayed
                        ? 'bg-emerald-600 text-white'
                        : isMissed
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {isPrayed ? '✓' : isMissed ? '✕' : waqt.nameBn[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {waqt.nameBn}
                      </span>
                      <span className="text-xs text-slate-400 font-arabic">
                        ({waqt.nameAr})
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      {waqt.rakats}
                    </span>
                  </div>
                </div>

                {/* Status Toggle Buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleSetWaqtStatus(waqt.id, 'prayed')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isPrayed
                        ? 'bg-emerald-600 text-white shadow-xs scale-102'
                        : 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isPrayed ? 'আদায়কৃত' : 'পড়েছি'}</span>
                  </button>

                  <button
                    onClick={() => handleSetWaqtStatus(waqt.id, 'missed')}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isMissed
                        ? 'bg-rose-600 text-white shadow-xs scale-102'
                        : 'bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 hover:bg-rose-100'
                    }`}
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>{isMissed ? 'মিস' : 'মিস'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bonus Tahajjud Tracker */}
        <div className="pt-1 flex items-center justify-between p-2.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-900/50">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <div>
              <span className="text-xs font-bold text-indigo-950 dark:text-indigo-200 block">
                তাহাজ্জুদ সালাত (নফল)
              </span>
              <span className="text-[10px] text-indigo-700/70 dark:text-indigo-300/70 block">
                রাতের বিশেষ ইবাদত ও নৈকট্য
              </span>
            </div>
          </div>

          <button
            onClick={handleToggleTahajjud}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              currentDayRecord.tahajjud
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
            }`}
          >
            {currentDayRecord.tahajjud ? '✓ আদায় করেছি' : '+ যোগ করুন'}
          </button>
        </div>
      </div>

      {/* 3. MONTHLY MISSED PRAYER ANALYTICS (চলতি মাসে কত ওয়াক্ত নামাজ পড়া হয়নি) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-linear-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-950 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        {/* Section Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-4 h-4 text-rose-600" />
              <span>এই মাসে মিস হওয়া সালাতের পূর্ণাঙ্গ হিসাব</span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              চলতি মাসের মোট ওয়াক্ত, আদায়কৃত এবং পড়া না হওয়া নামাজের খতিয়ান
            </p>
          </div>

          <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-xl">
            {selectedDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
              month: 'long',
              year: 'numeric',
            })}
          </span>
        </div>

        {/* Big Highlights Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Total Waqt this month */}
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">
              মোট ওয়াক্ত (আজ পর্যন্ত)
            </span>
            <span className="text-2xl font-black font-mono text-slate-900 dark:text-white mt-1 block">
              {monthlyStats.totalEligibleWaqts}
            </span>
            <span className="text-[10px] text-slate-400 block">ওয়াক্ত</span>
          </div>

          {/* Prayed Waqts */}
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center">
            <span className="text-[10px] text-emerald-800 dark:text-emerald-300 block font-semibold">
              আদায়কৃত সালাত
            </span>
            <span className="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400 mt-1 block">
              {monthlyStats.totalPrayed}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-bold">
              সাফল্য: {monthlyStats.successRate}%
            </span>
          </div>

          {/* Missed Waqts (The exact feature user asked for) */}
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-center">
            <span className="text-[10px] text-rose-800 dark:text-rose-300 block font-black">
              পড়া হয়নি (মিস ওয়াক্ত)
            </span>
            <span className="text-2xl font-black font-mono text-rose-700 dark:text-rose-400 mt-1 block">
              {monthlyStats.totalMissedCombined}
            </span>
            <span className="text-[10px] text-rose-600 dark:text-rose-400 block font-bold">
              ওয়াক্ত কাজা হয়েছে
            </span>
          </div>

          {/* Repaid Qaza & Net Remaining */}
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center">
            <span className="text-[10px] text-amber-800 dark:text-amber-300 block font-semibold">
              কাজা বাকি রয়েছে
            </span>
            <span className="text-2xl font-black font-mono text-amber-700 dark:text-amber-400 mt-1 block">
              {monthlyStats.netMissedRemaining}
            </span>
            <span className="text-[10px] text-amber-600 dark:text-amber-400 block font-bold">
              (পরিশোধিত: {repaidQazaCount})
            </span>
          </div>
        </div>

        {/* Detailed Breakdown per Waqt */}
        <div className="space-y-1.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850/80 border border-slate-200/80 dark:border-slate-800 text-xs">
          <span className="font-bold text-slate-800 dark:text-slate-200 block mb-2">
            ওয়াক্তভিত্তিক মিস হওয়া নামাজের বিবরণ:
          </span>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center">
            {WAQT_LIST.map((w) => {
              const missed = monthlyStats.waqtMissedBreakdown[w.id];
              const prayed = monthlyStats.waqtPrayedBreakdown[w.id];

              return (
                <div
                  key={w.id}
                  className={`p-2 rounded-xl border ${
                    missed > 0
                      ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200'
                      : 'bg-white dark:bg-slate-900 border-slate-200/60 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="font-bold block">{w.nameBn}</span>
                  <div className="flex items-center justify-center gap-1.5 mt-1 font-mono text-[11px]">
                    <span className="text-emerald-600 font-bold">✓{prayed}</span>
                    <span>·</span>
                    <span className="text-rose-600 font-bold">✕{missed}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Repay Qaza Action Bar */}
        <div className="p-3 rounded-2xl bg-amber-500/10 dark:bg-amber-950/30 border border-amber-300/60 dark:border-amber-800/50 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div>
            <span className="text-xs font-bold text-amber-900 dark:text-amber-200 block">
              কাজা নামাজ আদায় করেছেন?
            </span>
            <span className="text-[10px] text-slate-600 dark:text-slate-400 block">
              মিস হওয়া কোনো ওয়াক্ত আদায় করা হলে এখানে ক্লিক করে বাকি কাজার সংখ্যা কমিয়ে নিন
            </span>
          </div>

          <div className="flex items-center gap-2">
            {repaidQazaCount > 0 && (
              <button
                onClick={() => {
                  triggerHaptic(15);
                  setRepaidQazaCount((p) => Math.max(0, p - 1));
                }}
                className="px-2.5 py-1 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold cursor-pointer"
                title="১টি কাজা পরিশোধ কমান"
              >
                -১
              </button>
            )}

            <button
              onClick={handleRepayQaza}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>১ ওয়াক্ত কাজা আদায় সম্পন্ন</span>
            </button>
          </div>
        </div>
      </div>

      {/* ALL WARNING HADITHS MODAL */}
      {showHadithModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-linear-to-r from-rose-900 to-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">
                  সালাত ত্যাগকারীর কঠিন পরিণতি ও শাস্তি
                </h3>
              </div>
              <button
                onClick={() => setShowHadithModal(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-sm font-bold"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200">
                <p className="leading-relaxed font-semibold">
                  রাসূলুল্লাহ (ﷺ) ও সাহাবায়ে কেরাম সালাত ত্যাগের ব্যাপারে সবচেয়ে বেশি কঠোর সতর্কবাণী উচ্চারণ করেছেন। কোনো অবস্থাতেই প্রাপ্তবয়স্ক সুস্থ মুসলিমের জন্য নামাজ ত্যাগ করার কোনো সুযোগ নেই।
                </p>
              </div>

              {PRAYER_WARNING_HADITHS.map((item, idx) => (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs text-rose-700 dark:text-rose-400 font-bold">
                    <span>হাদিস নং {idx + 1}</span>
                    <span className="font-mono text-[11px] text-slate-500">
                      {item.reference}
                    </span>
                  </div>

                  <p className="font-arabic text-base sm:text-lg font-bold text-emerald-800 dark:text-emerald-300 text-right leading-loose" dir="rtl">
                    {item.arabic}
                  </p>

                  <p className="font-bengali text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                    "{item.bangla}"
                  </p>

                  <div className="pt-1">
                    <span className="inline-block px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[11px] font-bold">
                      গুরুত্বপূর্ণ শিক্ষা: {item.highlight}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-right">
              <button
                onClick={() => setShowHadithModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
