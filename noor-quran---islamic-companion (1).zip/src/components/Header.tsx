import React from 'react';
import { AppLanguage, AppTheme, LocationInfo } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { MapPin, Moon, Sun, Settings, Globe } from 'lucide-react';

interface HeaderProps {
  language: AppLanguage;
  theme: AppTheme;
  location: LocationInfo;
  onOpenLocationModal: () => void;
  onToggleTheme: () => void;
  onChangeLanguage: (lang: AppLanguage) => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  theme,
  location,
  onOpenLocationModal,
  onToggleTheme,
  onChangeLanguage,
  onOpenSettings,
}) => {
  const t = TRANSLATIONS[language];

  const cycleLanguage = () => {
    if (language === 'bn') onChangeLanguage('ar');
    else if (language === 'ar') onChangeLanguage('en');
    else onChangeLanguage('bn');
  };

  const getLangBadge = () => {
    if (language === 'bn') return 'বাং';
    if (language === 'ar') return 'عربي';
    return 'EN';
  };

  const locationDisplay = language === 'bn' ? location.nameBn : language === 'ar' ? location.nameAr : location.name;

  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur-md bg-white/90 dark:bg-slate-900/90 border-b border-slate-200/80 dark:border-slate-800/80 px-4 py-2.5 transition-colors">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center text-white font-arabic font-bold shadow-sm shadow-emerald-700/20">
            ن
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-slate-900 dark:text-white leading-none">
              {t.appName}
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Location Trigger */}
        <button
          onClick={onOpenLocationModal}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors border border-slate-200/60 dark:border-slate-700/60 max-w-[140px] truncate"
          title={t.changeLocation}
        >
          <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span className="truncate">{locationDisplay}</span>
        </button>

        {/* Actions Zone */}
        <div className="flex items-center gap-1">
          {/* Language Switcher */}
          <button
            onClick={cycleLanguage}
            className="h-8 px-2 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 transition-colors"
            title="Change Language"
          >
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span>{getLangBadge()}</span>
          </button>

          {/* Theme Switcher */}
          <button
            onClick={onToggleTheme}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Toggle Theme"
          >
            {theme === 'light' ? (
              <Moon className="w-4 h-4 text-slate-600" />
            ) : theme === 'dark' ? (
              <span className="text-xs font-bold text-amber-400">AMOLED</span>
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={t.settings}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
