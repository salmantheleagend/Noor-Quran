import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppLanguage, LocationInfo, PrayerTimesData, CurrentWaqtStatus } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  getCurrentWaqtStatus,
  getBengaliDate,
  getHijriDate,
  formatPrayerTime12h,
  getRunningNaflPrayer,
  getNaflPrayersList,
} from '../utils/prayerTimes';
import { HADITHS_LIST } from '../data/hadithData';
import {
  BookOpen,
  Clock,
  Compass,
  Heart,
  BookmarkCheck,
  Sparkles,
  AlertTriangle,
  Sunrise,
  Sunset,
  Moon,
  ChevronRight,
  Share2,
  Check,
  Shield,
  GraduationCap,
  Volume2,
} from 'lucide-react';
import { triggerHaptic, speakArabic } from '../utils/audioPlayer';

interface HomeDashboardProps {
  language: AppLanguage;
  location: LocationInfo;
  prayerTimes: PrayerTimesData;
  onNavigate: (tab: string, extra?: unknown) => void;
  onOpenLocationModal: () => void;
  ramadanMode: boolean;
  onToggleRamadanMode?: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  language,
  location,
  prayerTimes,
  onNavigate,
  onOpenLocationModal,
  ramadanMode,
  onToggleRamadanMode,
}) => {
  const t = TRANSLATIONS[language];
  const [now, setNow] = useState<Date>(new Date());
  const [copiedHadith, setCopiedHadith] = useState(false);
  const [activeHomeView, setActiveHomeView] = useState<'standard' | 'ramadan'>('standard');
  const [showDuaType, setShowDuaType] = useState<'iftar' | 'niyyah'>('iftar');

  // 1-second timer for live countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const waqtStatus: CurrentWaqtStatus = getCurrentWaqtStatus(now, prayerTimes);
  const runningNafl = getRunningNaflPrayer(prayerTimes, now, language);
  const bengaliDate = getBengaliDate(now);
  const hijriDate = getHijriDate(now);

  // Helper to convert "HH:mm" on date to timestamp
  const parseTimeToMs = (date: Date, timeStr: string, dayOffset = 0): number => {
    const [h, m] = timeStr.split(':').map(Number);
    const d = new Date(date);
    d.setDate(d.getDate() + dayOffset);
    d.setHours(h, m, 0, 0);
    return d.getTime();
  };

  // Ramadan Fasting Calculations
  const nowMs = now.getTime();
  const fajrTodayMs = parseTimeToMs(now, prayerTimes.sahriEnd);
  const maghribTodayMs = parseTimeToMs(now, prayerTimes.iftar);
  const fajrTomorrowMs = parseTimeToMs(now, prayerTimes.sahriEnd, 1);
  const maghribYesterdayMs = parseTimeToMs(now, prayerTimes.iftar, -1);

  let isFasting = false;
  let fastingProgressPercent = 0;
  let remainingSec = 0;
  let targetEventLabelBn = '';
  let targetEventTime24 = '';

  if (nowMs >= fajrTodayMs && nowMs < maghribTodayMs) {
    // Daytime Fasting (Fajr/Sahri End until Maghrib/Iftar)
    isFasting = true;
    const totalFastingMs = maghribTodayMs - fajrTodayMs;
    const elapsedFastingMs = nowMs - fajrTodayMs;
    fastingProgressPercent = Math.min(100, Math.max(0, (elapsedFastingMs / totalFastingMs) * 100));
    remainingSec = Math.max(0, Math.floor((maghribTodayMs - nowMs) / 1000));
    targetEventLabelBn = 'ইফতার হতে বাকি';
    targetEventTime24 = prayerTimes.iftar;
  } else if (nowMs >= maghribTodayMs) {
    // Night after Iftar (Preparing for next day Sahri)
    isFasting = false;
    const totalNightMs = fajrTomorrowMs - maghribTodayMs;
    const elapsedNightMs = nowMs - maghribTodayMs;
    fastingProgressPercent = Math.min(100, Math.max(0, (elapsedNightMs / totalNightMs) * 100));
    remainingSec = Math.max(0, Math.floor((fajrTomorrowMs - nowMs) / 1000));
    targetEventLabelBn = 'সাহরি শেষ হতে বাকি';
    targetEventTime24 = prayerTimes.sahriEnd;
  } else {
    // Early Morning before Fajr
    isFasting = false;
    const totalNightMs = fajrTodayMs - maghribYesterdayMs;
    const elapsedNightMs = nowMs - maghribYesterdayMs;
    fastingProgressPercent = Math.min(100, Math.max(0, (elapsedNightMs / totalNightMs) * 100));
    remainingSec = Math.max(0, Math.floor((fajrTodayMs - nowMs) / 1000));
    targetEventLabelBn = 'সাহরি শেষ হতে বাকি';
    targetEventTime24 = prayerTimes.sahriEnd;
  }

  // Format countdown string
  const countdownHours = Math.floor(remainingSec / 3600);
  const countdownMinutes = Math.floor((remainingSec % 3600) / 60);
  const countdownSeconds = remainingSec % 60;
  const formattedCountdown = `${countdownHours.toString().padStart(2, '0')}:${countdownMinutes
    .toString()
    .padStart(2, '0')}:${countdownSeconds.toString().padStart(2, '0')}`;

  // Bengali digits converter
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const toBn = (num: number | string) =>
    num
      .toString()
      .split('')
      .map((c) => bnDigits[parseInt(c, 10)] || c)
      .join('');

  // Circular gauge geometry
  const radius = 72;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (fastingProgressPercent / 100) * circumference;

  // Today's Hadith
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  const todayHadith = HADITHS_LIST[dayOfYear % HADITHS_LIST.length];

  const getWaqtName = (name: string) => {
    if (name === 'fajr') return t.fajr;
    if (name === 'sunrise') return t.sunrise;
    if (name === 'dhuhr') return t.dhuhr;
    if (name === 'asr') return t.asr;
    if (name === 'maghrib') return t.maghrib;
    if (name === 'isha') return t.isha;
    if (name === 'prohibited_sunrise') return language === 'bn' ? 'সূর্যোদয় (নিষিদ্ধ)' : 'Sunrise (Makruh)';
    if (name === 'prohibited_zawal') return language === 'bn' ? 'দ্বিপ্রহর (নিষিদ্ধ)' : 'Noon (Makruh)';
    if (name === 'prohibited_sunset') return language === 'bn' ? 'সূর্যাস্ত (নিষিদ্ধ)' : 'Sunset (Makruh)';
    return name;
  };

  const handleCopyHadith = () => {
    const shareText = `আজকের হাদিস:\n"${todayHadith.translationBn}"\n— ${todayHadith.sourceBn}\n\n(নূর কুরআন - ইসলামিক কম্প্যানিয়ন)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareText);
      setCopiedHadith(true);
      triggerHaptic(20);
      setTimeout(() => setCopiedHadith(false), 2000);
    }
  };

  const gregorianDateStr = now.toLocaleDateString(
    language === 'bn' ? 'bn-BD' : language === 'ar' ? 'ar-EG' : 'en-US',
    {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }
  );

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto space-y-4">
      {/* Date & Location Pill Bar */}
      <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-2xl p-3 border border-slate-200/70 dark:border-slate-800/70 shadow-xs space-y-1">
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span className="font-medium text-slate-800 dark:text-slate-200">{gregorianDateStr}</span>
          <button
            onClick={onOpenLocationModal}
            className="text-emerald-700 dark:text-emerald-400 font-medium hover:underline flex items-center gap-1"
          >
            <span>{language === 'bn' ? location.nameBn : location.name}</span>
          </button>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-400 flex-wrap">
          <span>{bengaliDate.fullBn}</span>
          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
          <span className="font-uthmani font-medium">{hijriDate.fullBn}</span>
        </div>
      </div>

      {/* View Switcher Tabs: Daily Waqt vs Ramadan Fasting Mode */}
      <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-850 rounded-2xl text-xs font-semibold">
        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveHomeView('standard');
          }}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeHomeView === 'standard'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-emerald-600" />
          <span>নামাজের ওয়াক্ত</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveHomeView('ramadan');
            if (onToggleRamadanMode && !ramadanMode) {
              onToggleRamadanMode();
            }
          }}
          className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeHomeView === 'ramadan'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-emerald-800 dark:text-emerald-300 hover:text-emerald-900'
          }`}
        >
          <span className="text-amber-300">🌙</span>
          <span>রমাদান ও রোজা মোড</span>
        </button>
      </div>

      {/* PROMINENT RAMADAN VIEW vs STANDARD VIEW */}
      <AnimatePresence mode="wait">
        {activeHomeView === 'ramadan' ? (
          <motion.div
            key="ramadan"
            initial={{ opacity: 0, y: 8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className="space-y-3"
          >
            {/* Main Ramadan Hero Card with Visual Fasting Gauge */}
            <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-950 via-teal-900 to-slate-950 text-white shadow-xl shadow-emerald-950/25 border border-emerald-700/50 p-5">
              {/* Background artwork */}
              <img
                src="/src/assets/images/islamic_hero_mosque_1790957336258.jpg"
                alt="Islamic Mosque Twilight"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay pointer-events-none"
              />

              <div className="relative z-10 space-y-4">
                {/* Header Label */}
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider text-amber-300 font-bold flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                    {isFasting ? 'রোজা চলমান (দিবাভাগ)' : 'সাহরির প্রস্তুতি ও অপেক্ষা'}
                  </span>
                  <span className="text-xs text-emerald-100/90 font-medium">
                    {targetEventLabelBn}: <strong className="text-white font-mono">{formatPrayerTime12h(targetEventTime24, language)}</strong>
                  </span>
                </div>

                {/* Fasting Circular Progress Indicator */}
                <div className="flex flex-col items-center justify-center py-2">
                  <div className="relative w-44 h-44 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 170 170">
                      {/* Background track circle */}
                      <circle
                        cx="85"
                        cy="85"
                        r={radius}
                        stroke="currentColor"
                        strokeWidth={strokeWidth}
                        className="text-white/15"
                        fill="transparent"
                      />
                      {/* Progress indicator circle */}
                      <circle
                        cx="85"
                        cy="85"
                        r={radius}
                        stroke="currentColor"
                        strokeWidth={strokeWidth}
                        strokeDasharray={circumference}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        className={`transition-all duration-1000 ${
                          isFasting ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                        fill="transparent"
                      />
                    </svg>

                    {/* Inside Circle Data */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-3">
                      <span className="text-[11px] text-emerald-200/90 font-medium">
                        {isFasting ? 'ইফতার বাকি' : 'সাহরি শেষ বাকি'}
                      </span>
                      <span className="text-2xl font-bold font-mono tabular-nums tracking-tight text-white drop-shadow-sm mt-0.5">
                        {formattedCountdown}
                      </span>
                      <span className="mt-1 px-2.5 py-0.5 rounded-full bg-white/10 text-[10px] font-bold font-mono text-amber-300 backdrop-blur-xs border border-white/10">
                        {Math.round(fastingProgressPercent)}% সম্পন্ন
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-emerald-200/80 mt-2 text-center">
                    {isFasting
                      ? `সূর্যোদয় থেকে সূর্যাস্ত পর্যন্ত রোজার অগ্রগতি (${toBn(Math.round(fastingProgressPercent))}%)`
                      : 'পরবর্তী রোজার জন্য সাহরি গ্রহণ ও প্রস্তুতি নিন'}
                  </p>
                </div>

                {/* Prominent Sahri & Iftar Dual Badges */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  {/* Sahri Card */}
                  <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/15 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-200">
                      <Sunrise className="w-4 h-4 text-amber-300" />
                      <span className="font-semibold">সাহরি শেষ (ফজর)</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-white block">
                      {formatPrayerTime12h(prayerTimes.sahriEnd, language)}
                    </span>
                    <span className="text-[10px] text-amber-300 block">
                      সতর্কতা: {formatPrayerTime12h(prayerTimes.sahriWarning, language)}
                    </span>
                  </div>

                  {/* Iftar Card */}
                  <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/15 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-200">
                      <Sunset className="w-4 h-4 text-orange-400" />
                      <span className="font-semibold">ইফতার সময় (মাগরিব)</span>
                    </div>
                    <span className="text-xl font-bold font-mono text-amber-300 block">
                      {formatPrayerTime12h(prayerTimes.iftar, language)}
                    </span>
                    <span className="text-[10px] text-emerald-200 block">
                      সূর্যাস্তের মুহূর্তেই ইফতার
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Ramadan Duas Card (Iftar & Niyyah) */}
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl text-xs font-semibold">
                  <button
                    onClick={() => setShowDuaType('iftar')}
                    className={`px-3 py-1.5 rounded-lg transition-colors ${
                      showDuaType === 'iftar'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    ইফতারের দোয়া
                  </button>
                  <button
                    onClick={() => setShowDuaType('niyyah')}
                    className={`px-3 py-1.5 rounded-lg transition-colors ${
                      showDuaType === 'niyyah'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    রোজার নিয়ত
                  </button>
                </div>

                <button
                  onClick={() =>
                    speakArabic(
                      showDuaType === 'iftar'
                        ? 'ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الأَجْرُ إِنْ شَاءَ اللَّهُ'
                        : 'نَوَيْتُ أَنْ أَصُومَ غَدًا مِنْ شَهْرِ رَمَضَانَ الْمُبَارَكِ'
                    )
                  }
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="উচ্চারণ শুনুন"
                >
                  <Volume2 className="w-4 h-4 text-emerald-600" />
                </button>
              </div>

              {showDuaType === 'iftar' ? (
                <div className="space-y-2 text-xs">
                  <p className="font-uthmani text-lg leading-loose text-right text-emerald-950 dark:text-emerald-100 font-bold block" dir="rtl">
                    ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الأَجْرُ إِنْ شَاءَ اللَّهُ
                  </p>
                  <p className="text-slate-600 dark:text-emerald-300 font-medium font-bengali text-left block" dir="ltr">
                    উচ্চারণ: যাহাবায জামাউ ওয়াবতাল্লাতিল উরূক্বু ওয়া সাবাতাল আজরু ইনশাআল্লাহ।
                  </p>
                  <p className="text-slate-800 dark:text-slate-200 font-medium font-bengali text-left block" dir="ltr">
                    অর্থ: "পিপাসা দূর হলো, শিরা-উপশিরা সিক্ত হলো এবং ইনশাআল্লাহ প্রতিদান ও সওয়াব নির্ধারিত হলো।"
                  </p>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block pt-1 text-left" dir="ltr">
                    সূত্র: সুনান আবু দাউদ: ২৩৫৭ (সহিহ)
                  </span>
                </div>
              ) : (
                <div className="space-y-2 text-xs">
                  <p className="font-uthmani text-lg leading-loose text-right text-emerald-950 dark:text-emerald-100 font-bold block" dir="rtl">
                    نَوَيْتُ أَنْ أَصُومَ غَدًا مِنْ شَهْرِ رَمَضَانَ الْمُبَارَكِ فَرْضًا لَكَ يَا اللَّهُ
                  </p>
                  <p className="text-slate-600 dark:text-emerald-300 font-medium font-bengali text-left block" dir="ltr">
                    উচ্চারণ: নাওয়াইতু আন আসূমা গাদাম মিন শাহরি রামাদানাল মুবারাকি ফারদাল্লাকা ইয়া আল্লাহ।
                  </p>
                  <p className="text-slate-800 dark:text-slate-200 font-medium font-bengali text-left block" dir="ltr">
                    অর্থ: "হে আল্লাহ! আমি আগামীকাল পবিত্র রমাদান মাসের আপনার নির্দেশিত ফরজ রোজা রাখার আন্তরিক নিয়ত করছি।"
                  </p>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block pt-1 text-left" dir="ltr">
                    জ্ঞাতব্য: মুখে উচ্চারণ জরুরি নয়, অন্তরের দৃঢ় সংকল্পই নিয়তের জন্য যথেষ্ট।
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="standard"
            initial={{ opacity: 0, y: 8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className="space-y-3"
          >
            {/* STANDARD WAQT HERO CARD */}
            <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-800 via-teal-900 to-slate-950 text-white shadow-lg shadow-emerald-950/20 border border-emerald-700/40 p-5">
              {/* Background image */}
              <img
                src="/src/assets/images/islamic_hero_mosque_1790957336258.jpg"
                alt="Islamic Serene Silhouette"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover opacity-25 mix-blend-overlay pointer-events-none"
              />

              <div className="relative z-10 space-y-3">
                {/* Top Status */}
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider text-emerald-200/90 font-semibold">
                    {waqtStatus.isProhibited ? t.prohibitedTime : t.currentWaqt}
                  </span>
                  <span className="text-xs text-emerald-100/80">
                    {t.nextPrayer}: <strong className="text-white font-semibold">{getWaqtName(waqtStatus.nextWaqt)} ({formatPrayerTime12h(waqtStatus.nextWaqtTime, language)})</strong>
                  </span>
                </div>

                {/* Current Waqt Title & Countdown */}
                <div className="flex items-baseline justify-between pt-1">
                  <div>
                    <h2 className="text-3xl font-extrabold tracking-tight text-white">
                      {getWaqtName(waqtStatus.currentWaqt)}
                    </h2>
                    {waqtStatus.isProhibited && (
                      <p className="text-xs text-amber-300 font-medium flex items-center gap-1 mt-0.5">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        {waqtStatus.prohibitedReason}
                      </p>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-[11px] text-emerald-200/80 block leading-tight">{t.timeRemaining}</span>
                    <span className="text-2xl font-bold font-mono tabular-nums tracking-tight text-amber-300 drop-shadow-xs">
                      {waqtStatus.formattedRemaining}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1 pt-1">
                  <div className="w-full bg-black/30 rounded-full h-2 overflow-hidden border border-white/10">
                    <div
                      className={`h-full rounded-full transition-all duration-1000 ${
                        waqtStatus.isProhibited ? 'bg-amber-400' : 'bg-emerald-400'
                      }`}
                      style={{ width: `${waqtStatus.progressPercent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-emerald-200/70">
                    <span>ওয়াক্ত শুরু</span>
                    <span>{waqtStatus.progressPercent}% অতিবাহিত</span>
                    <span>ওয়াক্ত শেষ</span>
                  </div>
                </div>

                {/* Quick Sunrise / Sunset & Tahajjud row */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/15 text-center">
                  <div className="bg-white/5 backdrop-blur-xs rounded-xl p-2 border border-white/5">
                    <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-200">
                      <Sunrise className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t.sunrise}</span>
                    </div>
                    <span className="text-xs font-bold font-mono tabular-nums mt-0.5 block">
                      {formatPrayerTime12h(prayerTimes.sunrise, language)}
                    </span>
                  </div>

                  <div className="bg-white/5 backdrop-blur-xs rounded-xl p-2 border border-white/5">
                    <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-200">
                      <Sunset className="w-3.5 h-3.5 text-orange-400" />
                      <span>{t.iftar}</span>
                    </div>
                    <span className="text-xs font-bold font-mono tabular-nums mt-0.5 block text-amber-300">
                      {formatPrayerTime12h(prayerTimes.iftar, language)}
                    </span>
                  </div>

                  <div className="bg-white/5 backdrop-blur-xs rounded-xl p-2 border border-white/5">
                    <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-200">
                      <Moon className="w-3.5 h-3.5 text-indigo-300" />
                      <span>{t.tahajjud}</span>
                    </div>
                    <div className="mt-0.5">
                      <span className="text-[11px] font-bold font-mono tabular-nums block text-white leading-tight">
                        {formatPrayerTime12h(prayerTimes.tahajjudStart, language)}
                      </span>
                      <span className="text-[9px] font-mono text-indigo-200/90 block leading-tight">
                        শেষ: {formatPrayerTime12h(prayerTimes.tahajjudEnd, language)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sahri & Iftar Quick Access Banner (with direct switch to Ramadan view) */}
            <div className="bg-linear-to-r from-amber-500/10 via-emerald-500/10 to-teal-500/10 dark:from-amber-950/30 dark:via-emerald-950/30 dark:to-teal-950/30 rounded-2xl p-3 border border-amber-300/40 dark:border-amber-700/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-700 dark:text-amber-400 flex items-center justify-center font-bold">
                  🌙
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    সাহরি ও ইফতার সময়সূচি
                  </h4>
                  <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">
                    <span>{t.sahriEnd}: <strong>{formatPrayerTime12h(prayerTimes.sahriEnd, language)}</strong></span>
                    <span aria-hidden="true">·</span>
                    <span>{t.iftar}: <strong className="text-emerald-700 dark:text-emerald-400">{formatPrayerTime12h(prayerTimes.iftar, language)}</strong></span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setActiveHomeView('ramadan')}
                className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 flex items-center gap-0.5 px-2.5 py-1 rounded-lg bg-white/60 dark:bg-slate-800/60 shadow-2xs"
              >
                <span>রোজার অগ্রগতি</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Daily Namaz Checklist & Missed Prayer Quick Action Banner */}
            <div
              onClick={() => {
                triggerHaptic(15);
                onNavigate('prayer');
              }}
              className="bg-linear-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 dark:from-emerald-950/30 dark:via-teal-950/30 dark:to-indigo-950/30 rounded-2xl p-3 border border-emerald-300/40 dark:border-emerald-700/40 flex items-center justify-between cursor-pointer hover:border-emerald-500/60 transition-all active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                  ✓
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    দৈনিক ৫ ওয়াক্ত সালাত চেকলিস্ট ও মিস হিসাব
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">
                    আজকের ওয়াক্ত চিহ্নিত করুন এবং এই মাসে কত ওয়াক্ত মিস হয়েছে তা দেখুন
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-0.5 shrink-0">
                <span>হিসাব দেখুন</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PROMINENT RUNNING NAFL PRAYER BANNER (User Request) */}
      {runningNafl ? (
        <div
          onClick={() => {
            triggerHaptic(15);
            onNavigate('prayer');
          }}
          className="relative overflow-hidden rounded-3xl bg-linear-to-r from-emerald-800 via-teal-850 to-emerald-900 text-white p-4.5 shadow-lg shadow-emerald-950/20 border border-emerald-400/50 cursor-pointer active:scale-98 transition-all group"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
          <div className="relative z-10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 text-[11px] font-bold border border-emerald-400/40 backdrop-blur-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping" />
                <span>এখন চলমান নফল নামাজ</span>
              </span>
              <span className="text-[11px] font-mono text-amber-300 font-semibold bg-black/25 px-2.5 py-0.5 rounded-lg border border-white/10">
                বাকি: {runningNafl.remainingMinutes ? `${runningNafl.remainingMinutes} মিনিট` : 'চলমান'}
              </span>
            </div>

            <div className="flex items-baseline justify-between pt-0.5">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs">
                    {runningNafl.nameBn}
                  </h3>
                  <span className="font-arabic text-sm text-emerald-200 font-bold opacity-80" dir="rtl">
                    {runningNafl.nameAr}
                  </span>
                </div>
                <p className="text-xs text-emerald-100/90 font-medium mt-0.5">
                  {runningNafl.importanceBn} · <span className="text-amber-300 font-semibold">{runningNafl.rakatBn}</span>
                </p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] text-emerald-200/80 block uppercase">ওয়াক্তের সময়সীমা</span>
                <span className="text-sm font-bold font-mono text-white">
                  {formatPrayerTime12h(runningNafl.startTime, language)} - {formatPrayerTime12h(runningNafl.endTime, language)}
                </span>
              </div>
            </div>

            {/* Virtue snippet */}
            <div className="p-2.5 rounded-xl bg-black/25 border border-white/10 text-[11px] text-emerald-50/90 flex items-center justify-between gap-2">
              <p className="line-clamp-1 italic text-slate-100">
                ✨ {runningNafl.virtueBn}
              </p>
              <span className="shrink-0 text-amber-300 font-semibold text-[11px] flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                <span>বিস্তারিত</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* If no time-bounded nafl is currently running, show a stylish nafl bar with upcoming nafl times */
        <div
          onClick={() => {
            triggerHaptic(15);
            onNavigate('prayer');
          }}
          className="rounded-2xl bg-white dark:bg-slate-900 p-3.5 border border-slate-200/80 dark:border-slate-800 shadow-2xs cursor-pointer hover:border-emerald-300 transition-all flex items-center justify-between group"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-4.5 h-4.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>নফল নামাজের সময়সূচি ও ফজিলত</span>
                <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 px-1.5 py-0.2 rounded-md">১০টি নফল</span>
              </h4>
              <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                <span>ইশরাক: {formatPrayerTime12h(prayerTimes.ishraqStart, language)}</span>
                <span>·</span>
                <span>চাশত: {formatPrayerTime12h(prayerTimes.chashtStart, language)}</span>
                <span>·</span>
                <span>তাহাজ্জুদ: {formatPrayerTime12h(prayerTimes.tahajjudStart, language)}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400 group-hover:translate-x-1 transition-transform shrink-0">
            <span>দেখুন</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      )}

      {/* Quick Launch Action Grid */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {t.quickLinks}
          </h3>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {/* Quran */}
          <button
            onClick={() => onNavigate('quran')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center mb-1.5">
              <BookOpen className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.quran}
            </span>
          </button>

          {/* Prayer Times */}
          <button
            onClick={() => onNavigate('prayer')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-400 flex items-center justify-center mb-1.5">
              <Clock className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.prayer}
            </span>
          </button>

          {/* Tasbeeh */}
          <button
            onClick={() => onNavigate('tasbeeh')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400 flex items-center justify-center mb-1.5">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.tasbeeh}
            </span>
          </button>

          {/* Duas */}
          <button
            onClick={() => onNavigate('dua')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-400 flex items-center justify-center mb-1.5">
              <Heart className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.dua}
            </span>
          </button>

          {/* Qaida & Ampara */}
          <button
            onClick={() => onNavigate('qaida')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-400 flex items-center justify-center mb-1.5">
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.qaida}
            </span>
          </button>

          {/* Salah Guide */}
          <button
            onClick={() => onNavigate('salahGuide')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 flex items-center justify-center mb-1.5">
              <BookmarkCheck className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.salahGuide}
            </span>
          </button>

          {/* Qibla */}
          <button
            onClick={() => onNavigate('qibla')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-400 flex items-center justify-center mb-1.5">
              <Compass className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.qibla}
            </span>
          </button>

          {/* Period Tracker (Private) */}
          <button
            onClick={() => onNavigate('tracker')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-850 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 shadow-2xs transition-all active:scale-95 text-center min-h-[76px]"
          >
            <div className="w-10 h-10 rounded-xl bg-pink-100 dark:bg-pink-950/80 text-pink-700 dark:text-pink-400 flex items-center justify-center mb-1.5">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate w-full">
              {t.tracker}
            </span>
          </button>

          {/* Ruqyah Shariyyah */}
          <button
            onClick={() => onNavigate('ruqyah')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 hover:bg-emerald-100/80 dark:hover:bg-emerald-900/60 border border-emerald-300/80 dark:border-emerald-700/80 shadow-2xs transition-all active:scale-95 text-center min-h-[76px] col-span-2 sm:col-span-1"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-1.5 shadow-xs">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 truncate w-full">
              রুকইয়াহ শারইয়াহ
            </span>
          </button>
        </div>
      </div>

      {/* Daily Hadith Card */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              {t.dailyHadith}
            </h4>
          </div>
          <button
            onClick={handleCopyHadith}
            className="text-xs text-slate-500 dark:text-slate-400 hover:text-emerald-600 flex items-center gap-1 transition-colors px-2 py-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Copy / Share Hadith"
          >
            {copiedHadith ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600 font-medium">কপি হয়েছে</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5" />
                <span>শেয়ার</span>
              </>
            )}
          </button>
        </div>

        <p className="font-uthmani text-lg leading-relaxed text-right text-slate-800 dark:text-slate-200 block mb-2" dir="rtl">
          {todayHadith.arabic}
        </p>

        <p className="text-sm text-slate-700 dark:text-slate-300 leading-normal font-bengali text-left block" dir="ltr">
          "{todayHadith.translationBn}"
        </p>

        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
          <span>{todayHadith.sourceBn}</span>
          <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">{todayHadith.gradeBn}</span>
        </div>
      </div>
    </div>
  );
};
