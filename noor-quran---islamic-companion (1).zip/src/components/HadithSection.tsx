import React, { useState } from 'react';
import { AppLanguage, HadithItem } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  HADITHS_LIST,
  HADITH_CATEGORIES,
} from '../data/hadithData';
import {
  BookOpen,
  Share2,
  Check,
  Heart,
  Search,
  Sparkles,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface HadithSectionProps {
  language: AppLanguage;
  favoriteHadiths: string[];
  onToggleFavoriteHadith: (hadithId: string) => void;
}

export const HadithSection: React.FC<HadithSectionProps> = ({
  language,
  favoriteHadiths,
  onToggleFavoriteHadith,
}) => {
  const t = TRANSLATIONS[language];
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleShareHadith = (hadith: HadithItem) => {
    const text = `হাদিস: ${hadith.titleBn}\n\n${hadith.arabic}\n\nঅনুবাদ: "${hadith.translationBn}"\n\nসূত্র: ${hadith.sourceBn}\nব্যাখ্যা: ${hadith.explanationBn}\n\n(নূর কুরআন)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedId(hadith.id);
      triggerHaptic(20);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const filteredHadiths = HADITHS_LIST.filter(h => {
    const matchesCat = selectedCategory === 'all' || h.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q ||
      h.titleBn.toLowerCase().includes(q) ||
      h.translationBn.toLowerCase().includes(q) ||
      h.arabic.includes(q) ||
      h.sourceBn.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.hadith}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          সহিহ বুখারি, সহিহ মুসলিম ও বিশুদ্ধ উৎস হতে শিক্ষণীয় নির্বাচিত হাদিস সম্ভার
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="হাদিসের বিষয় বা উৎস দিয়ে খুঁজুন..."
          className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/50"
        />
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {HADITH_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1.5 rounded-full shrink-0 font-medium transition-colors ${
              selectedCategory === cat.id
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            {cat.nameBn}
          </button>
        ))}
      </div>

      {/* Hadith Cards */}
      <div className="space-y-3">
        {filteredHadiths.map((hadith) => {
          const isFav = favoriteHadiths.includes(hadith.id);
          const isCopied = copiedId === hadith.id;

          return (
            <div
              key={hadith.id}
              className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3"
            >
              {/* Top Bar */}
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {hadith.titleBn}
                  </h4>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                    {hadith.categoryBn}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleShareHadith(hadith)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="শেয়ার বা কপি করুন"
                  >
                    {isCopied ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Share2 className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <button
                    onClick={() => onToggleFavoriteHadith(hadith.id)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                      isFav ? 'text-rose-500' : 'text-slate-400 hover:bg-slate-100'
                    }`}
                    title="প্রিয় তালিকা"
                  >
                    <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Arabic */}
              <p className="font-arabic text-xl leading-loose text-right text-slate-900 dark:text-white block mb-2" dir="rtl">
                {hadith.arabic}
              </p>

              {/* Translation */}
              <p className="text-xs text-slate-800 dark:text-slate-200 font-bengali leading-relaxed text-left block mb-2" dir="ltr">
                "{hadith.translationBn}"
              </p>

              {/* Explanation & Source */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-700/60 text-[11px] space-y-1.5">
                <p className="text-slate-700 dark:text-slate-300 leading-normal">
                  <strong>সংক্ষিপ্ত ব্যাখ্যা:</strong> {hadith.explanationBn}
                </p>
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200/50 dark:border-slate-700/50">
                  <span>বর্ণনাকারী: {hadith.narratorBn}</span>
                  <span className="font-medium text-emerald-700 dark:text-emerald-400">
                    {hadith.sourceBn}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
