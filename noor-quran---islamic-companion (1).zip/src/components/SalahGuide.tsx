import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  SALAH_RAKAT_TABLE,
  SALAH_STEPS,
  WUDU_RULES,
  GHUSL_RULES,
} from '../data/namazGuideData';
import {
  BookOpen,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  User,
  Users,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface SalahGuideProps {
  language: AppLanguage;
}

export const SalahGuide: React.FC<SalahGuideProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [activeSection, setActiveSection] = useState<'rakats' | 'steps' | 'wudu' | 'ghusl'>('rakats');
  const [expandedStep, setExpandedStep] = useState<number | null>(1);
  const [viewForWomen, setViewForWomen] = useState(false);

  const toggleStep = (stepNum: number) => {
    triggerHaptic(15);
    setExpandedStep(expandedStep === stepNum ? null : stepNum);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.salahGuide}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          বিশুদ্ধ সুন্নাহ ও নির্ভরযোগ্য ফিকহ অনুযায়ী নামাজ, অজু ও গোসলের পূর্ণাঙ্গ গাইড
        </p>
      </div>

      {/* Navigation Pills */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-medium">
        <button
          onClick={() => setActiveSection('rakats')}
          className={`py-2 rounded-xl transition-all ${
            activeSection === 'rakats'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          রাকাতের হিসাব
        </button>
        <button
          onClick={() => setActiveSection('steps')}
          className={`py-2 rounded-xl transition-all ${
            activeSection === 'steps'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          ধাপে ধাপে নামাজ
        </button>
        <button
          onClick={() => setActiveSection('wudu')}
          className={`py-2 rounded-xl transition-all ${
            activeSection === 'wudu'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          অজুর নিয়ম
        </button>
        <button
          onClick={() => setActiveSection('ghusl')}
          className={`py-2 rounded-xl transition-all ${
            activeSection === 'ghusl'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          গোসলের নিয়ম
        </button>
      </div>

      {/* RAKAT BREAKDOWN SECTION */}
      {activeSection === 'rakats' && (
        <div className="space-y-3">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl text-xs text-emerald-900 dark:text-emerald-300">
            <strong>পাঁচ ওয়াক্ত নামাজের রাকাতের তালিকা:</strong> প্রত্যেক ওয়াক্তে ফরজ নামাজ পড়া অত্যাবশ্যকীয়। এর পাশাপাশি সুন্নাতে মুয়াক্কাদা ও নফল নামাজের অসীম সওয়াব রয়েছে।
          </div>

          <div className="space-y-2.5">
            {SALAH_RAKAT_TABLE.map((item, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2"
              >
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {item.waqtBn} ({item.waqtEn})
                    </h4>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2.5 py-0.5 rounded-full">
                    মোট {item.total} রাকাত
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
                  {item.breakdown.map((b, bIdx) => {
                    const isFard = b.type === 'fard';
                    const isWitr = b.type === 'witr';
                    const isSunnah = b.type === 'sunnah_muakkadah';

                    return (
                      <div
                        key={bIdx}
                        className={`p-2 rounded-xl border ${
                          isFard
                            ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-300/70 text-emerald-950 dark:text-emerald-200'
                            : isWitr
                            ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300/70 text-amber-950 dark:text-amber-200'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <span className="font-semibold block">{b.label}</span>
                        <span className="text-sm font-bold font-mono mt-0.5 block">
                          {b.rakat} রাকাত
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP-BY-STEP SALAH GUIDE */}
      {activeSection === 'steps' && (
        <div className="space-y-3">
          {/* Gender Filter Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              নামাজের পদ্ধতি প্রদর্শন মোড:
            </span>
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl text-xs">
              <button
                onClick={() => setViewForWomen(false)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors font-medium ${
                  !viewForWomen
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <User className="w-3 h-3" />
                <span>পুরুষদের পদ্ধতি</span>
              </button>
              <button
                onClick={() => setViewForWomen(true)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors font-medium ${
                  viewForWomen
                    ? 'bg-pink-700 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <Users className="w-3 h-3" />
                <span>নারীদের বিশেষ নিয়ম</span>
              </button>
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-2">
            {SALAH_STEPS.map((step) => {
              const isExpanded = expandedStep === step.stepNumber;

              return (
                <div
                  key={step.stepNumber}
                  className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden"
                >
                  <button
                    onClick={() => toggleStep(step.stepNumber)}
                    className="w-full flex items-center justify-between p-3.5 text-left hover:bg-slate-50 dark:hover:bg-slate-850 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-xs flex items-center justify-center font-mono">
                        {step.stepNumber}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {step.titleBn}
                      </h4>
                    </div>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </button>

                  {isExpanded && (
                    <div className="p-4 pt-1 border-t border-slate-100 dark:border-slate-800 text-xs space-y-3">
                      <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-bengali">
                        {step.instructionBn}
                      </p>

                      {/* Arabic recitation box if present */}
                      {step.arabic && (
                        <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/50 dark:border-emerald-900/40 space-y-1.5">
                          <p className="font-arabic text-base leading-loose text-right text-emerald-950 dark:text-emerald-100 block mb-1.5" dir="rtl">
                            {step.arabic}
                          </p>
                          {step.transliterationBn && (
                            <p className="text-slate-600 dark:text-slate-400 italic text-left block" dir="ltr">
                              উচ্চারণ: {step.transliterationBn}
                            </p>
                          )}
                          {step.meaningBn && (
                            <p className="text-slate-800 dark:text-slate-200 font-medium pt-1 border-t border-emerald-200/40 dark:border-emerald-900/40 text-left block" dir="ltr">
                              অর্থ: {step.meaningBn}
                            </p>
                          )}
                        </div>
                      )}

                      {/* Women difference note */}
                      {step.womenDifferenceBn && (
                        <div className={`p-3 rounded-xl border ${
                          viewForWomen
                            ? 'bg-pink-50/80 dark:bg-pink-950/40 border-pink-300 dark:border-pink-800 text-pink-950 dark:text-pink-200 ring-2 ring-pink-500/20'
                            : 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 text-amber-900 dark:text-amber-300'
                        }`}>
                          <strong className="block mb-1">
                            {viewForWomen ? '🌸 নারীদের জন্য পদ্ধতি:' : 'নারীদের জন্য বিশেষ নির্দেশনা:'}
                          </strong>
                          <span>{step.womenDifferenceBn}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* WUDU RULES */}
      {activeSection === 'wudu' && (
        <div className="space-y-4">
          {/* 4 Fard */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                অজুর ফরজ ৪টি (যেকোনো একটি বাদ পড়লে অজু হবে না)
              </h4>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 pt-1">
              {WUDU_RULES.fardList.map((fard, i) => (
                <li key={i} className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  {fard}
                </li>
              ))}
            </ul>
          </div>

          {/* Wudu Breakers */}
          <div className="p-4 rounded-2xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 border-b border-rose-200/60 dark:border-rose-900/40 pb-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <h4 className="text-sm font-bold text-rose-950 dark:text-rose-200">
                অজু ভঙ্গের প্রধান কারণসমূহ (৭টি)
              </h4>
            </div>
            <ul className="space-y-1.5 text-xs text-rose-900 dark:text-rose-300 pt-1">
              {WUDU_RULES.breakers.map((brk, i) => (
                <li key={i} className="p-2 rounded-xl bg-white/80 dark:bg-slate-900/80">
                  {brk}
                </li>
              ))}
            </ul>
          </div>

          {/* Sunnahs */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                অজুর প্রধান সুন্নতসমূহ
              </h4>
            </div>
            <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300 list-disc list-inside pt-1">
              {WUDU_RULES.sunnahList.map((sunnah, i) => (
                <li key={i}>{sunnah}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* GHUSL RULES */}
      {activeSection === 'ghusl' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                ফরজ গোসলের ফরজ ৩টি
              </h4>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-normal">
              ফরজ গোসলে এই তিনটি বিষয়ের কোনো একটি চুল পরিমাণ বাদ পড়লে শরীর পবিত্র হবে না:
            </p>
            <ul className="space-y-2 text-xs text-slate-800 dark:text-slate-200 pt-1">
              {GHUSL_RULES.fardList.map((fard, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/40">
                  {fard}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
