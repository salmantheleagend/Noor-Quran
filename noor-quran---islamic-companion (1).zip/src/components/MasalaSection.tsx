import React, { useState } from 'react';
import { AppLanguage, MasalaItem } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  MASALAS_LIST,
  MASALA_CATEGORIES,
} from '../data/masalaData';
import {
  Search,
  BookOpen,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface MasalaSectionProps {
  language: AppLanguage;
}

export const MasalaSection: React.FC<MasalaSectionProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(MASALAS_LIST[0].id);

  const toggleExpand = (id: string) => {
    triggerHaptic(15);
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredMasalas = MASALAS_LIST.filter(m => {
    const matchesCat = selectedCategory === 'all' || m.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q ||
      m.questionBn.toLowerCase().includes(q) ||
      m.answerBn.toLowerCase().includes(q) ||
      m.references.some(r => r.toLowerCase().includes(q));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.masala}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          দৈনন্দিন জীবনের প্রয়োজনীয় ইসলামি ফিকহ ও মাসআলা-মাসায়েল
        </p>
      </div>

      {/* Mandatory Scholarly Disclaimer Box */}
      <div className="p-3.5 rounded-2xl bg-amber-500/10 dark:bg-amber-950/20 border border-amber-300/60 dark:border-amber-800/40 flex items-start gap-2.5 text-xs text-amber-950 dark:text-amber-200">
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>শরিয়াহ সতর্কবার্তা:</strong> এই সেকশনের প্রশ্নোত্তরগুলো কেবল সাধারণ দ্বীনি শিক্ষার জন্য নির্ভরযোগ্য গ্রন্থ থেকে সংকলিত। যেকোনো বিশেষ, ব্যক্তিগত বা জটিল ফতোয়ার জন্য অনুগ্রহ করে আপনার এলাকার নির্ভরযোগ্য হক্কানী মুফতি বা আলেমের সাথে সরাসরি পরামর্শ করুন।
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="মাসআলার বিষয় বা প্রশ্ন লিখে খুঁজুন..."
          className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/50"
        />
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {MASALA_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1.5 rounded-full shrink-0 font-medium transition-colors ${
              selectedCategory === cat.id
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            {cat.nameBn}
          </button>
        ))}
      </div>

      {/* Masala Accordion List */}
      <div className="space-y-2.5">
        {filteredMasalas.map((masala) => {
          const isExpanded = expandedId === masala.id;

          return (
            <div
              key={masala.id}
              className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden"
            >
              <button
                onClick={() => toggleExpand(masala.id)}
                className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-50 dark:hover:bg-slate-850 transition-colors"
              >
                <div className="flex items-start gap-2.5 pr-2">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    প্র
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                      {masala.questionBn}
                    </h4>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-medium mt-0.5 block">
                      {masala.categoryBn}
                    </span>
                  </div>
                </div>

                {isExpanded ? (
                  <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>

              {isExpanded && (
                <div className="p-4 pt-1 border-t border-slate-100 dark:border-slate-800 text-xs space-y-3 font-bengali">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 leading-relaxed text-slate-800 dark:text-slate-200">
                    <strong className="text-emerald-700 dark:text-emerald-400 block mb-1">
                      উত্তর:
                    </strong>
                    <p>{masala.answerBn}</p>
                  </div>

                  {masala.madhabNote && (
                    <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 text-amber-900 dark:text-amber-300 text-[11px]">
                      <strong>মাযহাবগত মতভিন্নতা:</strong> {masala.madhabNote}
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                    <span>প্রামাণ্য সূত্র:</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      {masala.references.join(', ')}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
