import React from 'react';
import { AppLanguage, AppTheme, UserPreferences } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  X,
  Moon,
  Sun,
  Globe,
  Sliders,
  Volume2,
  Trash2,
  Download,
  Upload,
  Check,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';
import islamicBadge from '../assets/images/islamic_app_badge_1791133494322.jpg';

interface SettingsModalProps {
  language: AppLanguage;
  theme: AppTheme;
  preferences: UserPreferences;
  onClose: () => void;
  onChangeLanguage: (lang: AppLanguage) => void;
  onChangeTheme: (theme: AppTheme) => void;
  onUpdatePreferences: (partial: Partial<UserPreferences>) => void;
  onResetAllData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  language,
  theme,
  preferences,
  onClose,
  onChangeLanguage,
  onChangeTheme,
  onUpdatePreferences,
  onResetAllData,
}) => {
  const t = TRANSLATIONS[language];

  const handleExportBackup = () => {
    try {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(preferences));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', 'noor_quran_backup.json');
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } catch {
      alert('ব্যাকআপ নেওয়া সম্ভব হয়নি।');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-4 space-y-4 border border-slate-200 dark:border-slate-800 shadow-xl max-h-[85vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            {t.settings}
          </h3>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto flex-1 space-y-4 pr-1 text-xs">
          {/* Theme Settings */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-300 block">
              {t.theme}
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => onChangeTheme('light')}
                className={`p-2.5 rounded-xl border text-center font-medium transition-colors ${
                  theme === 'light'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                Light
              </button>
              <button
                onClick={() => onChangeTheme('dark')}
                className={`p-2.5 rounded-xl border text-center font-medium transition-colors ${
                  theme === 'dark'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                Dark
              </button>
              <button
                onClick={() => onChangeTheme('amoled')}
                className={`p-2.5 rounded-xl border text-center font-bold transition-colors ${
                  theme === 'amoled'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-black text-amber-300 border-slate-800'
                }`}
              >
                AMOLED
              </button>
            </div>
          </div>

          {/* Language Settings */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-300 block">
              {t.language}
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => onChangeLanguage('bn')}
                className={`p-2 rounded-xl border text-center font-medium transition-colors ${
                  language === 'bn'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                বাংলা
              </button>
              <button
                onClick={() => onChangeLanguage('ar')}
                className={`p-2 rounded-xl border text-center font-arabic font-medium transition-colors ${
                  language === 'ar'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                العربية
              </button>
              <button
                onClick={() => onChangeLanguage('en')}
                className={`p-2 rounded-xl border text-center font-medium transition-colors ${
                  language === 'en'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Ramadan Mode Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40">
            <div>
              <span className="font-bold text-slate-900 dark:text-white block">
                {t.ramadanMode}
              </span>
              <span className="text-[10px] text-slate-500">
                হোমস্ক্রিনে সাহরি ও ইফতার কাউন্টার বিশেষ গুরুত্ব পাবে
              </span>
            </div>
            <button
              onClick={() => onUpdatePreferences({ ramadanMode: !preferences.ramadanMode })}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                preferences.ramadanMode ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 left-1 ${
                  preferences.ramadanMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Arabic Font Selector */}
          <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80">
            <span className="font-bold text-slate-900 dark:text-white block text-xs">
              আরবি কুরআন ফন্ট নির্বাচন (Arabic Quran Font)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs">
              {[
                { id: 'amiri-quran', name: 'উসমানি কুরআন (Amiri)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-amiri-quran' },
                { id: 'noto-nastaliq', name: 'নূরানী / নাস্তালিক (Nastaliq)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-noto-nastaliq' },
                { id: 'noto-naskh', name: 'আধুনিক নাসখ (Noto)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-noto-naskh' },
                { id: 'scheherazade', name: 'শাহারাজাদ (Scheherazade)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-scheherazade' },
                { id: 'amiri', name: 'ক্লাসিক আমিরি (Amiri)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-amiri' },
                { id: 'lateef', name: 'লতিফ লিপি (Lateef)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ', fontClass: 'font-arabic-lateef' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => {
                    triggerHaptic(15);
                    onUpdatePreferences({ arabicFont: f.id as any });
                  }}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    (preferences.arabicFont || 'amiri-quran') === f.id
                      ? 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-500 text-emerald-950 dark:text-emerald-100 ring-1 ring-emerald-500 font-bold'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <span className="text-[11px] font-semibold block">{f.name}</span>
                  <span className={`${f.fontClass} text-base font-bold text-right block mt-1 text-emerald-800 dark:text-emerald-300`} dir="rtl">
                    {f.preview}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Feedback & Sounds */}
          <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80">
            <div className="flex items-center justify-between">
              <span className="text-slate-700 dark:text-slate-300 font-medium">শব্দ / সাউন্ড এফেক্ট</span>
              <input
                type="checkbox"
                checked={preferences.soundEnabled}
                onChange={(e) => onUpdatePreferences({ soundEnabled: e.target.checked })}
                className="accent-emerald-600 w-4 h-4"
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-700 dark:text-slate-300 font-medium">ট্যাকটাইল ভাইব্রেশন (কম্পন)</span>
              <input
                type="checkbox"
                checked={preferences.vibrationEnabled}
                onChange={(e) => onUpdatePreferences({ vibrationEnabled: e.target.checked })}
                className="accent-emerald-600 w-4 h-4"
              />
            </div>
          </div>

          {/* Islamic Heritage Card */}
          <div className="p-3.5 rounded-2xl bg-linear-to-r from-emerald-950 via-teal-950 to-slate-950 border border-emerald-700/50 text-white space-y-2">
            <div className="flex items-center gap-2.5">
              <div className="w-11 h-11 rounded-xl overflow-hidden border-2 border-amber-400/80 shrink-0 bg-slate-900 shadow-sm">
                <img
                  src={islamicBadge}
                  onError={(e) => {
                    e.currentTarget.src = '/islamic_badge.jpg';
                  }}
                  alt="নূর কুরআন প্রতীক (Holy Quran Sacred Emblem)"
                  className="w-full h-full object-cover"
                  loading="eager"
                />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300 block">
                  পরিকল্পনা ও প্রতিষ্ঠাতা
                </span>
                <h5 className="text-xs font-bold text-white">
                  Engr. Mohammad Muzahidul Islam (Salman)
                </h5>
                <p className="text-[10px] text-emerald-200">
                  Electrical Engineer · নূর কুরআন খেদমত
                </p>
              </div>
            </div>
            <p className="text-[10px] text-emerald-100/80 font-bengali leading-relaxed pt-1 border-t border-white/10 italic">
              "যদি সামান্যতমও উপকৃত হন তবে এই অধমের জন্য দোয়া করবেন এবং আপনার সাধ্যমতো চারপাশের অসহায় মানুষের পাশে দাঁড়াবেন।"
            </p>
          </div>

          {/* Data Backup & Wipe */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <button
              onClick={handleExportBackup}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 font-medium flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ব্যাকআপ ডাউনলোড করুন</span>
            </button>

            <button
              onClick={() => {
                if (confirm('আপনি কি নিশ্চিত যে সমস্ত ডেটা ও সেটিংস রিসেট করতে চান?')) {
                  onResetAllData();
                  onClose();
                }
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 font-medium flex items-center justify-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>সকল ডেটা ফ্যাক্টরি রিসেট করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
