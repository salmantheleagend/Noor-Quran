import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  Compass,
  GraduationCap,
  Sparkles,
  BookOpen,
  BookmarkCheck,
  Shield,
  HelpCircle,
  Bell,
  Settings,
  ChevronRight,
  Award,
  Heart,
  HandHeart,
  HeartHandshake,
  Briefcase,
  Clock,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';
import { DesignerProfileModal } from './DesignerProfileModal';
import islamicBadge from '../assets/images/islamic_app_badge_1791133494322.jpg';

interface MoreMenuProps {
  language: AppLanguage;
  onSelectFeature: (featureId: string) => void;
  onOpenSettings: () => void;
}

export const MoreMenu: React.FC<MoreMenuProps> = ({
  language,
  onSelectFeature,
  onOpenSettings,
}) => {
  const t = TRANSLATIONS[language];
  const [showDesignerModal, setShowDesignerModal] = useState(false);

  const menuItems = [
    {
      id: 'prayer',
      title: 'নামাজের সময়সূচি ও চেকলিস্ট (Prayer Times)',
      desc: 'আজকের ৫ ওয়াক্ত সালাত, নফল সময়, আজান ও মিস নামাজের হিসাব',
      icon: <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-50 dark:bg-emerald-950/50',
      badge: '৫ ওয়াক্ত ও ট্র্যাকার',
    },
    {
      id: 'ruqyah',
      title: 'রুকইয়াহ শারইয়াহ (Ruqyah Shariyyah)',
      desc: 'বদনজর, জাদু-সিহর, জিনের ভয় ও অসুস্থতা থেকে কুরআন-সুন্নাহর আত্মিক শিফা',
      icon: <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-50 dark:bg-emerald-950/50',
      badge: '১০টি ক্যাটাগরি',
    },
    {
      id: 'qibla',
      title: t.qibla,
      desc: 'লাইভ কম্পাস ও কাবার দিকনির্ণয়',
      icon: <Compass className="w-5 h-5 text-sky-600 dark:text-sky-400" />,
      bg: 'bg-sky-50 dark:bg-sky-950/50',
    },
    {
      id: 'qaida',
      title: t.qaida,
      desc: 'নূরানী কায়দা অডিও শিক্ষা ও আমপারা',
      icon: <GraduationCap className="w-5 h-5 text-purple-600 dark:text-purple-400" />,
      bg: 'bg-purple-50 dark:bg-purple-950/50',
    },
    {
      id: 'tasbeeh',
      title: t.tasbeeh,
      desc: 'ডিজিটাল তাসবীহ ও জিকির কাউন্টার',
      icon: <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-50 dark:bg-amber-950/50',
    },
    {
      id: 'hadith',
      title: t.hadith,
      desc: 'সহিহ হাদিস সংকলন ও প্রতিদিনের হাদিস',
      icon: <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-50 dark:bg-emerald-950/50',
    },
    {
      id: 'salahGuide',
      title: t.salahGuide,
      desc: 'অজু, গোসল ও নামাজের পূর্ণাঙ্গ চিত্র গাইড',
      icon: <BookmarkCheck className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
      bg: 'bg-teal-50 dark:bg-teal-950/50',
    },
    {
      id: 'masala',
      title: t.masala,
      desc: 'দৈনন্দিন ফিকহ ও প্রশ্নোত্তর',
      icon: <HelpCircle className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      bg: 'bg-blue-50 dark:bg-blue-950/50',
    },
    {
      id: 'tracker',
      title: t.tracker,
      desc: 'গোপন ও ১০০% সুরক্ষিত পবিত্রতা ট্র্যাকার',
      icon: <Shield className="w-5 h-5 text-pink-600 dark:text-pink-400" />,
      bg: 'bg-pink-50 dark:bg-pink-950/50',
    },
  ];

  const handleItemClick = (id: string) => {
    triggerHaptic(15);
    onSelectFeature(id);
  };

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          ইসলামিক অন্যান্য বিভাগ
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          প্রয়োজনীয় সকল ইসলামিক ফিচার এক নজরে
        </p>
      </div>

      {/* Menu Grid */}
      <div className="space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleItemClick(item.id)}
            className={`w-full flex items-center justify-between p-3.5 rounded-2xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-850 border shadow-2xs transition-all active:scale-[0.99] text-left ${
              item.id === 'charity'
                ? 'border-rose-200/80 dark:border-rose-900/60 ring-1 ring-rose-500/20'
                : 'border-slate-200/80 dark:border-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl ${item.bg} flex items-center justify-center shrink-0`}>
                {item.icon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {item.title}
                  </h4>
                  {item.badge && (
                    <span className="text-[10px] bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold px-2 py-0.2 rounded-full border border-rose-300/40">
                      {item.badge}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {item.desc}
                </p>
              </div>
            </div>

            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
          </button>
        ))}
      </div>

      {/* Settings Row */}
      <button
        onClick={() => {
          triggerHaptic(15);
          onOpenSettings();
        }}
        className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Settings className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          <span className="text-sm font-bold">{t.settings}</span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400" />
      </button>

      {/* Owner Profile Card */}
      <div
        onClick={() => {
          triggerHaptic(15);
          setShowDesignerModal(true);
        }}
        className="cursor-pointer p-4 sm:p-5 rounded-3xl bg-linear-to-br from-emerald-900 via-teal-900 to-slate-950 text-white shadow-md border border-emerald-600/40 hover:border-amber-400/60 transition-all active:scale-[0.99] space-y-2.5"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-amber-400/80 shadow-md shrink-0 bg-slate-900">
              <img
                src={islamicBadge}
                onError={(e) => {
                  e.currentTarget.src = '/islamic_badge.jpg';
                }}
                alt="নূর কুরআন প্রতীক"
                className="w-full h-full object-cover"
                loading="eager"
              />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300 block">
                পরিকল্পনা ও প্রতিষ্ঠাতা
              </span>
              <h4 className="text-sm sm:text-base font-bold text-white">
                Engr. Mohammad Muzahidul Islam (Salman)
              </h4>
              <p className="text-[11px] text-emerald-200 font-medium">
                Electrical Engineer · নূর কুরআন খেদমত
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs text-amber-300 font-semibold bg-white/10 px-2.5 py-1 rounded-xl shrink-0">
            <span>পরিচিতি ও বার্তা</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </div>

        <blockquote className="text-[11px] sm:text-xs text-emerald-100/90 leading-relaxed font-bengali italic border-l-2 border-amber-400 pl-2.5">
          "যদি এই অ্যাপ থেকে আপনি সামান্যতমও উপকৃত হন, তবে আমার জন্য দোয়ার পাশাপাশি আপনার সাধ্যমতো আপনার চারপাশের অসহায় মানুষের পাশে দাঁড়াবেন।"
        </blockquote>

        <div className="flex items-center justify-between pt-1 text-[11px] text-emerald-200 border-t border-white/10">
          <span className="flex items-center gap-1">
            <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
            <span>সদকায়ে জারিয়ার আবেদন</span>
          </span>
          <span className="text-amber-300 font-medium hover:underline flex items-center gap-0.5">
            বিস্তারিত বার্তা ও দোয়া দেখুন →
          </span>
        </div>
      </div>

      {/* USER REQUESTED: CONTRIBUTE TO CHARITY PLACED AT THE VERY BOTTOM */}
      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800">
        <button
          onClick={() => handleItemClick('charity')}
          className="w-full flex items-center justify-between p-4 rounded-3xl bg-linear-to-r from-rose-50 via-pink-50 to-amber-50 dark:from-rose-950/40 dark:via-pink-950/30 dark:to-slate-900 border-2 border-rose-300/80 dark:border-rose-900/60 shadow-md transition-all active:scale-[0.99] text-left cursor-pointer hover:shadow-lg"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  দান ও অসহায়দের সাহায্য (Contribute to Charity)
                </h4>
                <span className="text-[10px] bg-rose-600 text-white font-bold px-2 py-0.5 rounded-full shadow-xs">
                  সদকা ও খেদমত
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                সদকা, এতিম-দুস্থদের সহায়তা, দানের নিয়ম ও ব্যক্তিগত চ্যারিটি ট্র্যাকার
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-rose-500 shrink-0" />
        </button>
      </div>

      {/* Designer Profile Modal */}
      <DesignerProfileModal
        isOpen={showDesignerModal}
        onClose={() => setShowDesignerModal(false)}
        language={language}
        onOpenCharity={() => onSelectFeature('charity')}
      />
    </div>
  );
};
