import React, { useState, useEffect } from 'react';
import { AppLanguage } from '../types';
import {
  Heart,
  HandHeart,
  ChevronLeft,
  Sparkles,
  BookOpen,
  Award,
  Users,
  ShieldCheck,
  Check,
  Plus,
  Trash2,
  Calendar,
  Gift,
  Coins,
  Droplets,
  Stethoscope,
  GraduationCap,
  Shirt,
  Home,
  AlertCircle,
  ExternalLink,
  Target,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';
import islamicBadge from '../assets/images/islamic_app_badge_1791133494322.jpg';

interface CharityLogItem {
  id: string;
  date: string;
  cause: string;
  amount: number;
  itemDescription?: string;
  recipientCategory: string;
  note?: string;
}

interface CharitySectionProps {
  language: AppLanguage;
  onBack: () => void;
}

const STORAGE_KEY_CHARITY_LOGS = 'noor_quran_charity_logs_v1';
const STORAGE_KEY_CHARITY_GOAL = 'noor_quran_charity_monthly_goal_v1';

export const CharitySection: React.FC<CharitySectionProps> = ({
  language,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'causes' | 'tracker' | 'hadith' | 'guidelines'>('causes');

  // Charity Logs State from localStorage
  const [logs, setLogs] = useState<CharityLogItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CHARITY_LOGS);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [
      {
        id: 'sample-1',
        date: new Date().toISOString().split('T')[0],
        cause: 'খাদ্য সহায়তা',
        amount: 500,
        itemDescription: 'অসহায় দিনমজুর পরিবারের জন্য চাল ও ডাল',
        recipientCategory: 'দরিদ্র প্রতিবেশী',
        note: 'আল্লাহ কবুল করুন',
      },
    ];
  });

  // Monthly Goal State
  const [monthlyGoal, setMonthlyGoal] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CHARITY_GOAL);
      if (saved) return parseInt(saved, 10);
    } catch {
      // ignore
    }
    return 1000;
  });

  const [isAddingLog, setIsAddingLog] = useState(false);
  const [newCause, setNewCause] = useState('খাদ্য সহায়তা');
  const [newAmount, setNewAmount] = useState('');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newCategory, setNewCategory] = useState('দরিদ্র প্রতিবেশী');
  const [newNote, setNewNote] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CHARITY_LOGS, JSON.stringify(logs));
    } catch {
      // ignore
    }
  }, [logs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CHARITY_GOAL, monthlyGoal.toString());
    } catch {
      // ignore
    }
  }, [monthlyGoal]);

  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(newAmount) || 0;
    if (amt <= 0 && !newItemDesc.trim()) {
      return;
    }
    triggerHaptic(25);
    const newEntry: CharityLogItem = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      cause: newCause,
      amount: amt,
      itemDescription: newItemDesc.trim() || undefined,
      recipientCategory: newCategory,
      note: newNote.trim() || undefined,
    };
    setLogs([newEntry, ...logs]);
    setNewAmount('');
    setNewItemDesc('');
    setNewNote('');
    setIsAddingLog(false);
  };

  const handleDeleteLog = (id: string) => {
    triggerHaptic(15);
    setLogs(logs.filter((l) => l.id !== id));
  };

  // Calculations
  const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
  const thisMonthLogs = logs.filter((l) => l.date.startsWith(currentMonth));
  const thisMonthTotal = thisMonthLogs.reduce((sum, l) => sum + (l.amount || 0), 0);
  const totalAllTime = logs.reduce((sum, l) => sum + (l.amount || 0), 0);
  const goalPercent = monthlyGoal > 0 ? Math.min(100, Math.round((thisMonthTotal / monthlyGoal) * 100)) : 0;

  // Actionable Charitable Causes
  const CHARITY_CAUSES = [
    {
      id: 'food',
      title: 'ক্ষুধার্ত ও দরিদ্র পরিবারের খাদ্য সহায়তা',
      icon: <Gift className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      badge: 'সর্বোত্তম সদকা',
      bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200/80 dark:border-amber-800/60',
      description: 'অনাহারে বা অর্ধাহারে থাকা অসহায় দিনমজুর, রিকশাচালক ও সুবিধাবঞ্চিত পরিবারকে খাদ্য পৌঁছে দেওয়া।',
      actionTips: [
        'চাল, ডাল, তেল, আলু ও লবণের একটি জরুরি খাদ্যব্যাগ (৳৫০০–৳১০০০) কোনো অভাবী ঘরে পৌঁছে দিন।',
        'রাস্তার ছিন্নমূল শিশু বা পথচারী মিসকিনদের একবেলার ভালো খাবার খাওয়ান।',
        'প্রতিবেশীদের মধ্যে যারা মুখ ফুটে অভাব প্রকাশ করতে পারেন না, তাদের গোপনে বাজার করে দিন।',
      ],
      virtueHadith: '"সর্বোত্তম আমল হলো ক্ষুধার্তকে আহার করানো এবং পরিচিত-অপরিচিত সকলকে সালাম দেওয়া।" — সহিহ বুখারি: ১২',
    },
    {
      id: 'orphan',
      title: 'এতিম ও অসহায় শিশুদের শিক্ষা ও বস্ত্র সহায়তা',
      icon: <GraduationCap className="w-5 h-5 text-purple-600 dark:text-purple-400" />,
      badge: 'জান্নাতে নবীর সান্নিধ্য',
      bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200/80 dark:border-purple-800/60',
      description: 'অভাবের কারণে পড়ালেখা বন্ধ হয়ে যাওয়া শিশু ও পিতৃহীন এতিমদের পড়ালেখার খরচ ও প্রয়োজনীয় উপকরণ বহন করা।',
      actionTips: [
        'কোনো অসচ্ছল শিক্ষার্থীর খাতা, কলম, বই বা স্কুল ফি (৳২০০–৳৫০০) দিয়ে পাশে দাঁড়ান।',
        'এতিমখানায় বসবাসকারী এতিম শিশুর এক বা দুই সেট পরিচ্ছন্ন পোশাক উপহার দিন।',
        'এতিম শিশুর অভিভাবকত্ব বা মাসিক নিয়মিত সামান্য স্পনসরশিপের জিম্মাদারি নিন।',
      ],
      virtueHadith: '"আমি ও এতিমের দায়িত্ব গ্রহণকারী জান্নাতে এভাবে কাছাকাছি থাকব (শাহাদাত ও মধ্যমা আঙুল একত্র করে দেখালেন)।" — সহিহ বুখারি: ৫৩০৪',
    },
    {
      id: 'medical',
      title: 'দুস্থ ও অসচ্ছল রোগীর জরুরি চিকিৎসা সহায়তা',
      icon: <Stethoscope className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
      badge: 'জীবন বাঁচানোর সওয়াব',
      bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200/80 dark:border-rose-800/60',
      description: 'টাকার অভাবে ওষুধ বা ডাক্তার দেখাতে না পারা অসহায় রোগীদের পাশে নগদ অর্থ ও প্রেসক্রিপশনের ওষুধ কিনে দাঁড়ানো।',
      actionTips: [
        'সরকারি হাসপাতালে অসহায় রোগীর প্রেসক্রিপশন অনুযায়ী প্রয়োজনীয় ওষুধ কিনে দিন।',
        'জরুরি অপারেশনে অর্থের অভাবে আটকে থাকা দুস্থ ব্যক্তির ফান্ডে সাধ্যমতো অংশ নিন।',
        'মুমূর্ষু রোগীর জন্য স্বেচ্ছায় রক্তদান করুন, যা অর্থ ছাড়াও এক অমূল্য মানবিক সদকা।',
      ],
      virtueHadith: '"যে ব্যক্তি কোনো মুসলিমের পার্থিব বিপদ দূর করে দেবে, আল্লাহ কিয়ামতের দিন তার বিপদসমূহ দূর করে দেবেন।" — সহিহ মুসলিম: ২৬৯৯',
    },
    {
      id: 'water',
      title: 'সুপেয় পানির নলকূপ ও স্থায়ী ব্যবস্থা (সাদাকায়ে জারিয়া)',
      icon: <Droplets className="w-5 h-5 text-sky-600 dark:text-sky-400" />,
      badge: 'চিরস্থায়ী সওয়াব',
      bg: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200/80 dark:border-sky-800/60',
      description: 'যেখানে মানুষ মাইলের পর মাইল হেঁটে ঘোলা বা লবণাক্ত পানি খায়, সেখানে নিরাপদ সুপেয় পানির নলকূপ বা ফিল্টার স্থাপন।',
      actionTips: [
        'কয়েকজন বন্ধু বা আত্মীয় মিলে উপকূলীয় এলাকায় একটি সাধারণ টিউবওয়েল বা ফিল্টার স্থাপন করতে পারেন।',
        'স্থানীয় মসজিদ, মাদ্রাসা বা রাস্তার পাশে তৃষ্ণার্ত পথচারীর জন্য সুপেয় পানির ড্রাম/ফিল্টার বসিয়ে দিন।',
        'নিজের বা মৃত পিতামাতার নামে সাদাকায়ে জারিয়া হিসেবে পানির ব্যবস্থা করুন।',
      ],
      virtueHadith: 'রাসূলুল্লাহ (সা.)-কে জিজ্ঞাসা করা হলো, "কোন সদকা সর্বোত্তম?" তিনি বললেন: "পানি পান করানো।" — সুনান আবু দাউদ: ১৬৭৯',
    },
    {
      id: 'winter',
      title: 'শীতবস্ত্র ও প্রাকৃতিক দুর্যোগে জরুরি ত্রাণ',
      icon: <Shirt className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
      badge: 'তাৎক্ষণিক প্রয়োজন',
      bg: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200/80 dark:border-teal-800/60',
      description: 'তীব্র শীতের রাতে খোলা আকাশের নিচে থাকা শীতার্ত মানুষ বা বন্যা-ঘূর্ণিঝড়ে সর্বস্ব হারানোদের তাৎক্ষণিক সহায়তা।',
      actionTips: [
        'একটি বা দুটি নতুন গরম কম্বল (৳৩০০–৳৬০০) কিনে রাতের বেলা রাস্তায় থাকা শীতার্তকে গায়ে জড়িয়ে দিন।',
        'নিজের ব্যবহৃত ভালো ও পরিষ্কার শীতের কাপড় ধুয়ে অভাবীদের সম্মানের সাথে উপহার দিন।',
        'বন্যা বা দুর্যোগের সময় শুকনো খাবার ও খাবার স্যালাইন সংগ্রহ করে ক্ষতিগ্রস্তদের কাছে পাঠান।',
      ],
      virtueHadith: '"যে কোনো মুসলমানকে বস্ত্রহীন অবস্থায় পোশাক পরাবে, আল্লাহ তাকে জান্নাতের সবুজ পোশাক পরাবেন।" — তিরমিজি: ২৪৪৯',
    },
    {
      id: 'livelihood',
      title: 'অসহায় পরিবার ও বিধবাদের স্থায়ী স্বাবলম্বীকরণ',
      icon: <Home className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      badge: 'ভিক্ষামুক্ত সমাজ',
      bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200/80 dark:border-emerald-800/60',
      description: 'এককালীন খাবার দেওয়ার চেয়ে কোনো পরিবারকে কর্মসংস্থানের পথ তৈরি করে দিয়ে আজীবনের জন্য আত্মনির্ভরশীল করা।',
      actionTips: [
        'একজন অসহায় বিধবা নারীকে একটি সেলাই মেশিন (৳৫০০০–৳৭০০০) কিনে দিন।',
        'দরিদ্র যুবককে একটি ভ্যানগাড়ি বা ক্ষুদ্র ব্যবসার সামগ্রী দিয়ে আয়ের সুযোগ তৈরি করে দিন।',
        'গ্রামের কোনো অভাবী পরিবারকে ছাগল, হাঁস-মুরগি বা গাভী কিনে দিয়ে স্বাবলম্বী করুন।',
      ],
      virtueHadith: '"বিধবা ও মিসকিনের দেখাশোনাকারী ব্যক্তি আল্লাহর রাস্তায় জিহাদকারীর সমতুল্য।" — সহিহ বুখারি: ৫৩৫৩',
    },
  ];

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Top Header Row */}
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={() => {
            triggerHaptic(15);
            onBack();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>মেন্যুতে ফিরে যান</span>
        </button>

        <span className="text-xs text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-200/60 dark:border-emerald-800/60 flex items-center gap-1.5">
          <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
          <span>সদকা ও জনকল্যাণ</span>
        </span>
      </div>

      {/* Founder's Humanitarian Appeal Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-900 via-teal-900 to-slate-950 p-5 sm:p-6 text-white shadow-lg border border-emerald-700/50">
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
          {/* Islamic Emblem */}
          <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl overflow-hidden border-2 border-amber-300 shadow-md shrink-0 bg-slate-900">
            <img
              src={islamicBadge}
              onError={(e) => {
                e.currentTarget.src = '/islamic_badge.jpg';
              }}
              alt="নূর কুরআন প্রতীক"
              className="w-full h-full object-cover"
              loading="eager"
            />
          </div>

          <div className="space-y-1.5 flex-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[11px] font-semibold border border-amber-300/30">
              <Sparkles className="w-3 h-3" />
              <span>উদ্যোক্তার মানবিক আবেদন ও নিবেদন</span>
            </div>

            <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
              Engr. Mohammad Muzahidul Islam (Salman)
            </h3>
            <p className="text-xs text-emerald-200 font-medium">
              Electrical Engineer · পরিকল্পনাকারী ও প্রতিষ্ঠাতা, নূর কুরআন
            </p>

            <blockquote className="mt-2 text-xs sm:text-sm text-emerald-100/90 font-bengali leading-relaxed pt-2 border-t border-white/10 italic">
              "প্রিয় দ্বীনি ভাই ও বোনেরা, আসসালামু আলাইকুম। এই অ্যাপটি ব্যবহার করে যদি আপনি সামান্যতমও উপকৃত হয়ে থাকেন, তবে এই অধম এবং আমার পিতা-মাতার জন্য মহান আল্লাহর দরবারে আন্তরিক দোয়া করবেন।
              <strong className="text-amber-300 not-italic block mt-1">
                আর আপনার পক্ষে সম্ভব হলে আপনার সাধ্যমতো আপনার চারপাশের অসহায়, দরিদ্র ও দুস্থ মানুষের পাশে দাঁড়াবেন, তাদের সাহায্য-সহযোগিতা করবেন।
              </strong>
              মানুষের মুখে এক চিলতে হাসি ফোটানো ও কারও বিপদে একটু সহায় হওয়াটাই হবে আমার জন্য পৃথিবীর সবচেয়ে বড় উপহার।"
            </blockquote>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="grid grid-cols-4 gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80 text-xs">
        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveTab('causes');
          }}
          className={`py-2 px-1 rounded-xl font-bold transition-all text-center ${
            activeTab === 'causes'
              ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          দানের খাতসমূহ
        </button>

        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveTab('tracker');
          }}
          className={`py-2 px-1 rounded-xl font-bold transition-all text-center relative ${
            activeTab === 'tracker'
              ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          সদকা ট্র্যাকার
          {logs.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-emerald-500 absolute top-1.5 right-1.5" />
          )}
        </button>

        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveTab('guidelines');
          }}
          className={`py-2 px-1 rounded-xl font-bold transition-all text-center ${
            activeTab === 'guidelines'
              ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          হকদার নির্দেশিকা
        </button>

        <button
          onClick={() => {
            triggerHaptic(15);
            setActiveTab('hadith');
          }}
          className={`py-2 px-1 rounded-xl font-bold transition-all text-center ${
            activeTab === 'hadith'
              ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          ফজিলত ও আদব
        </button>
      </div>

      {/* Tab 1: Actionable Causes */}
      {activeTab === 'causes' && (
        <div className="space-y-3.5">
          <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 px-1">
            <span className="font-bold text-slate-800 dark:text-slate-200">
              কীভাবে সরাসরি সাধ্যমতো সহায়তা করবেন:
            </span>
            <span>৬টি বাস্তবসম্মত ক্ষেত্র</span>
          </div>

          <div className="space-y-3">
            {CHARITY_CAUSES.map((cause) => (
              <div
                key={cause.id}
                className={`p-4 rounded-3xl border ${cause.bg} space-y-3 shadow-xs transition-all`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-white dark:bg-slate-900 shadow-xs flex items-center justify-center shrink-0">
                      {cause.icon}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {cause.title}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        {cause.description}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/80 dark:bg-slate-900/80 text-emerald-800 dark:text-emerald-300 shrink-0 border border-emerald-300/40">
                    {cause.badge}
                  </span>
                </div>

                {/* Practical Action Tips */}
                <div className="p-3 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200/50 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    বাস্তবসম্মত করণীয় পরামর্শ:
                  </span>
                  <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 pl-1 font-bengali">
                    {cause.actionTips.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Virtue Hadith Note */}
                <p className="text-[11px] text-slate-600 dark:text-slate-400 font-bengali italic border-l-2 border-emerald-500 pl-2.5">
                  {cause.virtueHadith}
                </p>

                {/* Quick Track Button */}
                <div className="pt-1 flex justify-end">
                  <button
                    onClick={() => {
                      triggerHaptic(15);
                      setNewCause(cause.title.split(' ')[0] + ' সহায়তা');
                      setActiveTab('tracker');
                      setIsAddingLog(true);
                    }}
                    className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>এই খাতে দান রেকর্ড করুন</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Sadaqah Tracker */}
      {activeTab === 'tracker' && (
        <div className="space-y-4">
          {/* Monthly Progress Card */}
          <div className="p-4 sm:p-5 rounded-3xl bg-linear-to-r from-emerald-800 to-teal-900 text-white shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300 block">
                  চলতি মাসের সদকা ও সহায়তা
                </span>
                <h4 className="text-2xl font-bold font-mono">
                  ৳{thisMonthTotal.toLocaleString()}
                </h4>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-emerald-200 block">মাসিক সংকল্প (লক্ষ্য):</span>
                <span className="text-sm font-bold font-mono text-amber-300">
                  ৳{monthlyGoal.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="w-full h-2.5 rounded-full bg-white/20 overflow-hidden">
                <div
                  className="h-full bg-linear-to-r from-amber-300 to-emerald-300 rounded-full transition-all duration-500"
                  style={{ width: `${goalPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-emerald-200">
                <span>লক্ষ্যের {goalPercent}% সম্পন্ন</span>
                <span>সর্বমোট দান: ৳{totalAllTime.toLocaleString()} ({logs.length}টি এন্ট্রি)</span>
              </div>
            </div>

            {/* Change Goal Mini form */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
              <span className="text-emerald-200 text-[11px]">মাসিক দানের লক্ষ্য পরিবর্তন:</span>
              <div className="flex items-center gap-1.5">
                {[500, 1000, 2000, 5000].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => {
                      triggerHaptic(15);
                      setMonthlyGoal(amt);
                    }}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-mono transition-colors ${
                      monthlyGoal === amt
                        ? 'bg-amber-400 text-slate-950 font-bold'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                  >
                    ৳{amt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Add New Charity Log Button / Form */}
          {!isAddingLog ? (
            <button
              onClick={() => {
                triggerHaptic(15);
                setIsAddingLog(true);
              }}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.99]"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন দান / সদকা এন্ট্রি যুক্ত করুন</span>
            </button>
          ) : (
            <form
              onSubmit={handleAddLog}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-emerald-500/40 dark:border-slate-800 shadow-md space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <HandHeart className="w-4 h-4 text-emerald-600" />
                  <span>দানের বিবরণ সংরক্ষণ করুন (গোপন ও ব্যক্তিগত)</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setIsAddingLog(false)}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  বাতিল
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    টাকার পরিমাণ (৳):
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    placeholder="যেমন: ৫০০"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    দানের খাত / ধরন:
                  </label>
                  <select
                    value={newCause}
                    onChange={(e) => setNewCause(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                  >
                    <option value="খাদ্য সহায়তা">খাদ্য ও নিত্যপণ্য সহায়তা</option>
                    <option value="চিকিৎসা সহায়তা">ওষুধ ও চিকিৎসা সহায়তা</option>
                    <option value="এতিম ও শিক্ষা">এতিম ও ছাত্র শিক্ষা সহায়তা</option>
                    <option value="নলকূপ / সুপেয় পানি">নলকূপ / সুপেয় পানি (সাদাকায়ে জারিয়া)</option>
                    <option value="শীতবস্ত্র ও ত্রাণ">শীতবস্ত্র / জরুরি ত্রাণ</option>
                    <option value="স্বাবলম্বীকরণ">স্বাবলম্বীকরণ ও কর্মসংস্থান</option>
                    <option value="সাধারণ সদকা">সাধারণ সদকা / দান</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    কার কাছে পৌঁছে দিয়েছেন (প্রাপক):
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                  >
                    <option value="দরিদ্র প্রতিবেশী">দরিদ্র প্রতিবেশী</option>
                    <option value="অসচ্ছল নিকটাত্মীয়">অসচ্ছল নিকটাত্মীয়</option>
                    <option value="এতিমখানা / মাদ্রাসা">এতিমখানা / মাদ্রাসা শিক্ষার্থী</option>
                    <option value="ছিন্নমূল / পথচারী">ছিন্নমূল / পথচারী মিসকিন</option>
                    <option value="হাসপাতালের দুস্থ রোগী">হাসপাতালের দুস্থ রোগী</option>
                    <option value="স্বচ্ছ দাতব্য সংস্থা">স্বচ্ছ ইসলামিক দাতব্য সংস্থা</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    উপহারের বর্ণনা (যদি পণ্য বা কাপড় হয়):
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: ১টি গরম কম্বল বা ওষুধ"
                    value={newItemDesc}
                    onChange={(e) => setNewItemDesc(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1 text-xs">
                  ব্যক্তিগত নোট বা দোয়া (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  placeholder="যেমন: মহান আল্লাহ যেন কবুল করেন"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingLog(false)}
                  className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-400"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          )}

          {/* Logs List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 px-1">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                আপনার পূর্ববর্তী সদকা রেকর্ড:
              </span>
              <span>{logs.length}টি সংরক্ষিত</span>
            </div>

            {logs.length === 0 ? (
              <div className="p-6 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-slate-500 text-xs space-y-1">
                <p>এখনো কোনো দানের রেকর্ড যুক্ত করা হয়নি।</p>
                <p className="text-[11px] text-slate-400">সাধ্যমতো দান করুন এবং নিজের আধ্যাত্মিক সন্তুষ্টির জন্য হিসাব রাখুন।</p>
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3 shadow-2xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                      <Coins className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-xs font-bold text-slate-900 dark:text-white">
                          {log.cause}
                        </h5>
                        <span className="text-[10px] px-2 py-0.2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                          {log.recipientCategory}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{log.date}</span>
                        {log.itemDescription && (
                          <span>· {log.itemDescription}</span>
                        )}
                        {log.note && (
                          <span className="italic">· "{log.note}"</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono text-sm font-bold text-emerald-700 dark:text-emerald-400">
                      ৳{log.amount.toLocaleString()}
                    </span>
                    <button
                      onClick={() => handleDeleteLog(log.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Finding Genuine Needy (হকদার নির্দেশিকা) */}
      {activeTab === 'guidelines' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-800/60 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 dark:text-amber-300">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>কাদের আগে দান করবেন? ইসলামি অগ্রাধিকারের ৪টি স্বর্ণালী স্তর:</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 font-bengali leading-relaxed">
              অনেকে রাস্তায় যাকে-তাকে দান করে মনে করেন দায়িত্ব শেষ, কিন্তু ইসলাম হকদার নির্বাচনে অত্যন্ত স্পষ্ট অগ্রাধিকার নির্ধারণ করে দিয়েছে।
            </p>
          </div>

          <div className="space-y-2.5">
            {[
              {
                step: '১ম অগ্রাধিকার',
                title: 'অসচ্ছল নিকটাত্মীয় (Relatives in Need)',
                desc: 'চাচা, মামা, ফুফু, খালা, ভাই-বোন বা কোনো নিকটাত্মীয় যদি অভাবী হন, তবে তাদের আগে সাহায্য করতে হবে। এতে দানের সওয়াব ও আত্মীয়তার সম্পর্ক রক্ষার দ্বিগুণ সওয়াব অর্জিত হয়।',
                hadith: '"সাধারণ মিসকিনকে দিলে শুধু সদকা হয়; আর অসচ্ছল আত্মীয়কে দিলে সদকা ও আত্মীয়তার হক দুটিই আদায় হয়।" — তিরমিজি: ৬৫৮',
              },
              {
                step: '২য় অগ্রাধিকার',
                title: 'অভাবী প্রতিবেশী (Needy Neighbors)',
                desc: 'আপনার বাড়ির আশপাশে বা গ্রামে এমন অনেক পরিবার থাকে যাদের হয়তো আজ চুলা জ্বলবে না। তাদের গোপনে বাজার বা নগদ টাকা পৌঁছে দেওয়া ফরজ দায়িত্বের মতো।',
                hadith: '"সে প্রকৃত মুমিন নয়, যে নিজে পেটভরে খায় অথচ তার প্রতিবেশী অনাহারে থাকে।" — বায়হাকি: ১৯০৪৯',
              },
              {
                step: '৩য় অগ্রাধিকার',
                title: 'আত্মমর্যাদাসম্পন্ন গোপন অভাবী (White-Collar / Secret Poor)',
                desc: 'যারা সম্মানের খাতিরে কারও কাছে হাত পাততে পারেন না, কিন্তু ভেতরে ভেতরে কষ্টে দিন কাটাচ্ছেন—এমন মানুষ খুঁজে বের করে গোপনে সাহায্য করাই সর্বোত্তম সদকা।',
                hadith: '"তারা মানুষের কাছে নির্লজ্জভাবে হাত পাতে না; তুমি তাদের চেহারার লক্ষণ দেখেই তাদের অবস্থা বুঝতে পারবে।" — সূরা আল-বাকারাহ: ২৭৩',
              },
              {
                step: '৪র্থ অগ্রাধিকার',
                title: 'স্বচ্ছ ও স্বীকৃত দাতব্য উদ্যোগ বা এতিমখানা',
                desc: 'আপনি নিজে যাদের কাছে পৌঁছাতে পারেন না, সেখানে পৌঁছানোর জন্য কোনো বিশ্বস্ত, সৎ ও শতভাগ স্বচ্ছ অরাজনৈতিক ইসলামি ত্রাণ ও সমাজসেবামূলক প্রতিষ্ঠানকে বেছে নিন।',
                hadith: '"সৎকর্মে তোমরা পরস্পরকে সহযোগিতা করো।" — সূরা আল-মায়িদাহ: ২',
              },
            ].map((guide, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    {guide.title}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300">
                    {guide.step}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
                  {guide.desc}
                </p>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-400 italic pt-1 border-t border-slate-100 dark:border-slate-800">
                  {guide.hadith}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Virtues & Etiquettes of Charity (ফজিলত ও আদব) */}
      {activeTab === 'hadith' && (
        <div className="space-y-3.5">
          {/* Key Virtues */}
          <div className="p-4 rounded-3xl bg-linear-to-br from-emerald-900/80 to-teal-950/80 text-white space-y-2 border border-emerald-700/40">
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300">
              পবিত্র কুরআনের মহান ঘোষণা
            </span>
            <p className="font-uthmani text-base leading-loose text-right text-emerald-100" dir="rtl">
              مَّثَلُ ٱلَّذِينَ يُنفِقُونَ أَمْوَٰلَهُمْ فِي سَبِيلِ ٱللَّهِ كَمَثَلِ حَبَّةٍ أَنۢبَتَتْ سَبْعَ سَنَابِلَ فِي كُلِّ سُنۢبُلَةٍ مِّاْئَةُ حَبَّةٍ
            </p>
            <p className="text-xs text-emerald-100/90 font-bengali leading-relaxed">
              "যারা আল্লাহর পথে নিজেদের ধন-সম্পদ ব্যয় করে, তাদের দৃষ্টান্ত একটি শস্যবীজের মতো, যা থেকে সাতটি শীষ জন্মায় এবং প্রতিটি শীষে থাকে একশত দানা। আল্লাহ যাকে ইচ্ছা বহুগুণ বৃদ্ধি করে দেন।" (সূরা আল-বাকারাহ: ২৬১)
            </p>
          </div>

          {/* 5 Golden Rules of Sadaqah */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-2.5">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>দানের ৫টি অত্যন্ত গুরুত্বপূর্ণ ইসলামি আদব:</span>
            </h4>
            <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300 font-bengali">
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  ১
                </span>
                <div>
                  <strong>একমাত্র আল্লাহর সন্তুষ্টির নিয়ত (ইখলাস):</strong>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">সামাজিক বাহবা বা মানুষের কাছে দাতা সাজার বাসনা থাকলে সওয়াব নষ্ট হয়ে যায়।</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  ২
                </span>
                <div>
                  <strong>গোপনে দেওয়া সর্বোত্তম (Secret Charity):</strong>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">ডান হাত দান করলে বাঁ হাত যেন জানতে না পারে—এমন গোপন দান আল্লাহর ক্রোধ নিভিয়ে দেয়।</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  ৩
                </span>
                <div>
                  <strong>খোটা দেওয়া বা মনঃকষ্ট দেওয়া সম্পূর্ণ হারাম:</strong>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">দান করে অনুগ্রহ প্রকাশ করা বা প্রাপককে অপমান করা দানকে বাতিল করে দেয়।</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  ৪
                </span>
                <div>
                  <strong>হালাল ও উত্তম বস্তু থেকে দান:</strong>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">খারাপ বা নষ্ট বস্তু নয়, যা নিজের কাছে প্রিয় তা থেকে দান করলে আল্লাহর নৈকট্য মেলে।</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  ৫
                </span>
                <div>
                  <strong>হাসিমুখে ও কৃতজ্ঞতার সাথে প্রদান:</strong>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">প্রাপক আপনার দান গ্রহণ করে আপনাকে আখেরাতের সওয়াব পাওয়ার সুযোগ করে দিয়েছেন—এই কৃতজ্ঞতা রাখা।</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Dua Banner */}
      <div className="p-4 rounded-3xl bg-amber-500/10 dark:bg-amber-950/20 border border-amber-300/40 dark:border-amber-800/40 text-amber-900 dark:text-amber-200 text-center space-y-1">
        <p className="text-xs font-semibold">
          "হে আমাদের পালনকর্তা! আমাদের দান ও খেদমত কবুল করুন, নিশ্চয় আপনি সর্বশ্রোতা ও সর্বজ্ঞ।"
        </p>
        <span className="text-[10px] text-amber-800 dark:text-amber-400 block font-mono">
          — সূরা আল-বাকারাহ: ১২৭
        </span>
      </div>
    </div>
  );
};
