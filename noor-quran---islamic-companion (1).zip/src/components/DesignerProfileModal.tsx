import React, { useState } from 'react';
import { AppLanguage } from '../types';
import { X, Heart, Sparkles, Check, Award, ShieldCheck, BookOpen, HandHeart, Briefcase } from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';
import islamicBadge from '../assets/images/islamic_app_badge_1791133494322.jpg';

interface DesignerProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onOpenCharity?: () => void;
}

export const DesignerProfileModal: React.FC<DesignerProfileModalProps> = ({
  isOpen,
  onClose,
  language,
  onOpenCharity,
}) => {
  const [duaCount, setDuaCount] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('noor_quran_designer_dua_count') || '42', 10);
    } catch {
      return 42;
    }
  });
  const [hasPrayed, setHasPrayed] = useState(false);

  if (!isOpen) return null;

  const handleSendDua = () => {
    triggerHaptic(30);
    if (!hasPrayed) {
      const next = duaCount + 1;
      setDuaCount(next);
      setHasPrayed(true);
      try {
        localStorage.setItem('noor_quran_designer_dua_count', next.toString());
      } catch {
        // ignore
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-emerald-500/20 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner with Islamic Geometry Gradient */}
        <div className="relative bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-950 p-6 text-white text-center">
          <button
            onClick={() => {
              triggerHaptic(15);
              onClose();
            }}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Islamic Sacred Art Emblem */}
          <div className="relative w-22 h-22 mx-auto mb-3">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-400 to-emerald-400 blur-xs opacity-75 animate-pulse" />
            <div className="relative w-full h-full rounded-full overflow-hidden border-2 border-amber-300 shadow-xl bg-slate-900">
              <img
                src={islamicBadge}
                onError={(e) => {
                  e.currentTarget.src = '/islamic_badge.jpg';
                }}
                alt="নূর কুরআন ইসলামিক প্রতীক"
                className="w-full h-full object-cover"
                loading="eager"
              />
            </div>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[11px] font-semibold tracking-wide border border-amber-300/30 mb-1">
            <Sparkles className="w-3 h-3" />
            <span>অ্যাপের প্রতিষ্ঠাতা ও পরিকল্পনাকারী</span>
          </span>

          <h3 className="text-lg sm:text-xl font-bold tracking-tight text-white mt-1">
            Engr. Mohammad Muzahidul Islam (Salman)
          </h3>
          <p className="text-xs text-emerald-200 font-medium mt-0.5 flex items-center justify-center gap-1">
            <Briefcase className="w-3 h-3" />
            <span>Electrical Engineer · প্রতিষ্ঠাতা, নূর কুরআন</span>
          </p>

          <div className="inline-block mt-2 px-3 py-1 rounded-xl bg-white/10 backdrop-blur-xs text-xs font-semibold text-emerald-100 border border-white/10">
            🕋 সদকায়ে জারিয়া ও দ্বীনি খেদমত
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-bengali">
          {/* Owner Message Block */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/50 space-y-2">
            <div className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300 font-bold text-sm">
              <BookOpen className="w-4 h-4 text-emerald-600" />
              <span>আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ</span>
            </div>
            <p className="text-slate-700 dark:text-slate-300">
              আমি <strong>Engr. Mohammad Muzahidul Islam (Salman)</strong>। পেশাগতভাবে একজন <strong>ইলেকট্রিক্যাল ইঞ্জিনিয়ার (Electrical Engineer)</strong>। প্রযুক্তি ও দ্বীনের সমন্বয়ে বাংলাভাষী মুসলিম ভাই-বোনদের জন্য <strong>"নূর কুরআন"</strong> অ্যাপটি সম্পূর্ণ নিঃস্বার্থভাবে ও মহান আল্লাহর সন্তুষ্টির উদ্দেশ্যে তৈরি করার প্রয়াস পেয়েছি।
            </p>
          </div>

          {/* Heartfelt Dua & Charity Appeal Request */}
          <div className="p-4 rounded-2xl bg-linear-to-br from-amber-500/15 via-rose-500/10 to-amber-500/10 dark:bg-amber-950/30 border border-amber-300/60 dark:border-amber-800/60 text-slate-800 dark:text-amber-100 space-y-2 shadow-xs">
            <div className="font-bold flex items-center gap-1.5 text-xs text-amber-900 dark:text-amber-300">
              <HandHeart className="w-4 h-4 text-rose-500" />
              <span>উদ্যোক্তার একটি আন্তরিক ও বিনীত অনুরোধ:</span>
            </div>
            <blockquote className="text-[12px] leading-relaxed italic border-l-3 border-amber-500 pl-3">
              "যদি এই অ্যাপ থেকে আপনি সামান্যতমও উপকৃত হয়ে থাকেন, তবে এই অধম এবং আমার পিতা-মাতার জন্য মহান আল্লাহর দরবারে আন্তরিক দোয়া করবেন। আর আপনার পক্ষে সম্ভব হলে আপনার সাধ্যমতো আপনার চারপাশের কোনো অসহায়, দরিদ্র ও দুস্থ মানুষকে সাহায্য-সহযোগিতা করবেন। মানুষের মুখে হাসি ফোটানো ও কারও বিপদে পাশে দাঁড়ানোটাই হবে আমার জন্য সবচেয়ে বড় উপহার।"
            </blockquote>

            {onOpenCharity && (
              <button
                onClick={() => {
                  triggerHaptic(15);
                  onClose();
                  onOpenCharity();
                }}
                className="w-full mt-2 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <Heart className="w-3.5 h-3.5 fill-slate-950" />
                <span>অসহায়দের দান ও সহায়তা গাইড দেখুন (Contribute to Charity)</span>
              </button>
            )}
          </div>

          {/* Key Architecture Features */}
          <div className="space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-slate-200 block">
              অ্যাপটির মূল দ্বীনি বৈশিষ্ট্যসমূহ:
            </span>
            <ul className="space-y-1 text-slate-600 dark:text-slate-400 pl-1">
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>মদিনা শরীফের উসমানি লিপি ও ৫টি বৈচিত্র্যময় আরবি কুরআন ফন্ট।</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>বাংলা উচ্চারণে উচ্চমানের নুকতাহ ও পূর্ণাঙ্গ হরকত সমন্বিত সহজ পঠন।</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>বাংলাদেশের ৬৪ জেলা ও বিশ্বব্যাপী সঠিক ওয়াক্ত, তাহাজ্জুদ ও সাহরি-ইফতার।</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>সম্পূর্ণ বিজ্ঞাপনমুক্ত, ট্র্যাকারিংহীন ও ব্যবহারকারীর প্রাইভেসি-সুরক্ষিত।</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Action Bottom Bar */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 flex items-center gap-2">
          <button
            onClick={handleSendDua}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              hasPrayed
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md active:scale-98'
            }`}
          >
            <Heart className={`w-4 h-4 ${hasPrayed ? 'fill-white' : ''}`} />
            <span>
              {hasPrayed ? 'জাযাকাল্লাহু খাইরান (দোয়া গৃহীত)' : 'উদ্যোক্তার জন্য দোয়া করুন'}
            </span>
            <span className="px-1.5 py-0.5 rounded-full bg-white/20 text-[10px] font-mono">
              {duaCount}
            </span>
          </button>

          <button
            onClick={() => {
              triggerHaptic(15);
              onClose();
            }}
            className="py-2.5 px-4 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-300 transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
