import React from 'react';
import { AppLanguage } from '../types';
import { Home, BookOpen, Clock, Search, Menu } from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

export type MainTabType = 'home' | 'quran' | 'prayer' | 'search' | 'more' | 'dua';

interface BottomNavProps {
  currentTab: string;
  onChangeTab: (tab: any) => void;
  language: AppLanguage;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onChangeTab,
  language,
}) => {
  const handleTabClick = (tab: string) => {
    triggerHaptic(15);
    onChangeTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navItems = [
    {
      id: 'home',
      label: language === 'bn' ? 'হোম' : 'Home',
      icon: <Home className="w-5 h-5 stroke-[1.8]" />,
    },
    {
      id: 'quran',
      label: language === 'bn' ? 'কুরআন' : 'Read',
      icon: <BookOpen className="w-5 h-5 stroke-[1.8]" />,
    },
    {
      id: 'prayer',
      label: language === 'bn' ? 'নামাজ' : 'Prayer',
      icon: <Clock className="w-5 h-5 stroke-[1.8]" />,
    },
    {
      id: 'search',
      label: language === 'bn' ? 'অনুসন্ধান' : 'Search',
      icon: <Search className="w-5 h-5 stroke-[1.8]" />,
    },
    {
      id: 'more',
      label: language === 'bn' ? 'মেন্যু' : 'More',
      icon: <Menu className="w-5 h-5 stroke-[1.8]" />,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200/80 dark:border-slate-800 transition-colors shadow-xs">
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
        {navItems.map((item) => {
          const isActive =
            currentTab === item.id ||
            (item.id === 'more' &&
              (currentTab === 'charity' ||
                currentTab === 'ruqyah' ||
                currentTab === 'dua' ||
                currentTab === 'tasbeeh' ||
                currentTab === 'tracker' ||
                currentTab === 'masala' ||
                currentTab === 'salahGuide' ||
                currentTab === 'qaida' ||
                currentTab === 'hadith' ||
                currentTab === 'qibla'));

          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-all relative ${
                isActive
                  ? 'text-teal-700 dark:text-teal-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-transform ${
                  isActive ? 'scale-110' : 'scale-100 opacity-80'
                }`}
              >
                {item.icon}
              </div>
              <span className="text-[10px] tracking-tight truncate max-w-[62px] mt-0.5">
                {item.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-1.5 h-1.5 rounded-full bg-teal-600 dark:bg-teal-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
