import React, { useState } from 'react';
import { AppLanguage, DuaItem } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  DUAS_LIST,
  DUA_CATEGORIES,
  MASNOON_HABITS,
} from '../data/duaData';
import {
  Heart,
  Volume2,
  Check,
  Share2,
  CheckCircle2,
  Circle,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { speakArabic, triggerHaptic } from '../utils/audioPlayer';

interface DuaAzkarProps {
  language: AppLanguage;
  dailyAmalChecklist: Record<string, boolean>;
  onToggleAmalHabit: (habitId: string) => void;
  favoriteDuas: string[];
  onToggleFavoriteDua: (duaId: string) => void;
}

export const DuaAzkar: React.FC<DuaAzkarProps> = ({
  language,
  dailyAmalChecklist,
  onToggleAmalHabit,
  favoriteDuas,
  onToggleFavoriteDua,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'duas' | 'checklist'>('duas');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [duaCounters, setDuaCounters] = useState<Record<string, number>>({});
  const [copiedDuaId, setCopiedDuaId] = useState<string | null>(null);

  const handleIncrement = (duaId: string) => {
    triggerHaptic(15);
    setDuaCounters(prev => ({
      ...prev,
      [duaId]: (prev[duaId] || 0) + 1,
    }));
  };

  const handleResetCounter = (duaId: string) => {
    triggerHaptic(20);
    setDuaCounters(prev => ({
      ...prev,
      [duaId]: 0,
    }));
  };

  const handleSpeak = (text: string) => {
    triggerHaptic(15);
    speakArabic(text);
  };

  const handleShareDua = (dua: DuaItem) => {
    const text = `${dua.titleBn}\n\n${dua.arabic}\n\nউচ্চারণ: ${dua.transliterationBn}\n\nঅর্থ: ${dua.translationBn}\n\nসূত্র: ${dua.referenceBn}\n(নূর কুরআন)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedDuaId(dua.id);
      triggerHaptic(20);
      setTimeout(() => setCopiedDuaId(null), 2000);
    }
  };

  const filteredDuas = DUAS_LIST.filter(
    d => selectedCategory === 'all' || d.category === selectedCategory
  );

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.dua}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          হিসনুল মুসলিম হতে সংকলিত সহিহ দোয়া ও দৈনন্দিন মাসনূন আমল ট্র্যাকার
        </p>
      </div>

      {/* Tabs: Duas vs Masnoon Checklist */}
      <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-medium">
        <button
          onClick={() => setActiveTab('duas')}
          className={`py-2 rounded-xl transition-all ${
            activeTab === 'duas'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          মাসনূন দোয়া সমূহ ({DUAS_LIST.length})
        </button>
        <button
          onClick={() => setActiveTab('checklist')}
          className={`py-2 rounded-xl transition-all ${
            activeTab === 'checklist'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          দৈনিক আমল চেকলিস্ট
        </button>
      </div>

      {/* DUAS LIST VIEW */}
      {activeTab === 'duas' && (
        <div className="space-y-3">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {DUA_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full shrink-0 font-medium transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {cat.nameBn}
              </button>
            ))}
          </div>

          {/* Duas Cards */}
          <div className="space-y-3">
            {filteredDuas.map((dua) => {
              const count = duaCounters[dua.id] || 0;
              const isFav = favoriteDuas.includes(dua.id);
              const isCopied = copiedDuaId === dua.id;

              return (
                <div
                  key={dua.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3"
                >
                  {/* Top Bar */}
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {dua.titleBn}
                      </h4>
                      <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-medium">
                        {dua.categoryBn}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleSpeak(dua.arabic)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="উচ্চারণ শুনুন"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleShareDua(dua)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="কপি করুন"
                      >
                        {isCopied ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Share2 className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={() => onToggleFavoriteDua(dua.id)}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                          isFav ? 'text-rose-500' : 'text-slate-400 hover:bg-slate-100'
                        }`}
                        title="প্রিয় তালিকা"
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                      </button>
                    </div>
                  </div>

                  {/* Arabic */}
                  <p className="font-arabic text-xl leading-loose text-right text-slate-900 dark:text-white block mb-2" dir="rtl">
                    {dua.arabic}
                  </p>

                  {/* Transliteration */}
                  <p className="text-xs text-slate-500 dark:text-slate-400 italic text-left block mb-1" dir="ltr">
                    {dua.transliterationBn}
                  </p>

                  {/* Translation */}
                  <p className="text-xs text-slate-800 dark:text-slate-200 font-bengali leading-relaxed text-left block mb-2" dir="ltr">
                    {dua.translationBn}
                  </p>

                  {/* Benefits & Source */}
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-[11px] space-y-1">
                    {dua.benefitsBn && (
                      <p className="text-emerald-800 dark:text-emerald-300">
                        <strong>ফজিলত:</strong> {dua.benefitsBn}
                      </p>
                    )}
                    <span className="text-slate-500 block">
                      সূত্র: {dua.referenceBn}
                    </span>
                  </div>

                  {/* Counter row */}
                  {dua.counterTarget && (
                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500">
                          পাঠ সংখ্যা: <strong className="text-slate-900 dark:text-white font-mono">{count}</strong>
                          {dua.counterTarget > 1 && ` / ${dua.counterTarget}`}
                        </span>
                        {count > 0 && (
                          <button
                            onClick={() => handleResetCounter(dua.id)}
                            className="text-[10px] text-slate-400 hover:text-slate-600 underline"
                          >
                            রিসেট
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => handleIncrement(dua.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 active:scale-95 transition-all shadow-xs"
                      >
                        পাঠ করেছি (+১)
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MASNOON HABIT CHECKLIST */}
      {activeTab === 'checklist' && (
        <div className="space-y-3">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl text-xs text-emerald-900 dark:text-emerald-300">
            <strong>দৈনিক মাসনূন আমল ট্র্যাকার:</strong> প্রতিদিনের গুরুত্বপূর্ণ সুন্নত আমলগুলো আদায় করে টিক দিন। এটি আপনার দৈনন্দিন আধ্যাত্মিক রুটিন রক্ষা করতে সাহায্য করবে।
          </div>

          <div className="space-y-2">
            {MASNOON_HABITS.map((habit) => {
              const isChecked = !!dailyAmalChecklist[habit.id];

              return (
                <div
                  key={habit.id}
                  onClick={() => {
                    triggerHaptic(20);
                    onToggleAmalHabit(habit.id);
                  }}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                    isChecked
                      ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                      : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:bg-slate-50'
                  }`}
                >
                  <div className="mt-0.5">
                    {isChecked ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-600 dark:text-emerald-400 dark:fill-emerald-400 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600 shrink-0" />
                    )}
                  </div>

                  <div className="space-y-0.5 flex-1">
                    <h4 className={`text-xs font-bold ${
                      isChecked ? 'text-emerald-950 dark:text-emerald-100 line-through opacity-80' : 'text-slate-900 dark:text-white'
                    }`}>
                      {habit.titleBn}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      ফজিলত: {habit.rewardBn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
