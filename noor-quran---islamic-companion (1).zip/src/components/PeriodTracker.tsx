import React, { useState, useEffect } from 'react';
import { AppLanguage, PeriodTrackerData } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { encryptData, decryptData, hashPin } from '../utils/crypto';
import {
  Lock,
  Unlock,
  KeyRound,
  Calendar,
  AlertCircle,
  ShieldCheck,
  Check,
  Trash2,
  Bell,
  Heart,
  BookOpen,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface PeriodTrackerProps {
  language: AppLanguage;
}

const STORAGE_KEY = 'noor_quran_period_tracker_encrypted_v1';
const PIN_HASH_KEY = 'noor_quran_tracker_pin_hash';

export const PeriodTracker: React.FC<PeriodTrackerProps> = ({ language }) => {
  const t = TRANSLATIONS[language];

  // State
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [savedPinHash, setSavedPinHash] = useState<string | null>(null);
  const [newPinSetup, setNewPinSetup] = useState('');

  const [trackerData, setTrackerData] = useState<PeriodTrackerData>({
    isEnabled: true,
    isLocked: false,
    lastPeriodStartDate: new Date().toISOString().split('T')[0],
    cycleLengthDays: 28,
    periodDurationDays: 5,
    history: [],
    reminderDaysBefore: 2,
  });

  const [savedNotice, setSavedNotice] = useState(false);

  // Load from local storage
  useEffect(() => {
    try {
      const storedPinHash = localStorage.getItem(PIN_HASH_KEY);
      setSavedPinHash(storedPinHash);

      const encrypted = localStorage.getItem(STORAGE_KEY);
      if (encrypted) {
        const decrypted = decryptData<PeriodTrackerData>(encrypted, storedPinHash || 'DEFAULT');
        if (decrypted) {
          setTrackerData(decrypted);
        }
      }

      // If no PIN set, unlock immediately
      if (!storedPinHash) {
        setIsUnlocked(true);
      }
    } catch (e) {
      console.warn('Error loading tracker data:', e);
      setIsUnlocked(true);
    }
  }, []);

  const handleUnlock = () => {
    if (!savedPinHash) {
      setIsUnlocked(true);
      return;
    }
    const inputHash = hashPin(pinInput);
    if (inputHash === savedPinHash) {
      triggerHaptic(20);
      setIsUnlocked(true);
      setPinError(false);
      setPinInput('');
    } else {
      triggerHaptic(50);
      setPinError(true);
    }
  };

  const handleSetNewPin = () => {
    if (newPinSetup.length >= 4) {
      triggerHaptic(20);
      const h = hashPin(newPinSetup);
      localStorage.setItem(PIN_HASH_KEY, h);
      setSavedPinHash(h);

      // Re-encrypt data with new pin
      const updated = { ...trackerData, isLocked: true };
      setTrackerData(updated);
      localStorage.setItem(STORAGE_KEY, encryptData(updated, h));

      setNewPinSetup('');
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2500);
    }
  };

  const handleSaveData = () => {
    triggerHaptic(20);
    const key = savedPinHash || 'DEFAULT';
    localStorage.setItem(STORAGE_KEY, encryptData(trackerData, key));
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleClearAllData = () => {
    if (confirm('আপনি কি নিশ্চিত যে আপনার সমস্ত ব্যক্তিগত পিরিয়ড ট্র্যাকার ডেটা মুছে ফেলতে চান?')) {
      triggerHaptic(30);
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(PIN_HASH_KEY);
      setSavedPinHash(null);
      setTrackerData({
        isEnabled: true,
        isLocked: false,
        lastPeriodStartDate: new Date().toISOString().split('T')[0],
        cycleLengthDays: 28,
        periodDurationDays: 5,
        history: [],
        reminderDaysBefore: 2,
      });
      setIsUnlocked(true);
    }
  };

  // Calculate next predicted period start date
  const lastDate = new Date(trackerData.lastPeriodStartDate || new Date());
  const nextDate = new Date(lastDate);
  nextDate.setDate(nextDate.getDate() + (trackerData.cycleLengthDays || 28));

  // Formatted next date string
  const nextDateFormatted = nextDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Calculate reminder warning date (2 days prior to next period)
  const reminderDate = new Date(nextDate);
  reminderDate.setDate(reminderDate.getDate() - (trackerData.reminderDaysBefore || 2));
  const reminderDateFormatted = reminderDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
    day: 'numeric',
    month: 'long',
  });

  // PIN Lock Screen
  if (savedPinHash && !isUnlocked) {
    return (
      <div className="pb-24 pt-6 px-4 max-w-sm mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-full bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 mx-auto flex items-center justify-center shadow-inner">
          <Lock className="w-8 h-8" />
        </div>

        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            {t.periodTrackerTitle}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            আপনার ব্যক্তিগত তথ্যের গোপনীয়তার জন্য পিন কোড দিন
          </p>
        </div>

        <div className="space-y-3">
          <input
            type="password"
            maxLength={6}
            value={pinInput}
            onChange={(e) => {
              setPinInput(e.target.value);
              setPinError(false);
            }}
            placeholder="••••"
            className="w-40 text-center tracking-widest text-2xl py-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mx-auto block focus:outline-hidden focus:ring-2 focus:ring-pink-500/50"
          />

          {pinError && (
            <p className="text-xs text-rose-500 font-medium">
              {t.wrongPin}
            </p>
          )}

          <button
            onClick={handleUnlock}
            className="w-full py-3 rounded-2xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-sm shadow-md transition-colors"
          >
            আনলক করুন
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t.periodTrackerTitle}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t.periodTrackerDesc}
          </p>
        </div>

        <div className="w-8 h-8 rounded-full bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center">
          <ShieldCheck className="w-4 h-4" />
        </div>
      </div>

      {/* Prediction Highlight Banner */}
      <div className="p-4 rounded-3xl bg-linear-to-r from-pink-800 to-rose-950 text-white shadow-md space-y-2 border border-pink-700/50">
        <span className="text-xs text-pink-200 uppercase tracking-widest font-semibold block">
          পরবর্তী সম্ভাব্য পিরিয়ড
        </span>
        <h3 className="text-xl font-bold tracking-tight text-white">
          {nextDateFormatted}
        </h3>
        <p className="text-xs text-pink-100/90 leading-normal">
          ২৮ দিনের স্বাভাবিক চক্র অনুযায়ী আনুমানিক হিসাব। ২৬তম দিনে আপনাকে স্মরণ করিয়ে দেওয়া হবে।
        </p>
      </div>

      {/* Confidential Notification Preview Card */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-2 text-xs">
        <div className="flex items-center gap-2 text-pink-600 dark:text-pink-400 font-bold border-b border-slate-100 dark:border-slate-800 pb-1.5">
          <Bell className="w-4 h-4" />
          <span>গোপন ও মার্জিত রিমাইন্ডার প্রিভিউ:</span>
        </div>
        <div className="p-3 rounded-xl bg-pink-50/60 dark:bg-pink-950/20 border border-pink-200/60 dark:border-pink-900/40 text-slate-700 dark:text-slate-300">
          “{t.periodReminderText} সম্ভাব্য তারিখ: {reminderDateFormatted}।”
        </div>
      </div>

      {/* Tracker Configuration Controls */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3 text-xs">
        <h4 className="font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
          সাইকেল সেটিংস ও তারিখ
        </h4>

        {/* Start Date Picker */}
        <div>
          <label className="block text-slate-600 dark:text-slate-400 font-medium mb-1">
            {t.lastPeriodStart}:
          </label>
          <input
            type="date"
            value={trackerData.lastPeriodStartDate}
            onChange={(e) => setTrackerData({ ...trackerData, lastPeriodStartDate: e.target.value })}
            className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-medium"
          />
        </div>

        {/* Cycle Length Slider */}
        <div>
          <div className="flex justify-between text-slate-600 dark:text-slate-400 mb-1">
            <span>মাসিক চক্রের দৈর্ঘ্য (সাধারণত ২৮ দিন):</span>
            <strong className="font-mono text-pink-600 font-bold">{trackerData.cycleLengthDays} দিন</strong>
          </div>
          <input
            type="range"
            min="21"
            max="35"
            value={trackerData.cycleLengthDays}
            onChange={(e) => setTrackerData({ ...trackerData, cycleLengthDays: Number(e.target.value) })}
            className="w-full accent-pink-600"
          />
        </div>

        {/* Duration Days Slider */}
        <div>
          <div className="flex justify-between text-slate-600 dark:text-slate-400 mb-1">
            <span>রক্তস্রাবের সময়কাল (সাধারণত ৩-৭ দিন):</span>
            <strong className="font-mono text-pink-600 font-bold">{trackerData.periodDurationDays} দিন</strong>
          </div>
          <input
            type="range"
            min="3"
            max="10"
            value={trackerData.periodDurationDays}
            onChange={(e) => setTrackerData({ ...trackerData, periodDurationDays: Number(e.target.value) })}
            className="w-full accent-pink-600"
          />
        </div>

        <button
          onClick={handleSaveData}
          className="w-full py-2.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
        >
          {savedNotice ? (
            <>
              <Check className="w-4 h-4" />
              <span>সংরক্ষিত হয়েছে!</span>
            </>
          ) : (
            <span>{t.saveData}</span>
          )}
        </button>
      </div>

      {/* Islamic Worship & Purity Rules Section */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3 text-xs">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
          <BookOpen className="w-4 h-4 text-emerald-600" />
          <h4 className="font-bold text-slate-900 dark:text-white">
            {t.islamicPurityRules} (হায়িজ ও ইস্তিহাজার বিধান)
          </h4>
        </div>

        <div className="space-y-2 text-slate-700 dark:text-slate-300 leading-relaxed font-bengali">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
            <strong className="text-emerald-800 dark:text-emerald-300 block">১. নামাজের হুকুম:</strong>
            <p>হায়িজ চলাকালীন নামাজ মাফ। এই সময়ের জন্য কোনো কাজা নামাজ পড়তে হবে না।</p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
            <strong className="text-emerald-800 dark:text-emerald-300 block">২. রমজানের রোজা:</strong>
            <p>হায়িজের কারণে রমজানের রোজা রাখা নিষেধ, তবে পিরিয়ড শেষ হওয়ার পর পরবর্তীতে সমসংখ্যক রোজা কাজা আদায় করতে হবে।</p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
            <strong className="text-emerald-800 dark:text-emerald-300 block">৩. কুরআন পাঠ ও স্পর্শ:</strong>
            <p>কুরআন সরাসরি স্পর্শ ছাড়া মুখস্থ বা অ্যাপ থেকে অর্থ পড়া নিয়ে সতর্কতা রয়েছে; তবে যেকোনো দোয়া, জিকির, ইস্তিগফার ও দুরুদ যেকোনো সময় পাঠ করা পুরোপুরি জায়েজ ও সওয়াবের কাজ।</p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
            <strong className="text-emerald-800 dark:text-emerald-300 block">৪. পবিত্রতার গোসল:</strong>
            <p>রক্তস্রাব পুরোপুরি বন্ধ হওয়ার পর ফরজ গোসলের মাধ্যমে পবিত্রতা অর্জন করে অবিলম্বে নামাজ শুরু করতে হবে।</p>
          </div>
        </div>
      </div>

      {/* Security & PIN Setup / Wipe Data */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-3 text-xs">
        <h4 className="font-bold text-slate-800 dark:text-slate-200">
          সিকিউরিটি ও ডেটা ডিলিট
        </h4>

        {/* Set PIN */}
        <div className="flex gap-2">
          <input
            type="password"
            maxLength={6}
            placeholder="নতুন ৪-সংখ্যার গোপন পিন দিন"
            value={newPinSetup}
            onChange={(e) => setNewPinSetup(e.target.value)}
            className="flex-1 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
          />
          <button
            onClick={handleSetNewPin}
            disabled={newPinSetup.length < 4}
            className="px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold disabled:opacity-40"
          >
            পিন সেট
          </button>
        </div>

        {/* Wipe Data Button */}
        <button
          onClick={handleClearAllData}
          className="text-rose-600 dark:text-rose-400 font-medium hover:underline flex items-center gap-1 pt-1"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>{t.clearData}</span>
        </button>
      </div>
    </div>
  );
};
