import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppLanguage } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  RotateCcw,
  Sparkles,
  Volume2,
  VolumeX,
  Smartphone,
  ChevronDown,
  Target,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { playTasbeehClick, triggerHaptic } from '../utils/audioPlayer';

interface TasbeehPreset {
  id: string;
  nameBn: string;
  nameAr: string;
  meaningBn: string;
  defaultTarget: number;
}

const PRESETS: TasbeehPreset[] = [
  { id: 'subhanallah', nameBn: 'সুবহানাল্লাহ', nameAr: 'سُبْحَانَ اللَّهِ', meaningBn: 'আল্লাহ অতি পবিত্র ও নিষ্কলুষ', defaultTarget: 33 },
  { id: 'alhamdulillah', nameBn: 'আলহামদুলিল্লাহ', nameAr: 'الْحَمْدُ لِلَّهِ', meaningBn: 'সকল প্রশংসা আল্লাহর জন্য', defaultTarget: 33 },
  { id: 'allahuakbar', nameBn: 'আল্লাহু আকবার', nameAr: 'اللَّهُ أَكْبَرُ', meaningBn: 'আল্লাহ সর্বশ্রেষ্ঠ ও মহান', defaultTarget: 34 },
  { id: 'tahlil', nameBn: 'লা ইলাহা ইল্লাল্লাহ', nameAr: 'لَا إِلَٰهَ إِلَّا اللَّهُ', meaningBn: 'আল্লাহ ছাড়া কোনো সত্য উপাস্য নেই', defaultTarget: 100 },
  { id: 'istighfar', nameBn: 'আস্তাগফিরুল্লাহ', nameAr: 'أَسْتَغْفِرُ اللَّهَ', meaningBn: 'আমি আল্লাহর কাছে ক্ষমা চাই', defaultTarget: 100 },
  { id: 'darood', nameBn: 'ছোট দুরুদ শরিফ', nameAr: 'صَلَّى اللّٰهُ عَلَيْهِ وَسَلَّمَ', meaningBn: 'সাল্লাল্লাহু আলাইহি ওয়া সাল্লাম — আল্লাহ তাঁর (রাসূল সা.) ওপর রহমত ও শান্তি বর্ষণ করুন (ছোট ও সহজ দুরুদ)', defaultTarget: 100 },
  { id: 'hawqala', nameBn: 'লা হাওলা ওয়ালা কুওয়াতা...', nameAr: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', meaningBn: 'আল্লাহর সাহায্য ছাড়া কোনো উপায় বা শক্তি নেই', defaultTarget: 100 },
];

interface TasbeehCounterProps {
  language: AppLanguage;
  activeTasbeehDhikr: string;
  onChangeDhikr: (dhikrId: string) => void;
  tasbeehCounts: Record<string, number>;
  onUpdateCount: (dhikrId: string, count: number) => void;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

export const TasbeehCounter: React.FC<TasbeehCounterProps> = ({
  language,
  activeTasbeehDhikr,
  onChangeDhikr,
  tasbeehCounts,
  onUpdateCount,
  soundEnabled,
  vibrationEnabled,
}) => {
  const t = TRANSLATIONS[language];
  const [selectedTarget, setSelectedTarget] = useState<number>(33);
  const [showResetModal, setShowResetModal] = useState(false);

  const currentPreset = PRESETS.find(p => p.id === activeTasbeehDhikr) || PRESETS[0];
  const currentCount = tasbeehCounts[currentPreset.id] || 0;

  const handleTap = () => {
    const nextCount = currentCount + 1;
    onUpdateCount(currentPreset.id, nextCount);

    if (vibrationEnabled) {
      if (nextCount % selectedTarget === 0) {
        triggerHaptic(60); // Long vibration on reaching target!
      } else {
        triggerHaptic(20);
      }
    }

    if (soundEnabled) {
      playTasbeehClick();
    }
  };

  const handleConfirmReset = () => {
    triggerHaptic(25);
    onUpdateCount(currentPreset.id, 0);
    setShowResetModal(false);
  };

  const progressPercent = selectedTarget > 0 ? Math.min(100, (currentCount % selectedTarget) / selectedTarget * 100) : 0;
  const cycleCount = Math.floor(currentCount / selectedTarget);

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t.tasbeehCounter}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            ডিজিটাল জিকির ও তাসবীহ গণনা
          </p>
        </div>

        <button
          onClick={() => setShowResetModal(true)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.reset}</span>
        </button>
      </div>

      {/* Preset Dhikr Selector */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block px-1">
          জিকির নির্বাচন করুন:
        </label>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {PRESETS.map((preset) => {
            const isSelected = preset.id === currentPreset.id;
            return (
              <button
                key={preset.id}
                onClick={() => {
                  triggerHaptic(15);
                  onChangeDhikr(preset.id);
                  setSelectedTarget(preset.defaultTarget);
                }}
                className={`p-2.5 rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50'
                }`}
              >
                <span className="font-bold text-slate-900 dark:text-white block truncate">
                  {preset.nameBn}
                </span>
                <span className="font-arabic text-xs text-emerald-700 dark:text-emerald-400 block truncate mt-0.5">
                  {preset.nameAr}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Target Selector */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs">
        <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <Target className="w-4 h-4 text-emerald-600" />
          <span>টার্গেট সংখ্যা:</span>
        </span>
        <div className="flex items-center gap-1.5">
          {[33, 100, 1000].map((tVal) => (
            <button
              key={tVal}
              onClick={() => {
                triggerHaptic(15);
                setSelectedTarget(tVal);
              }}
              className={`px-3 py-1 rounded-xl font-bold font-mono transition-colors ${
                selectedTarget === tVal
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {tVal}
            </button>
          ))}
        </div>
      </div>

      {/* Current Dhikr Display Card with Ultra-Prominent Reset Button in direct eyesight */}
      <div className="relative p-4 sm:p-5 rounded-3xl bg-linear-to-b from-emerald-800 to-teal-950 text-white shadow-lg space-y-3 border-2 border-emerald-500/50">
        <div className="flex items-center justify-between border-b border-white/15 pb-2.5">
          <span className="text-xs uppercase tracking-wider text-emerald-200 font-bold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>বর্তমান জিকির পাঠ ও তিলাওয়াত</span>
          </span>

          {/* EYE-CATCHING RESET BUTTON RIGHT NEXT TO DHIKR TEXT */}
          <button
            onClick={() => {
              triggerHaptic(15);
              setShowResetModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 text-xs font-black transition-all cursor-pointer shadow-md ring-2 ring-amber-300/60"
            title="গণনা ০ তে রিসেট করুন"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-950 stroke-[3]" />
            <span>রিসেট (০)</span>
          </button>
        </div>

        <div className="text-center space-y-1.5 pt-1">
          <h3 className="font-arabic text-3xl sm:text-4xl font-bold tracking-normal leading-relaxed text-amber-100">
            {currentPreset.nameAr}
          </h3>
          <p className="text-base font-bold text-white font-bengali">
            {currentPreset.nameBn}
          </p>
          <p className="text-xs text-emerald-200/90 italic max-w-sm mx-auto leading-relaxed">
            "{currentPreset.meaningBn}"
          </p>
        </div>

        {/* Quick Reset & Target Info Strip inside the card */}
        <div className="flex items-center justify-between pt-1 border-t border-white/10 text-[11px] text-emerald-200">
          <span>টার্গেট: <strong className="text-white font-mono">{selectedTarget}</strong> বার</span>
          <button
            onClick={() => {
              triggerHaptic(15);
              setShowResetModal(true);
            }}
            className="text-amber-300 hover:text-amber-200 font-bold underline underline-offset-2 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>গণনা শূন্য (০) করুন</span>
          </button>
        </div>
      </div>

      {/* Massive Interactive Tap Counter Button with Motion Graphics */}
      <div className="flex flex-col items-center justify-center py-2 space-y-3">
        <motion.button
          onClick={handleTap}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.92 }}
          transition={{ type: 'spring', stiffness: 400, damping: 17 }}
          className="relative w-56 h-56 rounded-full bg-linear-to-b from-emerald-500 via-teal-600 to-emerald-800 text-white shadow-xl shadow-emerald-800/30 flex flex-col items-center justify-center border-4 border-white/20 select-none group focus:outline-hidden cursor-pointer"
        >
          {/* Subtle animated ring around */}
          <div className="absolute inset-1 rounded-full border border-white/30 pointer-events-none" />

          {/* Glowing pulse ring on target reach */}
          {currentCount > 0 && currentCount % selectedTarget === 0 && (
            <motion.div
              initial={{ scale: 1, opacity: 0.8 }}
              animate={{ scale: 1.25, opacity: 0 }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="absolute inset-0 rounded-full border-2 border-amber-300 pointer-events-none"
            />
          )}

          <span className="text-[11px] text-emerald-100/80 uppercase tracking-widest font-semibold">
            {cycleCount > 0 ? `চক্র: ${cycleCount}` : 'জিকির পাঠ'}
          </span>

          <motion.span
            key={currentCount}
            initial={{ scale: 0.85, opacity: 0.7 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.12 }}
            className="text-6xl font-extrabold font-mono tabular-nums tracking-tighter drop-shadow-sm mt-1"
          >
            {currentCount}
          </motion.span>

          <span className="text-xs text-emerald-200 font-medium mt-1">
            টার্গেট: {selectedTarget}
          </span>

          <div className="absolute bottom-4 px-3 py-1 rounded-full bg-black/20 text-[10px] text-emerald-100 backdrop-blur-xs">
            স্পর্শ করুন
          </div>
        </motion.button>

        {/* Eye-catching Reset and Quick Action Button directly under Tap Area */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => {
              triggerHaptic(15);
              setShowResetModal(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-800 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
          >
            <RotateCcw className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            <span>জিকির গণনা রিসেট (০) করুন</span>
          </button>
        </div>
      </div>

      {/* Progress ring or bar */}
      <div className="space-y-1 px-4">
        <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
          <div
            className="bg-emerald-500 h-full rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="flex justify-between text-[11px] text-slate-500">
          <span>০</span>
          <span>{Math.round(progressPercent)}% পূর্ণ</span>
          <span>{selectedTarget}</span>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xs w-full p-5 space-y-4 border border-slate-200 dark:border-slate-800 shadow-xl text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {t.resetConfirmTitle}
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {t.resetConfirmDesc}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setShowResetModal(false)}
                className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleConfirmReset}
                className="py-2.5 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
