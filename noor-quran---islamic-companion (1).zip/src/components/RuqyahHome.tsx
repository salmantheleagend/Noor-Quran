import React, { useState, useEffect, useRef, useMemo } from 'react';
import { AppLanguage } from '../types';
import {
  RuqyahCategory,
  RuqyahCategoryMeta,
  RuqyahItem,
  RUQYAH_CATEGORIES,
  RUQYAH_ITEMS,
} from '../data/ruqyahData';
import {
  ruqyahManager,
  RuqyahIntentAnalysis,
  DailyRoutineStatus,
} from '../services/RuqyahManager';
import {
  Shield,
  Play,
  Pause,
  RotateCcw,
  Search,
  Sparkles,
  BookOpen,
  Heart,
  Bookmark,
  Share2,
  Check,
  ChevronRight,
  ChevronLeft,
  X,
  Volume2,
  Clock,
  AlertTriangle,
  Flame,
  Moon,
  Sun,
  Eye,
  HeartPulse,
  Home as HomeIcon,
  Compass,
  ShieldCheck,
  Download,
  Info,
  CheckCircle2,
  ListMusic,
  SkipForward,
  SkipBack,
  Repeat,
  Maximize2,
  Sliders,
  Type,
  HelpCircle,
  Headphones,
  CheckCheck,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface RuqyahHomeProps {
  language?: AppLanguage;
  onBack?: () => void;
  onOpenSettings?: () => void;
}

export const RuqyahHome: React.FC<RuqyahHomeProps> = ({
  language = 'bn',
  onBack,
}) => {
  // Mode: Simple (audio-first, large prominent buttons) vs Learn (text, tajweed, step-by-step)
  const [viewMode, setViewMode] = useState<'simple' | 'learn'>('learn');

  // Search input & Intent analysis
  const [searchQuery, setSearchQuery] = useState('');
  const [intentAnalysis, setIntentAnalysis] = useState<RuqyahIntentAnalysis | null>(null);

  // Selected Category filter ('all' or specific RuqyahCategory)
  const [selectedCategory, setSelectedCategory] = useState<RuqyahCategory | 'all'>('all');

  // Active / Playing Ruqyah item
  const [activeItem, setActiveItem] = useState<RuqyahItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSlowMode, setIsSlowMode] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isLooping, setIsLooping] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(0); // 0 to 100
  const [currentTimeFormatted, setCurrentTimeFormatted] = useState('00:00');
  const [durationFormatted, setDurationFormatted] = useState('00:00');

  // Sleep Timer
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimeRemaining, setSleepTimeRemaining] = useState<number | null>(null);

  // Detail Modal
  const [detailItem, setDetailItem] = useState<RuqyahItem | null>(null);
  const [fontSizeArabic, setFontSizeArabic] = useState<number>(24);

  // Daily Routine Status
  const [routineStatus, setRoutineStatus] = useState<DailyRoutineStatus>(() =>
    ruqyahManager.getDailyRoutineStatus()
  );

  // Favorites & Offline
  const [favorites, setFavorites] = useState<string[]>(() => ruqyahManager.getFavoriteIds());
  const [offlineIds, setOfflineIds] = useState<string[]>(() => ruqyahManager.getOfflineSavedIds());

  // Active Tab Filter within Category View (All, Favorites, Saved)
  const [itemFilter, setItemFilter] = useState<'all' | 'favorites' | 'routine'>('all');

  // Feedback Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio HTML Element Ref
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Quick Intent Suggestion Prompts
  const intentQuickChips = [
    { label: 'বদনজর / Bad Nojor', query: 'bad nojor lagse' },
    { label: 'ঘুমে চেপে ধরা', query: 'ghume chepe dhore' },
    { label: 'জিনের ভয় ও ওয়াসওয়াসা', query: 'jin er voy waswasa' },
    { label: 'জাদু / সিহর থেকে সুরক্ষা', query: 'jadu sihor theke bachte chai' },
    { label: 'শারীরিক ব্যথা ও শিফা', query: 'shorire betha' },
    { label: 'বাচ্চা ও ঘরের সুরক্ষা', query: 'child protection dua' },
    { label: 'ভয় ও দুশ্চিন্তা', query: 'anxiety voy lagse' },
    { label: 'সকাল-সন্ধ্যার দুর্গ', query: 'shokal shondha azkar' },
  ];

  // Icon Resolver
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Eye':
        return <Eye className="w-5 h-5" />;
      case 'Flame':
        return <Flame className="w-5 h-5" />;
      case 'Shield':
        return <Shield className="w-5 h-5" />;
      case 'Moon':
        return <Moon className="w-5 h-5" />;
      case 'HeartPulse':
        return <HeartPulse className="w-5 h-5" />;
      case 'Home':
        return <HomeIcon className="w-5 h-5" />;
      case 'Sun':
        return <Sun className="w-5 h-5" />;
      case 'Compass':
        return <Compass className="w-5 h-5" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5" />;
      default:
        return <Shield className="w-5 h-5" />;
    }
  };

  // Run Intent Analysis on Search Query
  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const result = ruqyahManager.analyzeIntent(searchQuery);
      setIntentAnalysis(result);
    } else {
      setIntentAnalysis(null);
    }
  }, [searchQuery]);

  // Sleep Timer Countdown
  useEffect(() => {
    if (!sleepTimerMinutes) {
      setSleepTimeRemaining(null);
      return;
    }

    setSleepTimeRemaining(sleepTimerMinutes * 60);

    const interval = setInterval(() => {
      setSleepTimeRemaining((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          if (audioRef.current) {
            audioRef.current.pause();
          }
          setIsPlaying(false);
          setSleepTimerMinutes(null);
          showToast('স্লিপ টাইমার শেষ হয়েছে, অডিও বন্ধ করা হয়েছে।');
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Play a specific Ruqyah item
  const handlePlayItem = (item: RuqyahItem, slow: boolean = false) => {
    triggerHaptic(20);
    setActiveItem(item);
    setIsSlowMode(slow);
    setIsPlaying(true);
    ruqyahManager.recordHistory(item.id);

    // Audio setup
    const audioUrl = slow
      ? item.audioSlowUrl || item.audioFullUrl || 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3'
      : item.audioFullUrl || item.audioSlowUrl || 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3';

    if (audioRef.current) {
      audioRef.current.src = audioUrl;
      audioRef.current.playbackRate = slow ? 0.8 : playbackSpeed;
      audioRef.current.loop = isLooping;
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(() => {
          // If network stream fails or blocked by browser autoplay policy
          setIsPlaying(true);
        });
    }
  };

  const handleTogglePlayPause = () => {
    triggerHaptic(15);
    if (!activeItem) {
      // If none active, play the first daily routine item
      const routine = ruqyahManager.getDailyProtectionRoutine();
      handlePlayItem(routine[0]);
      return;
    }

    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current
          .play()
          .then(() => setIsPlaying(true))
          .catch(() => setIsPlaying(true));
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleNextTrack = () => {
    triggerHaptic(15);
    const playlist =
      selectedCategory === 'all'
        ? RUQYAH_ITEMS
        : RUQYAH_ITEMS.filter((i) => i.category === selectedCategory);
    if (!activeItem || playlist.length === 0) return;

    const currentIndex = playlist.findIndex((i) => i.id === activeItem.id);
    const nextIndex = (currentIndex + 1) % playlist.length;
    handlePlayItem(playlist[nextIndex], isSlowMode);
  };

  const handlePrevTrack = () => {
    triggerHaptic(15);
    const playlist =
      selectedCategory === 'all'
        ? RUQYAH_ITEMS
        : RUQYAH_ITEMS.filter((i) => i.category === selectedCategory);
    if (!activeItem || playlist.length === 0) return;

    const currentIndex = playlist.findIndex((i) => i.id === activeItem.id);
    const prevIndex = (currentIndex - 1 + playlist.length) % playlist.length;
    handlePlayItem(playlist[prevIndex], isSlowMode);
  };

  const handlePlayDailyRuqyah = () => {
    triggerHaptic(25);
    const routine = ruqyahManager.getDailyProtectionRoutine();
    if (routine.length > 0) {
      handlePlayItem(routine[0]);
      showToast('আজকের সুরক্ষা রুটিন প্লেলিস্ট শুরু হয়েছে');
    }
  };

  const handleToggleRoutineCheck = (itemId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic(20);
    const updated = ruqyahManager.toggleRoutineItem(itemId);
    setRoutineStatus(updated);
    if (updated.completedIds.includes(itemId)) {
      showToast('আমল সম্পন্ন হিসেবে চিহ্নিত করা হয়েছে');
    }
  };

  const handleToggleFavorite = (itemId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic(15);
    const isNowFav = ruqyahManager.toggleFavorite(itemId);
    setFavorites(ruqyahManager.getFavoriteIds());
    showToast(isNowFav ? 'পছন্দের তালিকায় যুক্ত হয়েছে' : 'পছন্দের তালিকা থেকে বাদ দেওয়া হয়েছে');
  };

  const handleToggleOffline = (itemId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic(15);
    const isSaved = ruqyahManager.toggleOfflineSave(itemId);
    setOfflineIds(ruqyahManager.getOfflineSavedIds());
    showToast(isSaved ? 'অফলাইনে সংরক্ষণের জন্য বুকমার্ক করা হয়েছে' : 'অফলাইন তালিকা থেকে সরানো হয়েছে');
  };

  const handleShareRuqyah = (item: RuqyahItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic(15);
    const shareText = `*${item.titleBn}*\n\nআরবি: ${item.arabic}\n\nউচ্চারণ: ${item.transliterationBn}\n\nঅর্থ: "${item.translationBn}"\n\nসূত্র: ${item.source}\n(নূর কুরআন - রুকইয়াহ শারইয়াহ)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareText);
      showToast('রুকইয়াহর পূর্ণ বিবরণ ক্লিপবোর্ডে কপি হয়েছে');
    }
  };

  // Audio Event Listeners
  const onTimeUpdate = () => {
    if (!audioRef.current) return;
    const cur = audioRef.current.currentTime;
    const dur = audioRef.current.duration || 0;
    if (dur > 0) {
      setCurrentProgress((cur / dur) * 100);
      const curM = Math.floor(cur / 60)
        .toString()
        .padStart(2, '0');
      const curS = Math.floor(cur % 60)
        .toString()
        .padStart(2, '0');
      const durM = Math.floor(dur / 60)
        .toString()
        .padStart(2, '0');
      const durS = Math.floor(dur % 60)
        .toString()
        .padStart(2, '0');
      setCurrentTimeFormatted(`${curM}:${curS}`);
      setDurationFormatted(`${durM}:${durS}`);
    }
  };

  const onAudioEnded = () => {
    if (isLooping) {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    } else {
      handleNextTrack();
    }
  };

  // Items to display based on category & filters
  const displayedItems = useMemo(() => {
    let list =
      selectedCategory === 'all'
        ? RUQYAH_ITEMS
        : RUQYAH_ITEMS.filter((item) => item.category === selectedCategory);

    if (itemFilter === 'favorites') {
      list = list.filter((item) => favorites.includes(item.id));
    } else if (itemFilter === 'routine') {
      const routineItems = ruqyahManager.getDailyProtectionRoutine();
      list = list.filter((item) => routineItems.some((r) => r.id === item.id));
    }

    return list;
  }, [selectedCategory, itemFilter, favorites]);

  // Routine items list
  const dailyRoutineItems = useMemo(() => {
    return ruqyahManager.getDailyProtectionRoutine();
  }, []);

  return (
    <div className="pb-32 pt-1 px-3 sm:px-4 max-w-2xl mx-auto space-y-5 text-slate-900 dark:text-slate-100 font-sans selection:bg-emerald-200 dark:selection:bg-emerald-800">
      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        onTimeUpdate={onTimeUpdate}
        onEnded={onAudioEnded}
        onError={() => setIsPlaying(false)}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/95 dark:bg-emerald-900/95 text-white px-4 py-2 rounded-full text-xs font-medium shadow-xl border border-emerald-500/40 backdrop-blur-md animate-fade-in flex items-center gap-2">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar / Navigation Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2.5">
          {onBack && (
            <button
              onClick={onBack}
              className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors"
              title="পিছনে যান"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                <span>রুকইয়াহ শারইয়াহ</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-300/40">
                  সহিহ ও দলিলভিত্তিক
                </span>
              </h1>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              কুরআন ও সুন্নাহ নির্দেশিত আত্মিক শিফা, বদনজর ও সিহর থেকে হিফাজত
            </p>
          </div>
        </div>

        {/* Mode Switcher: Simple vs Learn */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-2xs">
          <button
            onClick={() => {
              triggerHaptic(10);
              setViewMode('simple');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              viewMode === 'simple'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            সিম্পল মোড
          </button>
          <button
            onClick={() => {
              triggerHaptic(10);
              setViewMode('learn');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              viewMode === 'learn'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            লার্ন মোড
          </button>
        </div>
      </div>

      {/* TODAY'S PROTECTIVE ROUTINE CARD (আজকের সুরক্ষা রুটিন) */}
      <section className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-900 via-teal-900 to-slate-950 text-white p-5 sm:p-6 shadow-xl shadow-emerald-950/20 border border-emerald-500/30">
        {/* Subtle Islamic Geometric Arch Background Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          {/* Header Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center justify-center">
                <ShieldCheck className="w-4.5 h-4.5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                  <span>আজকের সুরক্ষা রুটিন</span>
                  <span className="text-[11px] font-medium text-emerald-200/90 font-mono">
                    ({routineStatus.completedCount}/{routineStatus.total})
                  </span>
                </h2>
                <p className="text-[11px] text-emerald-200/80">
                  প্রতিদিনের ৫টি মৌলিক আমল দ্বারা নিজেকে ও পরিবারকে সুরক্ষিত রাখুন
                </p>
              </div>
            </div>

            {/* Completion Percentage Badge */}
            <div className="text-right">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-amber-300 text-xs font-mono font-bold">
                {routineStatus.percentage}% সম্পন্ন
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-black/30 rounded-full h-2 overflow-hidden border border-white/10">
            <div
              className="bg-linear-to-r from-amber-400 to-emerald-400 h-full rounded-full transition-all duration-500 ease-out"
              style={{ width: `${routineStatus.percentage}%` }}
            />
          </div>

          {/* Quick Action Checklist Items */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            {dailyRoutineItems.map((item) => {
              const isChecked = routineStatus.completedIds.includes(item.id);
              const isItemPlaying = activeItem?.id === item.id && isPlaying;

              return (
                <div
                  key={item.id}
                  onClick={() => handlePlayItem(item)}
                  className={`flex items-center justify-between p-2.5 rounded-2xl border transition-all cursor-pointer ${
                    isChecked
                      ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-100'
                      : 'bg-white/10 hover:bg-white/15 border-white/10 text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-2">
                    <button
                      onClick={(e) => handleToggleRoutineCheck(item.id, e)}
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all shrink-0 ${
                        isChecked
                          ? 'bg-emerald-500 border-emerald-400 text-white shadow-xs'
                          : 'border-white/30 hover:border-amber-400 text-transparent'
                      }`}
                      title={isChecked ? 'সম্পন্ন (আনচেক করতে ট্যাপ করুন)' : 'সম্পন্ন করুন'}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </button>
                    <div className="truncate">
                      <span className="text-xs font-semibold block truncate">
                        {item.titleBn}
                      </span>
                      <span className="text-[10px] text-emerald-200/70 block">
                        {item.repeatNoteBn || `${item.repeatCount} বার পাঠ্য`}
                      </span>
                    </div>
                  </div>

                  {/* Play Trigger */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (isItemPlaying) {
                        handleTogglePlayPause();
                      } else {
                        handlePlayItem(item);
                      }
                    }}
                    className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 transition-transform active:scale-90 ${
                      isItemPlaying
                        ? 'bg-amber-400 text-slate-950 font-bold'
                        : 'bg-white/20 text-white hover:bg-white/30'
                    }`}
                    title={isItemPlaying ? 'পজ করুন' : 'শুনুন'}
                  >
                    {isItemPlaying ? (
                      <Pause className="w-3.5 h-3.5 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    )}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Big Prominent "Play Daily Ruqyah" Button */}
          <div className="pt-2">
            <button
              onClick={handlePlayDailyRuqyah}
              className="w-full py-3.5 px-5 rounded-2xl bg-linear-to-r from-amber-400 via-amber-300 to-amber-400 hover:from-amber-300 hover:to-amber-500 text-emerald-950 font-black text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-lg shadow-amber-400/20 active:scale-98 transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-950 text-amber-300 flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
                <Play className="w-4 h-4 fill-current ml-0.5" />
              </div>
              <span>Play Daily Ruqyah · সম্পূর্ণ দৈনিক সুরক্ষা অডিও শুনুন</span>
            </button>
          </div>
        </div>
      </section>

      {/* SMART RUQYAH ASSISTANT / INTENT SEARCH */}
      <section className="rounded-3xl bg-white dark:bg-slate-900 p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
              স্মার্ট রুকইয়াহ সার্চ ও সমস্যা নির্দেশিকা
            </h3>
          </div>
          <span className="text-[10px] text-slate-400">বাংলা, Banglish বা English</span>
        </div>

        {/* Input Bar */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="আপনার সমস্যা বা লক্ষণ লিখুন (যেমন: bad nojor, ghume chepe dhore, jin er voy)..."
            className="w-full pl-10 pr-10 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/50 transition-all"
          />
          <Search className="w-4.5 h-4.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2 flex items-center justify-center hover:bg-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {intentQuickChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                triggerHaptic(10);
                setSearchQuery(chip.query);
              }}
              className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 hover:text-emerald-700 dark:hover:text-emerald-300 border border-slate-200/60 dark:border-slate-700/60 transition-colors"
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* Intent Analysis Result Card (Rendered if user searched) */}
        {intentAnalysis && (
          <div className="mt-3 p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/60 space-y-3 animate-fade-in">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                শনাক্তকৃত ক্যাটাগরি: {intentAnalysis.categoryMeta.nameBn}
              </span>
              <span className="text-[10px] bg-emerald-200/70 dark:bg-emerald-800/60 text-emerald-900 dark:text-emerald-100 font-bold px-2 py-0.5 rounded-full">
                মিলেছে {Math.round(intentAnalysis.confidence * 100)}%
              </span>
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {intentAnalysis.intentTitleBn}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                💡 <strong>কেন এই আমল:</strong> {intentAnalysis.recommendedReasonBn}
              </p>
            </div>

            {/* Medical Alert Warning if physical pain/seizures */}
            {intentAnalysis.medicalAdviceRequired && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-300/60 dark:border-amber-800/80 text-amber-900 dark:text-amber-200 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p>{intentAnalysis.medicalAlertMessageBn}</p>
              </div>
            )}

            {/* Primary Recommended Ruqyah Action */}
            <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-900 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold uppercase block">
                  প্রধান প্রস্তাবিত রুকইয়াহ
                </span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {intentAnalysis.primaryRuqyah.titleBn}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setDetailItem(intentAnalysis.primaryRuqyah)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200"
                >
                  নিয়ম দেখুন
                </button>
                <button
                  onClick={() => handlePlayItem(intentAnalysis.primaryRuqyah)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>শুনুন</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* RUQYAH CATEGORIES GRID (১০টি সুনির্দিষ্ট ক্যাটাগরি) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>রুকইয়াহ ক্যাটাগরি</span>
              <span className="text-xs text-slate-400 font-normal">({RUQYAH_CATEGORIES.length}টি বিভাগ)</span>
            </h3>
            <p className="text-[11px] text-slate-500">আপনার প্রয়োজনীয় বিষয়ে ক্লিক করে রুকইয়াহ নির্বাচন করুন</p>
          </div>

          {selectedCategory !== 'all' && (
            <button
              onClick={() => setSelectedCategory('all')}
              className="text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
            >
              <span>সবগুলো দেখুন</span>
              <RotateCcw className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* 2-Column Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {RUQYAH_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;

            return (
              <div
                key={cat.id}
                onClick={() => {
                  triggerHaptic(15);
                  setSelectedCategory(isSelected ? 'all' : cat.id);
                }}
                className={`p-4 rounded-3xl border transition-all cursor-pointer relative overflow-hidden group ${
                  isSelected
                    ? 'bg-emerald-50/90 dark:bg-emerald-950/60 border-emerald-500 ring-2 ring-emerald-500/20 shadow-md'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 shadow-2xs'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Category Icon Badge */}
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${
                      isSelected
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : `${cat.colorScheme.bg} ${cat.colorScheme.text} border ${cat.colorScheme.border}`
                    }`}
                  >
                    {getCategoryIcon(cat.iconName)}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                        {cat.nameBn}
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono font-medium shrink-0">
                        {cat.totalCount}টি
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-normal">
                      {cat.descriptionBn}
                    </p>

                    <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[10px]">
                      <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
                        {cat.colorScheme.badge}
                      </span>
                      <span className="text-slate-400 flex items-center gap-0.5 font-medium group-hover:text-emerald-600">
                        <span>{isSelected ? 'বন্ধ করুন' : 'বিস্তারিত তালিকা'}</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* FILTER TABS & MAIN RUQYAH ITEMS LIST */}
      <section className="space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            <button
              onClick={() => setItemFilter('all')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                itemFilter === 'all'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              সকল রুকইয়াহ ({displayedItems.length})
            </button>
            <button
              onClick={() => setItemFilter('routine')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                itemFilter === 'routine'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              দৈনিক রুটিন (৫)
            </button>
            <button
              onClick={() => setItemFilter('favorites')}
              className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 ${
                itemFilter === 'favorites'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Heart className="w-3 h-3 fill-current text-rose-500" />
              <span>পছন্দ ({favorites.length})</span>
            </button>
          </div>

          <span className="text-[11px] text-slate-400 hidden sm:inline">
            {selectedCategory === 'all' ? 'সকল বিষয়' : RUQYAH_CATEGORIES.find((c) => c.id === selectedCategory)?.nameBn}
          </span>
        </div>

        {/* Empty State */}
        {displayedItems.length === 0 && (
          <div className="text-center py-10 space-y-2 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <Shield className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
            <p className="text-xs text-slate-500">এই ফিল্টারে কোনো রুকইয়াহ পাওয়া যায়নি।</p>
            <button
              onClick={() => {
                setItemFilter('all');
                setSelectedCategory('all');
              }}
              className="text-xs text-emerald-600 font-bold hover:underline"
            >
              সবগুলো রুকইয়াহ দেখুন
            </button>
          </div>
        )}

        {/* Items List */}
        <div className="space-y-3">
          {displayedItems.map((item) => {
            const isPlayingThis = activeItem?.id === item.id && isPlaying;
            const isFav = favorites.includes(item.id);
            const isSaved = offlineIds.includes(item.id);
            const isDoneToday = routineStatus.completedIds.includes(item.id);

            return (
              <div
                key={item.id}
                className={`rounded-3xl border transition-all overflow-hidden ${
                  isPlayingThis
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-2xs'
                }`}
              >
                {/* Header Strip */}
                <div className="p-4 sm:p-5 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {item.categoryBn}
                        </span>
                        {item.repeatNoteBn && (
                          <span className="text-[10px] text-amber-700 dark:text-amber-300 font-medium">
                            • {item.repeatNoteBn}
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white mt-1">
                        {item.titleBn}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        {item.purposeBn}
                      </p>
                    </div>

                    {/* Bookmark / Favorite Action Icons */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => handleToggleFavorite(item.id, e)}
                        className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                          isFav
                            ? 'text-rose-600 bg-rose-50 dark:bg-rose-950/60'
                            : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                        title="পছন্দের তালিকায় রাখুন"
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                      </button>

                      <button
                        onClick={(e) => handleToggleOffline(item.id, e)}
                        className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                          isSaved
                            ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60'
                            : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                        title="অফলাইন সেভ"
                      >
                        <Download className="w-4 h-4" />
                      </button>

                      <button
                        onClick={(e) => handleShareRuqyah(item, e)}
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="কপি ও শেয়ার"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Arabic Text Presentation */}
                  <div
                    className="p-4 rounded-2xl bg-amber-50/30 dark:bg-slate-950/50 border border-amber-200/40 dark:border-slate-800/80 text-right"
                    dir="rtl"
                  >
                    <p
                      className="font-uthmani text-lg sm:text-xl text-slate-900 dark:text-slate-100 font-bold leading-loose select-text"
                      dir="rtl"
                    >
                      {item.arabic}
                    </p>
                  </div>

                  {/* Learn Mode: Transliteration & Translation */}
                  {viewMode === 'learn' && (
                    <div className="space-y-2 text-xs">
                      {/* Transliteration */}
                      <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50 text-emerald-900 dark:text-emerald-200">
                        <span className="font-bold block mb-0.5 text-[11px] text-emerald-700 dark:text-emerald-400">
                          উচ্চারণ (সহজ পঠন):
                        </span>
                        <p className="leading-relaxed">{item.transliterationBn}</p>
                      </div>

                      {/* Translation */}
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-slate-700 dark:text-slate-300">
                        <span className="font-bold block mb-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                          বাংলা অর্থ:
                        </span>
                        <p className="leading-relaxed">"{item.translationBn}"</p>
                      </div>

                      {/* Reference Badge */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                        <span>দলিল: {item.source}</span>
                        <button
                          onClick={() => setDetailItem(item)}
                          className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-0.5"
                        >
                          <span>নিয়ম ও নির্দেশিকা</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Action Bar / Dual Audio Controller */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      {/* Full Audio Play Button */}
                      <button
                        onClick={() => {
                          if (isPlayingThis && !isSlowMode) {
                            handleTogglePlayPause();
                          } else {
                            handlePlayItem(item, false);
                          }
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                          isPlayingThis && !isSlowMode
                            ? 'bg-amber-500 hover:bg-amber-600 text-white animate-pulse'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        {isPlayingThis && !isSlowMode ? (
                          <>
                            <Pause className="w-3.5 h-3.5 fill-current" />
                            <span>থামুন</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5 fill-current" />
                            <span>পূর্ণ অডিও</span>
                          </>
                        )}
                      </button>

                      {/* Slow Audio for Learning */}
                      <button
                        onClick={() => {
                          if (isPlayingThis && isSlowMode) {
                            handleTogglePlayPause();
                          } else {
                            handlePlayItem(item, true);
                          }
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-all ${
                          isPlayingThis && isSlowMode
                            ? 'bg-amber-100 dark:bg-amber-950/80 border-amber-400 text-amber-900 dark:text-amber-200'
                            : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                        }`}
                        title="ধীরগতির শেখার অডিও"
                      >
                        <Headphones className="w-3.5 h-3.5 text-emerald-600" />
                        <span>ধীরে শুনুন (0.8x)</span>
                      </button>
                    </div>

                    {/* Today's Checklist Check */}
                    <button
                      onClick={() => handleToggleRoutineCheck(item.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                        isDoneToday
                          ? 'bg-emerald-100/90 dark:bg-emerald-900/60 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
                          : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-500 hover:border-slate-300'
                      }`}
                    >
                      <Check className={`w-3.5 h-3.5 ${isDoneToday ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{isDoneToday ? 'আজকে সম্পন্ন' : 'আমল সম্পন্ন করুন'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* DETAIL MODAL (কেন এই রুকইয়াহ ও পূর্ণ ব্যবহারবিধি) */}
      {detailItem && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
          <div className="w-full max-w-lg max-h-[90vh] bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                    রুকইয়াহ ব্যবহারবিধি ও দলিল
                  </h3>
                  <span className="text-[10px] text-slate-400">{detailItem.categoryBn}</span>
                </div>
              </div>

              <button
                onClick={() => setDetailItem(null)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  {detailItem.titleBn}
                </h4>
                <span className="font-arabic text-sm text-emerald-700 dark:text-emerald-400 block mt-0.5" dir="rtl">
                  {detailItem.titleAr}
                </span>
              </div>

              {/* Purpose / Why This Ruqyah */}
              <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-900/60 text-xs text-amber-950 dark:text-amber-200 space-y-1">
                <span className="font-bold flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
                  <Info className="w-3.5 h-3.5" />
                  কেন এই রুকইয়াহ এবং কী প্রয়োজনে পড়া হয়:
                </span>
                <p className="leading-relaxed">{detailItem.purposeBn}</p>
                {detailItem.targetBenefitBn && (
                  <p className="font-semibold text-emerald-800 dark:text-emerald-300 pt-1">
                    ✨ প্রত্যক্ষ ফায়দা: {detailItem.targetBenefitBn}
                  </p>
                )}
              </div>

              {/* Arabic Box */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-right" dir="rtl">
                <p className="font-uthmani text-xl sm:text-2xl font-bold leading-loose text-slate-900 dark:text-white" dir="rtl">
                  {detailItem.arabic}
                </p>
              </div>

              {/* Transliteration & Meaning */}
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900 text-emerald-950 dark:text-emerald-200">
                  <span className="font-bold block text-[11px] text-emerald-700 dark:text-emerald-400 mb-0.5">
                    উচ্চারণ:
                  </span>
                  <p className="leading-relaxed">{detailItem.transliterationBn}</p>
                </div>

                <div className="p-3 rounded-xl bg-slate-100/70 dark:bg-slate-800/60 text-slate-700 dark:text-slate-200">
                  <span className="font-bold block text-[11px] text-slate-500 mb-0.5">অর্থ:</span>
                  <p className="leading-relaxed">"{detailItem.translationBn}"</p>
                </div>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="space-y-2">
                <h5 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <CheckCheck className="w-4 h-4 text-emerald-600" />
                  <span>ধাপে ধাপে আমল করার নিয়মাবলী:</span>
                </h5>
                <ol className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-decimal list-inside pl-1">
                  {detailItem.instructionsBn.map((step, idx) => (
                    <li key={idx} className="leading-relaxed">
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              {/* Hadith / Quran Source Verification */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300 block mb-0.5">
                  সহিহ সূত্র ও রেফারেন্স:
                </span>
                <p className="text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                  {detailItem.source}
                </p>
                {detailItem.repeatNoteBn && (
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-bold block mt-1">
                    কখন ও কতবার পাঠ্য: {detailItem.repeatNoteBn}
                  </span>
                )}
              </div>
            </div>

            {/* Modal Footer Controls */}
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center gap-2">
              <button
                onClick={() => {
                  handlePlayItem(detailItem);
                  setDetailItem(null);
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-98"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>এখনই অডিও শুনুন</span>
              </button>

              <button
                onClick={() => setDetailItem(null)}
                className="py-3 px-4 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PERSISTENT MINI AUDIO PLAYER (Sticky at Bottom) */}
      {activeItem && (
        <div className="fixed bottom-16 left-0 right-0 z-40 px-2 sm:px-4 max-w-2xl mx-auto animate-slide-up">
          <div className="rounded-3xl bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md text-white p-3 sm:p-4 shadow-2xl border border-emerald-500/40 space-y-2">
            {/* Progress Bar */}
            <div className="w-full bg-white/10 rounded-full h-1 overflow-hidden">
              <div
                className="bg-emerald-400 h-full rounded-full transition-all duration-200"
                style={{ width: `${currentProgress}%` }}
              />
            </div>

            <div className="flex items-center justify-between gap-3">
              {/* Item Info */}
              <div
                onClick={() => setDetailItem(activeItem)}
                className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer"
              >
                <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                  <Volume2 className="w-5 h-5 animate-pulse" />
                </div>
                <div className="truncate">
                  <h5 className="text-xs font-bold text-white truncate">
                    {activeItem.titleBn}
                  </h5>
                  <div className="flex items-center gap-2 text-[10px] text-emerald-200/80">
                    <span>{currentTimeFormatted} / {durationFormatted}</span>
                    <span>•</span>
                    <span className="text-amber-300">{isSlowMode ? 'লার্ন অডিও (0.8x)' : `${playbackSpeed}x স্পিড`}</span>
                    {sleepTimeRemaining !== null && (
                      <span className="text-sky-300 font-mono">
                        ⏰ {Math.ceil(sleepTimeRemaining / 60)} মি.
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                <button
                  onClick={handlePrevTrack}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:text-white"
                  title="পূর্ববর্তী"
                >
                  <SkipBack className="w-4 h-4 fill-current" />
                </button>

                <button
                  onClick={handleTogglePlayPause}
                  className="w-10 h-10 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold flex items-center justify-center shadow-lg active:scale-95 transition-transform"
                  title={isPlaying ? 'পজ' : 'চালু করুন'}
                >
                  {isPlaying ? (
                    <Pause className="w-4 h-4 fill-current" />
                  ) : (
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  )}
                </button>

                <button
                  onClick={handleNextTrack}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:text-white"
                  title="পরবর্তী"
                >
                  <SkipForward className="w-4 h-4 fill-current" />
                </button>

                {/* Sleep Timer Preset Selector */}
                <div className="relative group">
                  <button
                    onClick={() => {
                      triggerHaptic(10);
                      const presets = [null, 15, 30, 60];
                      const curIndex = presets.indexOf(sleepTimerMinutes);
                      const next = presets[(curIndex + 1) % presets.length];
                      setSleepTimerMinutes(next);
                      if (next) showToast(`স্লিপ টাইমার: ${next} মিনিট`);
                      else showToast('স্লিপ টাইমার বন্ধ');
                    }}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                      sleepTimerMinutes ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40' : 'text-slate-400 hover:text-white'
                    }`}
                    title="স্লিপ টাইমার"
                  >
                    <Clock className="w-4 h-4" />
                  </button>
                </div>

                {/* Close Player */}
                <button
                  onClick={() => {
                    if (audioRef.current) audioRef.current.pause();
                    setIsPlaying(false);
                    setActiveItem(null);
                  }}
                  className="w-7 h-7 rounded-full text-slate-400 hover:text-white flex items-center justify-center"
                  title="প্লেয়ার বন্ধ করুন"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default RuqyahHome;
