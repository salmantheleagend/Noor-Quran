import React, { useState } from 'react';
import { AppLanguage, LocationInfo, PrayerTimesData, NaflPrayerItem } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  calculatePrayerTimes,
  formatPrayerTime12h,
  getNaflPrayersList,
  getRunningNaflPrayer,
} from '../utils/prayerTimes';
import {
  Clock,
  Calendar,
  AlertTriangle,
  Bell,
  BellOff,
  Volume2,
  ChevronDown,
  ChevronUp,
  Check,
  Sunrise,
  Sunset,
  Moon,
  Settings,
  Sparkles,
  BookOpen,
  Info,
  Heart,
  HelpCircle,
} from 'lucide-react';
import { playAdhanTone, triggerHaptic } from '../utils/audioPlayer';
import { NamazTracker } from './NamazTracker';

interface PrayerScheduleProps {
  language: AppLanguage;
  location: LocationInfo;
  prayerTimes: PrayerTimesData;
  calculationMethod: string;
  asrMethod: 'hanafi' | 'standard';
  onChangeCalculationMethod: (method: string) => void;
  onChangeAsrMethod: (method: 'hanafi' | 'standard') => void;
  onOpenLocationModal: () => void;
  ramadanMode?: boolean;
  onToggleRamadanMode?: () => void;
}

export const PrayerSchedule: React.FC<PrayerScheduleProps> = ({
  language,
  location,
  prayerTimes,
  calculationMethod,
  asrMethod,
  onChangeCalculationMethod,
  onChangeAsrMethod,
  onOpenLocationModal,
  ramadanMode = false,
  onToggleRamadanMode,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'today' | 'tracker' | '7days' | 'monthly'>('today');
  const [selectedNaflFilter, setSelectedNaflFilter] = useState<'all' | 'timed' | 'general'>('all');
  const [expandedNaflId, setExpandedNaflId] = useState<string | null>(null);

  const [notificationToggles, setNotificationToggles] = useState<Record<string, boolean>>({
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  });

  const toggleNotification = (waqt: string) => {
    triggerHaptic(15);
    setNotificationToggles(prev => ({
      ...prev,
      [waqt]: !prev[waqt],
    }));
  };

  const handleTestAdhan = () => {
    triggerHaptic(25);
    playAdhanTone();
  };

  // Nafl Prayers Data
  const naflPrayers = getNaflPrayersList(prayerTimes, new Date(), language);
  const runningNafl = getRunningNaflPrayer(prayerTimes, new Date(), language);

  const filteredNafl = naflPrayers.filter((p) => {
    if (selectedNaflFilter === 'timed') return p.isTimeBounded;
    if (selectedNaflFilter === 'general') return !p.isTimeBounded;
    return true;
  });

  // Generate 7-day forecast
  const next7Days = [...Array(7)].map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const times = calculatePrayerTimes(d, location, calculationMethod, asrMethod);
    const dateLabel = d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
    return { date: d, dateLabel, times };
  });

  // Generate 30-day monthly schedule
  const monthlyDays = [...Array(30)].map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const times = calculatePrayerTimes(d, location, calculationMethod, asrMethod);
    const dayStr = d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
      month: 'numeric',
      day: 'numeric',
    });
    const weekdayStr = d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
      weekday: 'short',
    });
    return { dayStr, weekdayStr, times };
  });

  const mainWaqts = [
    {
      id: 'fajr',
      label: t.fajr,
      startTime: prayerTimes.fajr,
      endTime: prayerTimes.sunrise,
      icon: <Moon className="w-4 h-4 text-indigo-400" />,
    },
    {
      id: 'dhuhr',
      label: t.dhuhr,
      startTime: prayerTimes.dhuhr,
      endTime: prayerTimes.asr,
      icon: <Sunrise className="w-4 h-4 text-amber-500" />,
    },
    {
      id: 'asr',
      label: t.asr,
      startTime: prayerTimes.asr,
      endTime: prayerTimes.sunsetProhibitedStart,
      icon: <Sunset className="w-4 h-4 text-orange-500" />,
    },
    {
      id: 'maghrib',
      label: t.maghrib,
      startTime: prayerTimes.maghrib,
      endTime: prayerTimes.isha,
      icon: <Sunset className="w-4 h-4 text-rose-500" />,
    },
    {
      id: 'isha',
      label: t.isha,
      startTime: prayerTimes.isha,
      endTime: prayerTimes.fajr,
      icon: <Moon className="w-4 h-4 text-indigo-600" />,
    },
  ];

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Header & Location & Ramadan Mode Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t.prayer}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {language === 'bn' ? location.nameBn : location.name}, {location.country}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {/* USER REQUESTED RAMADAN MODE TOGGLE */}
          {onToggleRamadanMode && (
            <button
              onClick={() => {
                triggerHaptic(20);
                onToggleRamadanMode();
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                ramadanMode
                  ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
              }`}
              title="রমজান ও রোজা মোড চালু/বন্ধ"
            >
              <span className="text-sm">🌙</span>
              <span>{ramadanMode ? 'রমজান মোড: চালু' : 'রমজান মোড চালু করুন'}</span>
            </button>
          )}

          <button
            onClick={handleTestAdhan}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs font-semibold hover:bg-emerald-100 transition-colors border border-emerald-200/60 dark:border-emerald-800/60 cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>আযান সুর</span>
          </button>
        </div>
      </div>

      {/* SPECIAL RAMADAN FASTING BANNER (When Ramadan Mode is active) */}
      {ramadanMode && (
        <div className="p-4 rounded-3xl bg-linear-to-r from-emerald-950 via-teal-900 to-slate-950 text-white border border-amber-400/50 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase font-bold text-amber-300 flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>🌙 মোবারক রমাদান ও রোজা সময়সূচি</span>
            </span>
            <span className="text-[11px] text-emerald-200">
              আজকের রোজা
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
              <span className="text-[10px] text-amber-200 block font-semibold">সাহরির শেষ সময়</span>
              <span className="text-lg font-black font-mono text-white mt-0.5 block">
                {formatPrayerTime12h(prayerTimes.sahriEnd, language)}
              </span>
              <span className="text-[10px] text-slate-300 block">ফজর: {formatPrayerTime12h(prayerTimes.fajr, language)}</span>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
              <span className="text-[10px] text-amber-200 block font-semibold">ইফতারের সময়</span>
              <span className="text-lg font-black font-mono text-amber-300 mt-0.5 block">
                {formatPrayerTime12h(prayerTimes.iftar, language)}
              </span>
              <span className="text-[10px] text-slate-300 block">মাগরিব: {formatPrayerTime12h(prayerTimes.maghrib, language)}</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-black/30 border border-white/10 text-xs text-emerald-100 flex items-center justify-between">
            <span className="italic">"হে আল্লাহ, তোমার জন্যই রোজা রেখেছি এবং তোমার রিযিকেই ইফতার করছি।"</span>
          </div>
        </div>
      )}

      {/* Tabs: Today / Checklist & Missed Tracker / 7 Days / Monthly */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs">
        <button
          onClick={() => setActiveTab('today')}
          className={`py-2 px-2 font-medium rounded-xl transition-all truncate text-center ${
            activeTab === 'today'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          আজকের ওয়াক্ত
        </button>
        <button
          onClick={() => setActiveTab('tracker')}
          className={`py-2 px-2 font-medium rounded-xl transition-all truncate text-center flex items-center justify-center gap-1 ${
            activeTab === 'tracker'
              ? 'bg-emerald-600 text-white shadow-xs font-bold'
              : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-slate-700'
          }`}
        >
          <span>সালাত চেকলিস্ট ও মিস হিসাব</span>
        </button>
        <button
          onClick={() => setActiveTab('7days')}
          className={`py-2 px-2 font-medium rounded-xl transition-all truncate text-center ${
            activeTab === '7days'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          ৭ দিনের সূচি
        </button>
        <button
          onClick={() => setActiveTab('monthly')}
          className={`py-2 px-2 font-medium rounded-xl transition-all truncate text-center ${
            activeTab === 'monthly'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          মাসিক ক্যালেন্ডার
        </button>
      </div>

      {/* TODAY'S VIEW */}
      {activeTab === 'today' && (
        <div className="space-y-4">
          {/* Main 5 Waqts List (Start & End times without Jamat time) */}
          <div className="space-y-2">
            {mainWaqts.map((waqt) => {
              const isNotified = notificationToggles[waqt.id];

              return (
                <div
                  key={waqt.id}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:border-emerald-300 dark:hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      {waqt.icon}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {waqt.label}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span>শুরু: <strong className="text-emerald-700 dark:text-emerald-400 font-mono font-semibold">{formatPrayerTime12h(waqt.startTime, language)}</strong></span>
                        <span>·</span>
                        <span>শেষ: <strong className="text-slate-700 dark:text-slate-300 font-mono font-semibold">{formatPrayerTime12h(waqt.endTime, language)}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white block">
                        {formatPrayerTime12h(waqt.startTime, language)}
                      </span>
                      <span className="text-[10px] text-slate-400 block">ওয়াক্ত শুরু</span>
                    </div>
                    <button
                      onClick={() => toggleNotification(waqt.id)}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                        isNotified
                          ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800'
                          : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                      title="আযান নোটিফিকেশন চালু/বন্ধ"
                    >
                      {isNotified ? (
                        <Bell className="w-4 h-4 fill-emerald-600" />
                      ) : (
                        <BellOff className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Prohibited / Makruh Prayer Times Section */}
          <div className="rounded-2xl bg-amber-500/10 dark:bg-amber-950/20 border border-amber-300/50 dark:border-amber-800/40 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <h4 className="text-xs font-bold text-amber-900 dark:text-amber-300 uppercase tracking-wide">
                নামাজ পড়ার ৩টি নিষিদ্ধ ও মাকরুহ সময়
              </h4>
            </div>

            <p className="text-xs text-slate-700 dark:text-slate-300 leading-normal">
              এই তিন সময়ে যেকোনো ফরজ, ওয়াজিব ও নফল নামাজ আদায় করা এবং সিজদা করা সম্পূর্ণ নিষিদ্ধ:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-amber-200/60 dark:border-amber-900/40">
                <span className="font-semibold text-amber-800 dark:text-amber-300 block">১. সূর্যোদয়ের সময়</span>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px] block mt-0.5">
                  {formatPrayerTime12h(prayerTimes.sunrise, language)} হতে ১৫ মিনিট
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-amber-200/60 dark:border-amber-900/40">
                <span className="font-semibold text-amber-800 dark:text-amber-300 block">২. দ্বিপ্রহর / জাওয়াল</span>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px] block mt-0.5">
                  {formatPrayerTime12h(prayerTimes.zawalStart, language)} - {formatPrayerTime12h(prayerTimes.zawalEnd, language)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-amber-200/60 dark:border-amber-900/40">
                <span className="font-semibold text-amber-800 dark:text-amber-300 block">৩. সূর্যাস্তের সময়</span>
                <span className="text-slate-600 dark:text-slate-400 font-mono text-[11px] block mt-0.5">
                  {formatPrayerTime12h(prayerTimes.sunsetProhibitedStart, language)} - {formatPrayerTime12h(prayerTimes.maghrib, language)}
                </span>
              </div>
            </div>
          </div>

          {/* COMPREHENSIVE NAFL PRAYER SCHEDULE & GUIDE (User Request) */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-emerald-200/80 dark:border-emerald-900/40 shadow-sm p-4 sm:p-5 space-y-4">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    সকল নফল নামাজের পূর্ণাঙ্গ সময়সূচি ও গাইড
                  </h3>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  ইশরাক, চাশত, আওয়াবীন ও তাহাজ্জুদসহ ১০টি গুরুত্বপূর্ণ নফল সালাতের শুরু-শেষ সময় ও ফজিলত
                </p>
              </div>

              {/* Running Nafl Badge in Header */}
              {runningNafl && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs font-bold shrink-0 self-start sm:self-auto">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span>এখন চলমান: {runningNafl.nameBn}</span>
                </div>
              )}
            </div>

            {/* If a Nafl prayer is currently running, show a highlighted active banner */}
            {runningNafl && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-700 to-emerald-800 text-white space-y-2 shadow-md">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-wider font-bold bg-white/20 px-2.5 py-0.5 rounded-full border border-white/20 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-300 animate-pulse" />
                    <span>চলমান নফল ওয়াক্ত</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-300">
                    সময় বাকি: {runningNafl.remainingMinutes ? `${runningNafl.remainingMinutes} মিনিট` : 'চলমান'}
                  </span>
                </div>

                <div className="flex items-baseline justify-between pt-1">
                  <div>
                    <h4 className="text-xl font-black text-white">{runningNafl.nameBn}</h4>
                    <span className="text-xs text-emerald-100 font-arabic" dir="rtl">{runningNafl.nameAr}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-emerald-200 block">ওয়াক্তের সময়সীমা</span>
                    <span className="text-sm font-bold font-mono text-white">
                      {formatPrayerTime12h(runningNafl.startTime, language)} - {formatPrayerTime12h(runningNafl.endTime, language)}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-emerald-100/90 italic pt-1 border-t border-white/10">
                  ✨ {runningNafl.virtueBn}
                </p>
              </div>
            )}

            {/* Filter Tabs for Nafl */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl text-xs font-medium">
              <button
                onClick={() => setSelectedNaflFilter('all')}
                className={`flex-1 py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                  selectedNaflFilter === 'all'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                সকল নফল ({naflPrayers.length})
              </button>
              <button
                onClick={() => setSelectedNaflFilter('timed')}
                className={`flex-1 py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                  selectedNaflFilter === 'timed'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                ওয়াক্তভিত্তিক ({naflPrayers.filter(p => p.isTimeBounded).length})
              </button>
              <button
                onClick={() => setSelectedNaflFilter('general')}
                className={`flex-1 py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                  selectedNaflFilter === 'general'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                অন্যান্য নফল ({naflPrayers.filter(p => !p.isTimeBounded).length})
              </button>
            </div>

            {/* Nafl Prayers List */}
            <div className="space-y-2.5">
              {filteredNafl.map((nafl) => {
                const isExpanded = expandedNaflId === nafl.id;
                const isRunning = nafl.isRunning;

                return (
                  <div
                    key={nafl.id}
                    className={`rounded-2xl border transition-all ${
                      isRunning
                        ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-500 shadow-xs ring-1 ring-emerald-500/30'
                        : 'bg-slate-50/80 dark:bg-slate-850 border-slate-200/80 dark:border-slate-800'
                    }`}
                  >
                    {/* Header Row */}
                    <div
                      onClick={() => {
                        triggerHaptic(10);
                        setExpandedNaflId(isExpanded ? null : nafl.id);
                      }}
                      className="p-3.5 flex items-center justify-between cursor-pointer select-none"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            {nafl.nameBn}
                          </h4>
                          <span className="font-arabic text-xs text-slate-400 font-semibold" dir="rtl">
                            {nafl.nameAr}
                          </span>
                          {isRunning && (
                            <span className="text-[10px] bg-emerald-600 text-white font-bold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                              <Check className="w-2.5 h-2.5" /> চলমান
                            </span>
                          )}
                        </div>

                        {/* Start & End Times */}
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                          {nafl.isTimeBounded ? (
                            <>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                <span>শুরু: <strong className="font-mono text-emerald-700 dark:text-emerald-400">{formatPrayerTime12h(nafl.startTime, language)}</strong></span>
                              </span>
                              <span>·</span>
                              <span>শেষ: <strong className="font-mono text-slate-800 dark:text-slate-200">{formatPrayerTime12h(nafl.endTime, language)}</strong></span>
                            </>
                          ) : (
                            <span className="flex items-center gap-1 text-slate-500">
                              <Info className="w-3.5 h-3.5 text-slate-400" />
                              <span>{nafl.startTime} ({nafl.endTime})</span>
                            </span>
                          )}
                          <span>·</span>
                          <span className="text-amber-700 dark:text-amber-400 font-medium">রাকাত: {nafl.rakatBn}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          className="w-7 h-7 rounded-lg bg-white dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center border border-slate-200/60 dark:border-slate-700 transition-transform"
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Expandable Details (Virtues, Hadith, How to Pray) */}
                    {isExpanded && (
                      <div className="px-3.5 pb-4 pt-1 border-t border-slate-200/60 dark:border-slate-800/80 space-y-3 text-xs text-slate-700 dark:text-slate-300 font-bengali">
                        {/* Virtue */}
                        <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 space-y-1">
                          <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                            ফজিলত ও গুরুত্ব:
                          </span>
                          <p className="leading-relaxed text-slate-800 dark:text-slate-200">
                            {nafl.virtueBn}
                          </p>
                          <span className="text-[11px] text-slate-500 dark:text-slate-400 block pt-0.5">
                            দলিল: {nafl.hadithReferenceBn}
                          </span>
                        </div>

                        {/* How to pray */}
                        <div className="p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/30 space-y-1">
                          <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                            নামাজ আদায়ের নিয়ম ও পদ্ধতি:
                          </span>
                          <p className="leading-relaxed text-slate-700 dark:text-slate-300">
                            {nafl.howToPrayBn}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Sahri Details */}
          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold text-xs">
              <Sunrise className="w-3.5 h-3.5" />
              <span>সাহরির শেষ সময় (রোজা ও তাহাজ্জুদ সমাপ্তি)</span>
            </div>
            <div className="flex items-baseline justify-between pt-0.5">
              <span className="text-sm font-bold font-mono text-slate-800 dark:text-slate-200">
                {formatPrayerTime12h(prayerTimes.sahriEnd, language)}
              </span>
              <span className="text-[11px] text-slate-500">
                সতর্কতামূলক সমাপ্তি: {formatPrayerTime12h(prayerTimes.sahriWarning, language)}
              </span>
            </div>
          </div>

          {/* Calculation Method & Asr Selector */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                আসরের হিসাব পদ্ধতি:
              </span>
              <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
                <button
                  onClick={() => onChangeAsrMethod('hanafi')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    asrMethod === 'hanafi'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t.hanafi}
                </button>
                <button
                  onClick={() => onChangeAsrMethod('standard')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    asrMethod === 'standard'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t.standardShafi}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                হিসাবের সংস্থা:
              </span>
              <select
                value={calculationMethod}
                onChange={(e) => onChangeCalculationMethod(e.target.value)}
                className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
              >
                <option value="IFB">ইসলামিক ফাউন্ডেশন বাংলাদেশ / করাচী</option>
                <option value="MWL">মুসলিম ওয়ার্ল্ড লীগ (MWL)</option>
                <option value="MAKKAH">উম্মুল কুরা বিশ্ববিদ্যালয় (মক্কা)</option>
                <option value="ISNA">ইসলামিক সোসাইটি অব নর্থ আমেরিকা</option>
                <option value="EGYPT">মিশরীয় জেনারেল অথরিটি</option>
              </select>
            </div>
          </div>

          {/* Direct Daily Checklist & Missed Namaz Section right on Today's Screen */}
          <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800">
            <NamazTracker language={language} />
          </div>
        </div>
      )}

      {/* DEDICATED SALAH CHECKLIST & MONTHLY MISSED TRACKER TAB */}
      {activeTab === 'tracker' && (
        <div className="space-y-4">
          <NamazTracker language={language} />
        </div>
      )}

      {/* 7-DAY FORECAST VIEW */}
      {activeTab === '7days' && (
        <div className="space-y-2">
          {next7Days.map((item, idx) => (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-1.5">
                <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                  {item.dateLabel}
                </span>
                <span className="text-[11px] text-slate-500">
                  ইফতার: <strong>{formatPrayerTime12h(item.times.iftar, language)}</strong>
                </span>
              </div>

              <div className="grid grid-cols-5 gap-1 text-center font-mono text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans">ফজর</span>
                  <span className="font-semibold">{item.times.fajr}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans">যোহর</span>
                  <span className="font-semibold">{item.times.dhuhr}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans">আসর</span>
                  <span className="font-semibold">{item.times.asr}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans">মাগরিব</span>
                  <span className="font-semibold">{item.times.maghrib}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans">এশা</span>
                  <span className="font-semibold">{item.times.isha}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 30-DAY MONTHLY VIEW */}
      {activeTab === 'monthly' && (
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 overflow-x-auto shadow-xs">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-2.5 font-semibold">তারিখ</th>
                <th className="p-2.5 font-semibold">ফজর</th>
                <th className="p-2.5 font-semibold">সূর্যোদয়</th>
                <th className="p-2.5 font-semibold">যোহর</th>
                <th className="p-2.5 font-semibold">আসর</th>
                <th className="p-2.5 font-semibold">মাগরিব</th>
                <th className="p-2.5 font-semibold">এশা</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
              {monthlyDays.map((row, i) => (
                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-850">
                  <td className="p-2.5 font-sans font-medium text-slate-800 dark:text-slate-200">
                    {row.dayStr} ({row.weekdayStr})
                  </td>
                  <td className="p-2.5">{row.times.fajr}</td>
                  <td className="p-2.5 text-slate-500">{row.times.sunrise}</td>
                  <td className="p-2.5">{row.times.dhuhr}</td>
                  <td className="p-2.5">{row.times.asr}</td>
                  <td className="p-2.5 font-semibold text-emerald-700 dark:text-emerald-400">{row.times.maghrib}</td>
                  <td className="p-2.5">{row.times.isha}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
