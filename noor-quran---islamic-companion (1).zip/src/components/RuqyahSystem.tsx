import React, { useState, useEffect, useRef } from 'react';
import { AppLanguage } from '../types';
import {
  RUQYAH_CATEGORIES,
  RUQYAH_ITEMS,
  RuqyahItem,
  RuqyahCategory,
  matchRuqyahByQuery,
  RuqyahSearchMatch,
} from '../data/ruqyahData';
import {
  Shield,
  Play,
  Pause,
  RotateCcw,
  Search,
  Sparkles,
  BookOpen,
  Heart,
  Bookmark,
  Share2,
  Check,
  ChevronRight,
  ChevronLeft,
  X,
  Volume2,
  VolumeX,
  Clock,
  AlertTriangle,
  Flame,
  Moon,
  Sun,
  Eye,
  HeartPulse,
  Home,
  Compass,
  ShieldCheck,
  Sliders,
  Download,
  Info,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface RuqyahSystemProps {
  language: AppLanguage;
  onBack?: () => void;
}

const STORAGE_KEY_FAVORITES = 'noor_quran_ruqyah_favorites_v1';
const STORAGE_KEY_ROUTINE = 'noor_quran_ruqyah_routine_v1';
const STORAGE_KEY_HISTORY = 'noor_quran_ruqyah_history_v1';

export const RuqyahSystem: React.FC<RuqyahSystemProps> = ({
  language,
  onBack,
}) => {
  // Mode: Simple (audio first, large buttons) vs Learn (deep textual, tajweed, step-by-step)
  const [viewMode, setViewMode] = useState<'simple' | 'learn'>('learn');

  // Search & Smart NLP Suggestion
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<ReturnType<typeof matchRuqyahByQuery> | null>(null);

  // Selected Category filter
  const [selectedCategory, setSelectedCategory] = useState<RuqyahCategory | 'all'>('all');

  // Active playing Ruqyah item
  const [activeItem, setActiveItem] = useState<RuqyahItem | null>(RUQYAH_ITEMS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isLooping, setIsLooping] = useState(false);
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimeRemaining, setSleepTimeRemaining] = useState<number | null>(null);

  // Detail modal
  const [detailItem, setDetailItem] = useState<RuqyahItem | null>(null);

  // Favorites & Bookmarks
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FAVORITES);
      return saved ? JSON.parse(saved) : ['ruq_fatihah', 'ruq_ayatul_kursi', 'ruq_muawwidhat'];
    } catch {
      return ['ruq_fatihah', 'ruq_ayatul_kursi', 'ruq_muawwidhat'];
    }
  });

  // Daily Protection Routine Checklist
  const [dailyRoutineProgress, setDailyRoutineProgress] = useState<Record<string, boolean>>(() => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const saved = localStorage.getItem(`${STORAGE_KEY_ROUTINE}_${today}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Persist Favorites
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_FAVORITES, JSON.stringify(favorites));
    } catch {
      // ignore
    }
  }, [favorites]);

  // Persist Routine
  useEffect(() => {
    try {
      const today = new Date().toISOString().split('T')[0];
      localStorage.setItem(`${STORAGE_KEY_ROUTINE}_${today}`, JSON.stringify(dailyRoutineProgress));
    } catch {
      // ignore
    }
  }, [dailyRoutineProgress]);

  // Handle Search Input with NLP
  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const res = matchRuqyahByQuery(searchQuery);
      setSearchResult(res);
    } else {
      setSearchResult(null);
    }
  }, [searchQuery]);

  // Sleep Timer Countdown
  useEffect(() => {
    if (!sleepTimerMinutes) {
      setSleepTimeRemaining(null);
      return;
    }
    setSleepTimeRemaining(sleepTimerMinutes * 60);

    const interval = setInterval(() => {
      setSleepTimeRemaining((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          if (audioRef.current) {
            audioRef.current.pause();
          }
          setIsPlaying(false);
          setSleepTimerMinutes(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes]);

  // Play audio item
  const handlePlayItem = (item: RuqyahItem, slow: boolean = false) => {
    triggerHaptic(20);
    setActiveItem(item);

    // Audio stream URL (sample authentic recitation)
    const audioUrl = slow && item.audioSlowUrl ? item.audioSlowUrl : (item.audioFullUrl || 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3');

    if (audioRef.current) {
      audioRef.current.src = audioUrl;
      audioRef.current.playbackRate = playbackSpeed;
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        console.warn('Audio play error:', err);
        setIsPlaying(true); // fallback UI indicator
      });
    } else {
      setIsPlaying(true);
    }

    // Save history
    try {
      const hist = JSON.parse(localStorage.getItem(STORAGE_KEY_HISTORY) || '[]');
      const updated = [item.id, ...hist.filter((id: string) => id !== item.id)].slice(0, 20);
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleTogglePlayPause = () => {
    triggerHaptic(15);
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(console.warn);
    }
  };

  const handleToggleFavorite = (id: string) => {
    triggerHaptic(15);
    setFavorites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const handleToggleRoutineCheck = (id: string) => {
    triggerHaptic(20);
    setDailyRoutineProgress(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleCopyText = (item: RuqyahItem) => {
    triggerHaptic(15);
    const content = `${item.titleBn}\n\n${item.arabic}\n\nউচ্চারণ: ${item.transliterationBn}\n\nঅর্থ: ${item.translationBn}\n\nসূত্র: ${item.source}\n\n[নূর কুরআন - রুকইয়াহ শারইয়াহ]`;
    navigator.clipboard.writeText(content).then(() => {
      setCopiedId(item.id);
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  // Filter items
  const filteredItems = selectedCategory === 'all'
    ? RUQYAH_ITEMS
    : RUQYAH_ITEMS.filter(item => item.category === selectedCategory);

  // Daily Protection Routine Core Items (Fatihah, Ayatul Kursi, Muawwidhat, Night Protection)
  const ROUTINE_CORE_IDS = ['ruq_fatihah', 'ruq_ayatul_kursi', 'ruq_muawwidhat', 'ruq_baqarah_last2', 'ruq_hasad_prophetic'];
  const routineCompletedCount = ROUTINE_CORE_IDS.filter(id => dailyRoutineProgress[id]).length;
  const routinePercent = Math.round((routineCompletedCount / ROUTINE_CORE_IDS.length) * 100);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame': return <Flame className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
      case 'Moon': return <Moon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
      case 'Sun': return <Sun className="w-5 h-5 text-amber-500" />;
      case 'Eye': return <Eye className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'HeartPulse': return <HeartPulse className="w-5 h-5 text-rose-500" />;
      case 'Home': return <Home className="w-5 h-5 text-sky-600 dark:text-sky-400" />;
      case 'Compass': return <Compass className="w-5 h-5 text-blue-500" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-purple-500" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5 text-emerald-600" />;
      default: return <Shield className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <div className="pb-32 pt-2 px-3 sm:px-4 max-w-2xl mx-auto space-y-4">
      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onEnded={() => {
          if (isLooping) {
            audioRef.current?.play().catch(console.warn);
          } else {
            setIsPlaying(false);
          }
        }}
        preload="none"
      />

      {/* Top Header Row with Navigation & Mode Switcher */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={() => {
                triggerHaptic(15);
                onBack();
              }}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
              title="ফিরে যান"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <span>রুকইয়াহ শারইয়াহ (Ruqyah)</span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              কুরআন ও সহিহ সুন্নাহভিত্তিক আত্মিক আরোগ্য ও সুরক্ষাব্যবস্থা
            </p>
          </div>
        </div>

        {/* Simple vs Learn Mode Pill */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl text-xs">
          <button
            onClick={() => {
              triggerHaptic(15);
              setViewMode('simple');
            }}
            className={`px-2.5 py-1 rounded-xl font-semibold transition-all ${
              viewMode === 'simple'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            অডিও মোড
          </button>
          <button
            onClick={() => {
              triggerHaptic(15);
              setViewMode('learn');
            }}
            className={`px-2.5 py-1 rounded-xl font-semibold transition-all ${
              viewMode === 'learn'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            শেখার মোড
          </button>
        </div>
      </div>

      {/* Islamic Pure Belief & Anti-Shirk Safety Banner */}
      <div className="p-3 sm:p-3.5 rounded-2xl bg-amber-500/10 dark:bg-amber-950/25 border border-amber-300/50 dark:border-amber-800/40 text-xs text-amber-950 dark:text-amber-200 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5 leading-relaxed font-bengali">
          <span className="font-bold block">সুন্নাহসম্মত রুকইয়াহর মূল শর্ত ও সতর্কতা:</span>
          <p className="text-[11px] text-slate-700 dark:text-amber-100/90">
            রুকইয়াহ কেবল কুরআন ও রাসুলুল্লাহ (সা.) নির্দেশিত সহিহ দোয়ার মাধ্যমে হতে হবে। তাবিজ-কবজ, কুফরি মন্ত্র, সংখ্যা-ভিত্তিক নকশা ও শিরকি পদ্ধতি সম্পূর্ণ নিষিদ্ধ। শিফা একমাত্র মহান আল্লাহর হাতে।
          </p>
        </div>
      </div>

      {/* Smart Search & Suggestion Input */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="আপনার সমস্যা লিখুন (যেমন: ghume chepe dhore, jin er voy, bad nojor, anxiety)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm placeholder:text-slate-400 shadow-2xs focus:ring-2 focus:ring-emerald-500/30 outline-hidden"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Smart Matching Result Card */}
        {searchResult && searchResult.primaryMatch && (
          <div className="p-4 rounded-3xl bg-linear-to-br from-emerald-950 via-teal-950 to-slate-950 border border-emerald-500/50 text-white shadow-md space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>শনাক্তকৃত রুকইয়াহ প্ল্যান: {searchResult.detectedIntentBn}</span>
              </span>
              <span className="text-[10px] bg-emerald-500/30 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                লক্ষ্যভিত্তিক সমাধান
              </span>
            </div>

            {/* Why This Ruqyah (কেন এই রুকইয়াহ) */}
            <div className="p-2.5 rounded-xl bg-white/10 text-xs text-emerald-100 font-bengali leading-relaxed border-l-2 border-amber-400">
              <strong>কেন এই রুকইয়াহ:</strong> {searchResult.primaryMatch.matchedReasonBn}
            </div>

            {/* Primary Matched Item Card */}
            <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-between gap-2">
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  {searchResult.primaryMatch.matchedItem.titleBn}
                </h4>
                <p className="text-[11px] text-emerald-200">
                  {searchResult.primaryMatch.matchedItem.targetBenefitBn}
                </p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handlePlayItem(searchResult.primaryMatch!.matchedItem)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition-all shadow-xs"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>শুনুন</span>
                </button>

                <button
                  onClick={() => setDetailItem(searchResult.primaryMatch!.matchedItem)}
                  className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs"
                  title="বিস্তারিত নিয়ম দেখুন"
                >
                  <BookOpen className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Emergency Medical Alert if keyword triggered */}
            {searchResult.hasMedicalAlert && (
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-[11px] text-rose-200 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{searchResult.medicalAlertMessageBn}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Today's Protection Routine & Play Button Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-800 via-teal-900 to-slate-950 text-white p-5 sm:p-6 shadow-xl border border-emerald-600/40 space-y-4">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-44 h-44 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              <span>আজকের সুরক্ষা রুটিন (Daily Protection)</span>
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              দৈনিক রুকইয়াহ ও হিফাজতের আমল
            </h3>
            <p className="text-xs text-emerald-200">
              সকাল-সন্ধ্যা ও শয্যাগ্রহণের মাসনূন ঢাল
            </p>
          </div>

          <div className="text-right">
            <span className="text-2xl font-bold font-mono text-amber-300">
              {routinePercent}%
            </span>
            <span className="text-[10px] text-emerald-200 block">
              {routineCompletedCount}/{ROUTINE_CORE_IDS.length} সম্পন্ন
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-white/20 overflow-hidden">
          <div
            className="h-full bg-linear-to-r from-amber-300 to-emerald-300 rounded-full transition-all duration-500"
            style={{ width: `${routinePercent}%` }}
          />
        </div>

        {/* Action Row: Big Play Button & Routine Check */}
        <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
          <button
            onClick={() => handlePlayItem(RUQYAH_ITEMS[0])}
            className="w-full sm:flex-1 py-3 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.99] cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>দৈনিক রুকইয়াহ সম্পূর্ণ শুনুন (Play Daily Ruqyah)</span>
          </button>

          <button
            onClick={() => {
              triggerHaptic(15);
              setSelectedCategory('morning_evening');
            }}
            className="w-full sm:w-auto py-3 px-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <Clock className="w-4 h-4" />
            <span>সকাল-সন্ধ্যার আযকার</span>
          </button>
        </div>
      </div>

      {/* Ruqyah Categories Filter Strip */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 px-1">
          <span className="font-bold text-slate-800 dark:text-slate-200">
            রুকইয়াহর ১০টি নির্দিষ্ট ক্যাটাগরি:
          </span>
          <span>{filteredItems.length}টি দোয়া ও আয়াত</span>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
          <button
            onClick={() => {
              triggerHaptic(15);
              setSelectedCategory('all');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
              selectedCategory === 'all'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
            }`}
          >
            সবগুলো ({RUQYAH_ITEMS.length})
          </button>

          {RUQYAH_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                triggerHaptic(15);
                setSelectedCategory(cat.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
              }`}
            >
              <span>{cat.nameBn.split(' ')[0]}</span>
              <span className="text-[10px] opacity-75 font-mono">({cat.totalCount})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Ruqyah Items List */}
      <div className="space-y-3">
        {filteredItems.map((item) => {
          const isCurrentPlaying = activeItem?.id === item.id && isPlaying;
          const isFav = favorites.includes(item.id);
          const isChecked = !!dailyRoutineProgress[item.id];

          return (
            <div
              key={item.id}
              className={`p-4 rounded-3xl bg-white dark:bg-slate-900 border transition-all ${
                isCurrentPlaying
                  ? 'border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                  : 'border-slate-200/80 dark:border-slate-800 shadow-2xs hover:border-slate-300'
              }`}
            >
              {/* Top Row: Category badge, Title, and Actions */}
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5 mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60">
                      {item.categoryBn}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                      {item.repeatNoteBn}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {item.titleBn}
                  </h4>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {/* Daily Routine Check Button */}
                  <button
                    onClick={() => handleToggleRoutineCheck(item.id)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                      isChecked
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600'
                    }`}
                    title={isChecked ? 'আজকের আমল সম্পন্ন' : 'আজকের আমলে টিক দিন'}
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>

                  {/* Favorite Button */}
                  <button
                    onClick={() => handleToggleFavorite(item.id)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                      isFav
                        ? 'text-rose-500 bg-rose-50 dark:bg-rose-950/40'
                        : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                    title="প্রিয় তালিকা"
                  >
                    <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                  </button>

                  {/* Copy Button */}
                  <button
                    onClick={() => handleCopyText(item)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="কপি করুন"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Share2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Simple Mode vs Learn Mode Content */}
              {viewMode === 'simple' ? (
                /* Simple Mode: Audio First, Large Buttons, Short Rule */
                <div className="space-y-3">
                  {/* Single Line Purpose */}
                  <p className="text-xs text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
                    <strong>উদ্দেশ্য:</strong> {item.purposeBn}
                  </p>

                  <div className="p-3 rounded-2xl bg-amber-50/40 dark:bg-slate-950/40 border border-amber-200/40 dark:border-slate-800/80">
                    <p className="font-arabic text-base sm:text-lg text-right text-slate-900 dark:text-slate-100 font-bold leading-loose" dir="rtl">
                      {item.arabic.slice(0, 160)}...
                    </p>
                  </div>

                  {/* Large Audio Action Buttons */}
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handlePlayItem(item)}
                      className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                        isCurrentPlaying
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      }`}
                    >
                      {isCurrentPlaying ? (
                        <>
                          <Pause className="w-4 h-4" />
                          <span>বিরতি দিন</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 fill-current" />
                          <span>রুকইয়াহ শুনুন ({item.repeatCount} বার)</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => setDetailItem(item)}
                      className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors"
                    >
                      বিস্তারিত নিয়ম
                    </button>
                  </div>
                </div>
              ) : (
                /* Learn Mode: Arabic with Diacritics, Pronunciation, Meaning, Step-by-Step gestures */
                <div className="space-y-3 text-left">
                  {/* Arabic Text Box */}
                  <div
                    className="w-full p-4 rounded-2xl bg-amber-50/30 dark:bg-slate-950/50 border border-amber-200/40 dark:border-slate-800/80 block clear-both"
                    dir="rtl"
                  >
                    <p className="font-arabic text-lg sm:text-xl text-right text-slate-900 dark:text-slate-100 leading-loose block select-text">
                      {item.arabic}
                    </p>
                  </div>

                  {/* Bengali Pronunciation */}
                  <div className="p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/70 dark:border-emerald-800/50 space-y-1 block clear-both" dir="ltr">
                    <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 block">
                      বাংলা উচ্চারণ:
                    </span>
                    <p className="text-xs sm:text-sm text-slate-800 dark:text-emerald-100 font-medium leading-relaxed font-bengali">
                      {item.transliterationBn}
                    </p>
                  </div>

                  {/* Bengali Meaning */}
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800 space-y-1 block clear-both" dir="ltr">
                    <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 block">
                      বাংলা অর্থ:
                    </span>
                    <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-bengali">
                      {item.translationBn}
                    </p>
                  </div>

                  {/* Source & Instructions */}
                  <div className="p-3 rounded-2xl bg-slate-100/70 dark:bg-slate-800/70 text-xs space-y-2 border border-slate-200/50 dark:border-slate-700/50">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                      <span>সূত্র: {item.source}</span>
                      <span className="font-bold text-emerald-700 dark:text-emerald-400">পড়ার পরিমাণ: {item.repeatCount} বার</span>
                    </div>

                    <div className="space-y-1 pt-1 border-t border-slate-200/50 dark:border-slate-700/50">
                      <span className="font-bold text-slate-800 dark:text-slate-200 text-[11px] block">
                        আমল ও দম (ফুঁ) করার পদ্ধতি:
                      </span>
                      <ul className="space-y-0.5 text-[11px] text-slate-600 dark:text-slate-300 pl-1">
                        {item.instructionsBn.map((ins, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span>{ins}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Audio Controls Row */}
                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => handlePlayItem(item)}
                      className={`py-2 px-3.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                        isCurrentPlaying
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      }`}
                    >
                      {isCurrentPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                      <span>{isCurrentPlaying ? 'বিরতি দিন' : 'অডিও শুনুন'}</span>
                    </button>

                    <button
                      onClick={() => handlePlayItem(item, true)}
                      className="text-xs text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>ধীরগতির শেখার অডিও</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Persistent Mini Audio Player at Bottom */}
      {activeItem && (
        <div className="fixed bottom-16 left-0 right-0 z-35 px-3 max-w-2xl mx-auto">
          <div className="p-3.5 rounded-2xl bg-linear-to-r from-slate-900 via-emerald-950 to-slate-900 text-white border border-emerald-500/40 shadow-2xl backdrop-blur-md flex items-center justify-between gap-3 animate-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center gap-2.5 min-w-0 flex-1">
              <button
                onClick={handleTogglePlayPause}
                className="w-10 h-10 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shrink-0 shadow-md transition-all active:scale-95"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 fill-current" />
                ) : (
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                )}
              </button>

              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block">
                  রুকইয়াহ প্লেয়ার {isPlaying ? 'চলছে' : 'স্থগিত'}
                </span>
                <h5 className="text-xs font-bold text-white truncate">
                  {activeItem.titleBn}
                </h5>
                <span className="text-[10px] text-emerald-200 block truncate">
                  {activeItem.categoryBn} · {activeItem.repeatNoteBn}
                </span>
              </div>
            </div>

            {/* Quick Controls: Speed, Sleep Timer & Close */}
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Playback Speed */}
              <button
                onClick={() => {
                  triggerHaptic(15);
                  const speeds = [0.75, 1, 1.25];
                  const next = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
                  setPlaybackSpeed(next);
                  if (audioRef.current) audioRef.current.playbackRate = next;
                }}
                className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-mono text-emerald-200"
                title="গতি পরিবর্তন"
              >
                {playbackSpeed}x
              </button>

              {/* Sleep Timer */}
              <button
                onClick={() => {
                  triggerHaptic(15);
                  const timers = [null, 15, 30, 60];
                  const next = timers[(timers.indexOf(sleepTimerMinutes) + 1) % timers.length];
                  setSleepTimerMinutes(next);
                }}
                className={`p-1.5 rounded-lg transition-colors ${
                  sleepTimerMinutes
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
                title={sleepTimerMinutes ? `স্লিপ টাইমার: ${Math.ceil((sleepTimeRemaining || 0) / 60)} মিনিট বাকি` : 'স্লিপ টাইমার সেট করুন'}
              >
                <Clock className="w-3.5 h-3.5" />
              </button>

              {/* Loop */}
              <button
                onClick={() => {
                  triggerHaptic(15);
                  setIsLooping(!isLooping);
                }}
                className={`p-1.5 rounded-lg transition-colors ${
                  isLooping
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
                title="একই রুকইয়াহ পুনরাবৃত্তি"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  if (audioRef.current) audioRef.current.pause();
                  setIsPlaying(false);
                  setActiveItem(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
                title="বন্ধ করুন"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Modal for Learning Mode View */}
      {detailItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 sm:p-6 space-y-4 border border-emerald-500/20 dark:border-slate-800 shadow-2xl max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300">
                  {detailItem.categoryBn}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {detailItem.titleBn}
                </h3>
              </div>
              <button
                onClick={() => setDetailItem(null)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Why This Ruqyah Explanation */}
            <div className="p-3 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/60 text-xs space-y-1">
              <span className="font-bold text-emerald-900 dark:text-emerald-300 block">
                কেন এই রুকইয়াহ পড়বেন / শুনবেন:
              </span>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-bengali">
                {detailItem.purposeBn}
              </p>
            </div>

            {/* Arabic Box */}
            <div className="p-4 rounded-2xl bg-amber-50/40 dark:bg-slate-950/60 border border-amber-200/60 dark:border-slate-800" dir="rtl">
              <p className="font-arabic text-xl sm:text-2xl text-right text-slate-900 dark:text-white leading-loose select-text">
                {detailItem.arabic}
              </p>
            </div>

            {/* Pronunciation & Meaning */}
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <span className="font-bold text-slate-500 block">বাংলা উচ্চারণ:</span>
                <p className="text-slate-900 dark:text-slate-100 font-medium leading-relaxed font-bengali">
                  {detailItem.transliterationBn}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <span className="font-bold text-slate-500 block">বাংলা অর্থ:</span>
                <p className="text-slate-800 dark:text-slate-200 leading-relaxed font-bengali">
                  {detailItem.translationBn}
                </p>
              </div>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-850 space-y-1.5 text-xs">
              <span className="font-bold text-slate-900 dark:text-white block">
                ধারাবাহিক আমলের নিয়ম (Step-by-Step):
              </span>
              <ul className="space-y-1 text-slate-700 dark:text-slate-300 pl-1 font-bengali">
                {detailItem.instructionsBn.map((ins, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">•</span>
                    <span>{ins}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-1 text-[11px] text-slate-500 border-t border-slate-200 dark:border-slate-700">
                দলিল ও রেফারেন্স: {detailItem.source}
              </div>
            </div>

            {/* Play Button inside Modal */}
            <div className="pt-1 flex items-center gap-2">
              <button
                onClick={() => {
                  handlePlayItem(detailItem);
                  setDetailItem(null);
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>প্লেয়ারে রুকইয়াহ চালান</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
