import React, { useState, useEffect } from 'react';
import { AppLanguage, LocationInfo } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  Compass,
  Navigation,
  RotateCw,
  Info,
  MapPin,
  Sparkles,
  Check,
  AlertCircle,
  LocateFixed,
  RefreshCw,
  Shield,
} from 'lucide-react';
import { triggerHaptic } from '../utils/audioPlayer';

interface QiblaCompassProps {
  language: AppLanguage;
  location: LocationInfo;
}

// Holy Kaaba Coordinates in Makkah al-Mukarramah
const KAABA_LAT = 21.422487;
const KAABA_LNG = 39.826206;

// Formula to calculate Great-Circle Qibla bearing from user latitude and longitude
function calculateQiblaBearing(lat: number, lng: number): number {
  const phiK = (KAABA_LAT * Math.PI) / 180.0;
  const lambdaK = (KAABA_LNG * Math.PI) / 180.0;
  const phi = (lat * Math.PI) / 180.0;
  const lambda = (lng * Math.PI) / 180.0;

  const numerator = Math.sin(lambdaK - lambda);
  const denominator =
    Math.cos(phi) * Math.tan(phiK) - Math.sin(phi) * Math.cos(lambdaK - lambda);

  let qibla = (Math.atan2(numerator, denominator) * 180.0) / Math.PI;
  if (qibla < 0) qibla += 360;
  return Math.round(qibla * 10) / 10;
}

// Distance to Kaaba via Haversine formula
function calculateDistanceToKaabaKm(lat: number, lng: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((KAABA_LAT - lat) * Math.PI) / 180.0;
  const dLng = ((KAABA_LNG - lng) * Math.PI) / 180.0;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat * Math.PI) / 180.0) *
      Math.cos((KAABA_LAT * Math.PI) / 180.0) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export const QiblaCompass: React.FC<QiblaCompassProps> = ({
  language,
  location,
}) => {
  const t = TRANSLATIONS[language];
  const [deviceHeading, setDeviceHeading] = useState<number>(0);
  const [hasOrientationSensor, setHasOrientationSensor] = useState(false);
  const [manualAdjustment, setManualAdjustment] = useState<number>(0);

  // Live GPS state
  const [gpsCoordinates, setGpsCoordinates] = useState<{
    lat: number;
    lng: number;
    accuracy?: number;
  } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<
    'idle' | 'requesting' | 'granted' | 'denied' | 'unsupported'
  >('idle');
  const [gpsFeedback, setGpsFeedback] = useState<string | null>(null);
  const [needsSensorPermission, setNeedsSensorPermission] = useState(false);

  // Effective coordinates: Live GPS coordinate if granted, otherwise district location
  const currentLat = gpsCoordinates ? gpsCoordinates.lat : location.lat;
  const currentLng = gpsCoordinates ? gpsCoordinates.lng : location.lng;

  const qiblaAngle = calculateQiblaBearing(currentLat, currentLng);
  const distanceKm = calculateDistanceToKaabaKm(currentLat, currentLng);

  // Request device geolocation permission
  const handleRequestDeviceLocation = () => {
    triggerHaptic(15);
    if (typeof window === 'undefined' || !navigator.geolocation) {
      setGpsStatus('unsupported');
      setGpsFeedback('আপনার ডিভাইসে জিপিএস লোকেশন সমর্থিত নয়।');
      return;
    }

    setIsLocating(true);
    setGpsStatus('requesting');
    setGpsFeedback('ডিভাইসের লাইভ জিপিএস লোকেশন নেওয়া হচ্ছে...');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        setGpsCoordinates({
          lat: latitude,
          lng: longitude,
          accuracy: Math.round(accuracy),
        });
        setIsLocating(false);
        setGpsStatus('granted');
        setGpsFeedback(
          `জিপিএস সফল! সঠিকতা: ±${Math.round(accuracy)} মি.`
        );
        triggerHaptic(25);
        setTimeout(() => setGpsFeedback(null), 3500);
      },
      (error) => {
        setIsLocating(false);
        if (error.code === error.PERMISSION_DENIED) {
          setGpsStatus('denied');
          setGpsFeedback('লোকেশন পারমিশন মেলেনি। জেলাভিত্তিক লোকেশন ব্যবহৃত হচ্ছে।');
        } else {
          setGpsStatus('denied');
          setGpsFeedback('জিপিএস সিগন্যাল পাওয়া যায়নি। জেলাভিত্তিক তথ্য ব্যবহৃত হচ্ছে।');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      }
    );
  };

  // Request iOS / WebKit orientation permission if needed
  const handleRequestSensorPermission = async () => {
    triggerHaptic(15);
    try {
      if (
        typeof DeviceOrientationEvent !== 'undefined' &&
        typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> })
          .requestPermission === 'function'
      ) {
        const response = await (
          DeviceOrientationEvent as unknown as { requestPermission: () => Promise<string> }
        ).requestPermission();
        if (response === 'granted') {
          setNeedsSensorPermission(false);
          setHasOrientationSensor(true);
        }
      }
    } catch {
      // ignore
    }
  };

  // Try automatic GPS lookup on initial render once
  useEffect(() => {
    if (typeof window !== 'undefined' && navigator.geolocation) {
      handleRequestDeviceLocation();
    }
  }, []);

  // Orientation sensor event listener
  useEffect(() => {
    // Check if iOS 13+ requires explicit permission
    if (
      typeof DeviceOrientationEvent !== 'undefined' &&
      typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> })
        .requestPermission === 'function'
    ) {
      setNeedsSensorPermission(true);
    }

    const handleOrientation = (e: DeviceOrientationEvent) => {
      let heading = e.alpha || 0;
      // Webkit compass heading on iOS
      if ('webkitCompassHeading' in e) {
        heading = (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading;
      }
      setDeviceHeading(heading);
      setHasOrientationSensor(true);
      setNeedsSensorPermission(false);
    };

    if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
      window.addEventListener('deviceorientation', handleOrientation, true);
    }

    return () => {
      if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
        window.removeEventListener('deviceorientation', handleOrientation);
      }
    };
  }, []);

  const effectiveHeading = (deviceHeading + manualAdjustment) % 360;
  // Needle points to Qibla relative to device heading
  const needleRotation = (qiblaAngle - effectiveHeading + 360) % 360;
  const isFacingQibla = Math.abs(needleRotation) < 5 || Math.abs(needleRotation - 360) < 5;

  return (
    <div className="pb-24 pt-2 px-3 sm:px-4 max-w-md mx-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
          {t.qiblaCompass}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          লাইভ জিপিএস লোকেশন ও কাবার সঠিক দিকনির্দেশনা
        </p>
      </div>

      {/* DEVICE GPS LOCATION PERMISSION & STATUS CARD */}
      <div className={`p-4 rounded-3xl border transition-all space-y-3 ${
        gpsStatus === 'granted'
          ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 shadow-sm'
          : 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 shadow-md ring-2 ring-amber-400/30'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                gpsStatus === 'granted'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-amber-500 text-slate-950 shadow-xs animate-pulse'
              }`}
            >
              <LocateFixed className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 dark:text-white block">
                {gpsCoordinates
                  ? '✓ লাইভ ডিভাইস জিপিএস সক্রিয় (সঠিক ডাটা)'
                  : `বর্তমান অবস্থান: ${language === 'bn' ? location.nameBn : location.name} জেলা`}
              </span>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                {gpsCoordinates
                  ? `লাইভ অক্ষাংশ: ${gpsCoordinates.lat.toFixed(4)}°, দ্রাঘিমাংশ: ${gpsCoordinates.lng.toFixed(4)}° (সঠিকতা: ±${gpsCoordinates.accuracy || 15} মি.)`
                  : 'ডিভাইসের লাইভ জিপিএস পারমিশন দিলে কাবার নির্ভুলতম ডিগ্রি ও দিক পাওয়া যাবে।'}
              </p>
            </div>
          </div>

          <button
            onClick={handleRequestDeviceLocation}
            disabled={isLocating}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-md self-start sm:self-auto shrink-0 ${
              isLocating
                ? 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                : gpsStatus === 'granted'
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black ring-2 ring-amber-300'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
            <span>
              {isLocating
                ? 'লোকেশন খোঁজা হচ্ছে...'
                : gpsStatus === 'granted'
                ? 'জিপিএস রিফ্রেশ'
                : 'লোকেশন পারমিশন দিন'}
            </span>
          </button>
        </div>

        {/* Feedback Alert Message */}
        {gpsFeedback && (
          <div
            className={`p-2.5 rounded-2xl text-xs flex items-center gap-2 ${
              gpsStatus === 'granted'
                ? 'bg-emerald-100/80 dark:bg-emerald-900/50 text-emerald-900 dark:text-emerald-100 border border-emerald-300 dark:border-emerald-700'
                : 'bg-amber-100/90 dark:bg-amber-900/50 text-amber-950 dark:text-amber-100 border border-amber-300 dark:border-amber-700'
            }`}
          >
            {gpsStatus === 'granted' ? (
              <Check className="w-4 h-4 text-emerald-700 dark:text-emerald-300 shrink-0 stroke-[3]" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-700 dark:text-amber-300 shrink-0 stroke-[3]" />
            )}
            <span className="font-semibold">{gpsFeedback}</span>
          </div>
        )}

        {/* iOS Sensor Permission Button */}
        {needsSensorPermission && (
          <button
            onClick={handleRequestSensorPermission}
            className="w-full py-2.5 px-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-colors shadow-md"
          >
            <Compass className="w-4 h-4" />
            <span>কম্পাস সেন্সর অনুমতি দিন (Allow Device Orientation)</span>
          </button>
        )}
      </div>

      {/* Kaaba Info Card */}
      <div className="p-3.5 rounded-2xl bg-linear-to-r from-emerald-800 to-teal-900 text-white shadow-md flex items-center justify-between border border-emerald-700/50">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl overflow-hidden border border-white/20 shrink-0">
            <img
              src="/src/assets/images/kaaba_makkah_art_1790957360864.jpg"
              alt="Holy Kaaba Makkah"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h4 className="text-sm font-bold">পবিত্র কাবা শরিফ (মক্কা)</h4>
            <span className="text-xs text-emerald-200">
              দূরত্ব: <strong className="font-mono text-white">{distanceKm.toLocaleString()} কি.মি.</strong>
            </span>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-emerald-200 block uppercase">কিবলা কোণ</span>
          <span className="text-lg font-bold font-mono text-amber-300">
            {qiblaAngle}°
          </span>
        </div>
      </div>

      {/* Compass Circular Dial */}
      <div className="flex flex-col items-center justify-center py-4">
        <div className="relative w-72 h-72 rounded-full bg-slate-900 border-8 border-slate-800 shadow-2xl flex items-center justify-center select-none overflow-hidden">
          {/* Compass Dial Markings */}
          <div
            className="absolute inset-0 transition-transform duration-300 flex items-center justify-center"
            style={{ transform: `rotate(${-effectiveHeading}deg)` }}
          >
            {/* North Indicator */}
            <span className="absolute top-2 text-xs font-black text-rose-500 tracking-wider">
              N (উত্তর)
            </span>
            <span className="absolute bottom-2 text-xs font-bold text-slate-400">
              S (দক্ষিণ)
            </span>
            <span className="absolute right-2 text-xs font-bold text-slate-400">
              E (পূর্ব)
            </span>
            <span className="absolute left-2 text-xs font-bold text-slate-400">
              W (পশ্চিম)
            </span>

            {/* Compass degree ticks */}
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="absolute w-0.5 h-3 bg-slate-700"
                style={{
                  transform: `rotate(${i * 30}deg) translateY(-120px)`,
                }}
              />
            ))}
          </div>

          {/* Qibla Direction Needle */}
          <div
            className="absolute w-full h-full flex items-center justify-center transition-transform duration-500 pointer-events-none"
            style={{ transform: `rotate(${needleRotation}deg)` }}
          >
            {/* Needle pointing to Kaaba */}
            <div className="flex flex-col items-center justify-start h-full pt-6">
              <div className="w-8 h-8 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg border-2 border-white animate-pulse">
                🕋
              </div>
              <div className="w-1.5 h-20 bg-linear-to-b from-amber-400 to-emerald-500 rounded-full shadow-md" />
            </div>
          </div>

          {/* Center Hub */}
          <div className="relative z-10 w-16 h-16 rounded-full bg-slate-800 border-4 border-slate-700 flex flex-col items-center justify-center text-white shadow-inner">
            <span className="text-xs font-mono font-bold text-emerald-400">
              {Math.round(needleRotation)}°
            </span>
            <span className="text-[9px] text-slate-400 font-semibold">কিবলা</span>
          </div>
        </div>

        {/* Facing Status Notification */}
        <div className="mt-3">
          {isFacingQibla ? (
            <div className="px-4 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-md flex items-center gap-1.5 animate-bounce">
              <Sparkles className="w-3.5 h-3.5" />
              <span>মাশাআল্লাহ! আপনি সঠিক কিবলামুখী আছেন</span>
            </div>
          ) : (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              কাবার প্রতীকের দিকে ফোনটি ধীরে ধীরে ঘোরান
            </p>
          )}
        </div>
      </div>

      {/* Manual Compass Rotation Slider (for devices without hardware magnetometer) */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-2 text-xs">
        <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
          <span>ম্যানুয়াল দিক সমন্বয়:</span>
          <span className="font-mono font-bold">{effectiveHeading}°</span>
        </div>
        <input
          type="range"
          min="0"
          max="360"
          value={manualAdjustment}
          onChange={(e) => setManualAdjustment(Number(e.target.value))}
          className="w-full accent-emerald-600"
        />
        <div className="flex justify-between text-[10px] text-slate-400">
          <span>উত্তর (০°)</span>
          <span>পূর্ব (৯০°)</span>
          <span>দক্ষিণ (১৮০°)</span>
          <span>পশ্চিম (২৭০°)</span>
        </div>
      </div>

      {/* Calibration Notice */}
      <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-400">
        <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          {t.calibrateNotice} চৌম্বকীয় ক্ষেত্র বা ধাতব বস্তু থেকে ফোন দূরে রাখুন।
        </p>
      </div>
    </div>
  );
};
export default QiblaCompass;
