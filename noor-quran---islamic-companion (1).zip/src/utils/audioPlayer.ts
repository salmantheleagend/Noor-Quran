/**
 * Audio reciter definitions and playback management
 */

export interface ReciterInfo {
  id: string;
  name: string;
  nameBn: string;
  nameAr: string;
  subfolder: string;
}

export const QURAN_RECITERS: ReciterInfo[] = [
  {
    id: 'alafasy',
    name: 'Mishary Rashid Alafasy',
    nameBn: 'মিশারী রশিদ আল-আফাসী',
    nameAr: 'مشاري راشد العفاسي',
    subfolder: 'Alafasy_128kbps',
  },
  {
    id: 'abdulbasit',
    name: 'Abdul Basit Murattal',
    nameBn: 'আব্দুল বাসেত (মুরাত্তাল)',
    nameAr: 'عبد الباسط عبد الصمد',
    subfolder: 'Abdul_Basit_Murattal_192kbps',
  },
  {
    id: 'sudais',
    name: 'Abdur-Rahman As-Sudais',
    nameBn: 'আব্দুর রহমান আস-সুদাইস (ইমামে কাবা)',
    nameAr: 'عبد الرحمن السديس',
    subfolder: 'Abdurrahmaan_As-Sudais_192kbps',
  },
  {
    id: 'muaiqly',
    name: 'Maher Al-Muaiqly',
    nameBn: 'মাহের আল-মুয়াইক্বিলী',
    nameAr: 'ماهر المعيقلي',
    subfolder: 'MaherAlMuaiqly128kbps',
  },
];

// Helper to format 3-digit surah and ayah (e.g., Surah 1 Ayah 1 -> "001001.mp3")
export function getAyahAudioUrl(surahNum: number, ayahNum: number, reciterId: string = 'alafasy'): string {
  const reciter = QURAN_RECITERS.find(r => r.id === reciterId) || QURAN_RECITERS[0];
  const s = surahNum.toString().padStart(3, '0');
  const a = ayahNum.toString().padStart(3, '0');
  return `https://everyayah.com/data/${reciter.subfolder}/${s}${a}.mp3`;
}

// Full Surah audio URL (from high-speed Quran CDN)
export function getSurahAudioUrl(surahNum: number, reciterId: string = 'alafasy'): string {
  const s = surahNum.toString().padStart(3, '0');
  if (reciterId === 'abdulbasit') {
    return `https://server7.mp3quran.net/basit/${s}.mp3`;
  }
  if (reciterId === 'sudais') {
    return `https://server11.mp3quran.net/sds/${s}.mp3`;
  }
  if (reciterId === 'muaiqly') {
    return `https://server12.mp3quran.net/maher/${s}.mp3`;
  }
  // Default Alafasy
  return `https://server8.mp3quran.net/afs/${s}.mp3`;
}

// Speak Arabic letter or word using browser speech synthesis
export function speakArabic(text: string): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.85; // slightly slower for clear tajweed learning
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}

// Play pleasant mechanical click / bead sound for Tasbeeh
export function playTasbeehClick(): void {
  if (typeof window === 'undefined' || !window.AudioContext) return;
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(620, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.18, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  } catch {
    // Audio context may be restricted before user gesture
  }
}

// Play melodic Adhan preview chime / bell notification
export function playAdhanTone(): void {
  if (typeof window === 'undefined' || !window.AudioContext) return;
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const notes = [440, 554.37, 659.25, 880]; // A major arpeggio
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = ctx.currentTime + idx * 0.22;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.15, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.5);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.5);
    });
  } catch {
    // Ignore audio restriction
  }
}

// Haptic feedback trigger
export function triggerHaptic(duration = 25): void {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(duration);
    } catch {
      // Ignore vibration error
    }
  }
}
